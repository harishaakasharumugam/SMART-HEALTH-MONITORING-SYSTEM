#!/usr/bin/env python
"""Test messaging system with debugging"""

from backend.app import create_app
from backend.models import User
from backend.models_extended import DoctorPatientAssignment

app = create_app()

with app.app_context():
    patient = User.query.filter_by(role='patient').first()
    doctor = User.query.filter_by(role='doctor').first()
    
    if patient and doctor:
        print('=== TESTING MESSAGING SYSTEM ===\n')
        
        # Test 1: Patient fetching messages with doctor
        print(f'TEST 1: Patient (ID={patient.id}) fetching messages with doctor (ID={doctor.id})')
        with app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = patient.id
                sess['_fresh'] = True
            
            resp = client.get(f'/api/messages/{doctor.id}')
            data = resp.get_json()
            print(f'  Status: {resp.status_code}')
            print(f'  Messages: {len(data.get("messages", [])) if data else 0}')
            if resp.status_code != 200:
                print(f'  Error: {data}')
        
        # Test 2: Doctor fetching messages with patient
        print(f'\nTEST 2: Doctor (ID={doctor.id}) fetching messages with patient (ID={patient.id})')
        
        # Check assignment first
        assign = DoctorPatientAssignment.query.filter(
            DoctorPatientAssignment.patient_id == patient.id,
            DoctorPatientAssignment.doctor_id == doctor.id,
            DoctorPatientAssignment.status == 'active'
        ).first()
        assign_exists = 'YES' if assign else 'NO'
        print(f'  Assignment exists: {assign_exists}')
        
        with app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = doctor.id
                sess['_fresh'] = True
            
            resp = client.get(f'/api/messages/{patient.id}')
            data = resp.get_json()
            print(f'  Status: {resp.status_code}')
            if resp.status_code == 200:
                print(f'  Messages: {len(data.get("messages", []))}')
            else:
                print(f'  Error: {data}')
