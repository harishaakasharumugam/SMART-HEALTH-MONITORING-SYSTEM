# Code Changes Summary - Medical Records Feature

## 📝 Overview

This document shows exactly what code was added to fix the medical records feature.

---

## 1️⃣ Backend Model Update

### File: `/backend/models.py`

**BEFORE:**
```python
class HealthReport(db.Model):
    __tablename__ = 'health_reports'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    report_type = db.Column(db.String(50))
    file_path = db.Column(db.String(255))
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)
```

**AFTER:**
```python
class HealthReport(db.Model):
    __tablename__ = 'health_reports'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))  # ← NEW
    report_type = db.Column(db.String(50))
    description = db.Column(db.Text)  # ← NEW  
    file_path = db.Column(db.String(255))
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)  # ← NEW
```

**What Changed:**
- Added `doctor_id` to track which doctor created the record
- Added `description` to store the medical findings
- Added `created_at` to track creation time

---

## 2️⃣ Backend Imports Update

### File: `/backend/routes/advanced_api.py`

**BEFORE:**
```python
from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from sqlalchemy import or_
from ..models import User, db
from ..models_extended import (
    Prescription, PrescriptionMedicine, Medicine, MedicineInteraction, 
    Appointment, ConsultationNote, TreatmentPlan, TreatmentPlanPhase,
    MedicalDocument, LabOrder, LabResult, EmailLog, DoctorPatientAssignment
)
from ..services.email_service import get_email_service
from ..services.pdf_professional import generate_professional_report
from ..services.audit_service import log_audit
from datetime import datetime, timedelta
import os
```

**AFTER:**
```python
from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from sqlalchemy import or_
from ..models import User, db, HealthReport  # ← ADDED: HealthReport
from ..models_extended import (
    Prescription, PrescriptionMedicine, Medicine, MedicineInteraction, 
    Appointment, ConsultationNote, TreatmentPlan, TreatmentPlanPhase,
    MedicalDocument, LabOrder, LabResult, EmailLog, DoctorPatientAssignment
)
from ..services.email_service import get_email_service
from ..services.pdf_professional import generate_professional_report
from ..services.audit_service import log_audit
from datetime import datetime, timedelta
import os
from werkzeug.utils import secure_filename  # ← ADDED: For filename security
```

---

## 3️⃣ Two New API Endpoints

### File: `/backend/routes/advanced_api.py` (at the end)

**ENDPOINT 1: Create Health Report**

```python
@advanced_api.route('/create-health-report', methods=['POST'])
@login_required
@log_audit("Created Health Report")
def create_health_report():
    """Create a new health report / medical record"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Only doctors can create health reports"}), 403
    
    try:
        patient_id = request.form.get('patient_id')
        report_type = request.form.get('report_type')
        description = request.form.get('description')
        
        if not patient_id:
            return jsonify({"status": "error", "message": "Patient ID is required"}), 400
        if not report_type:
            return jsonify({"status": "error", "message": "Report type is required"}), 400
        if not description:
            return jsonify({"status": "error", "message": "Description is required"}), 400
        
        # Verify patient exists and is assigned to this doctor
        patient = User.query.get(int(patient_id))
        if not patient or patient.role != 'patient':
            return jsonify({"status": "error", "message": "Patient not found"}), 404
        
        # Check doctor-patient assignment
        assignment = DoctorPatientAssignment.query.filter_by(
            doctor_id=current_user.id,
            patient_id=int(patient_id)
        ).first()
        if not assignment:
            return jsonify({"status": "error", "message": "Patient not assigned to you"}), 403
        
        file_path = None
        
        # Handle file upload if present
        if 'file' in request.files:
            file = request.files['file']
            if file and file.filename:
                # Validate file type
                allowed_extensions = {'pdf', 'jpg', 'jpeg', 'png'}
                file_ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
                
                if file_ext not in allowed_extensions:
                    return jsonify({"status": "error", "message": "File type not allowed. Use PDF, JPG, or PNG"}), 400
                
                # Validate file size (10MB max)
                file.seek(0, os.SEEK_END)
                file_size = file.tell()
                file.seek(0)
                
                if file_size > 10 * 1024 * 1024:
                    return jsonify({"status": "error", "message": "File size exceeds 10MB limit"}), 400
                
                # Create reports directory if it doesn't exist
                reports_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'reports')
                os.makedirs(reports_dir, exist_ok=True)
                
                # Save file with secure name
                filename = secure_filename(f"{patient_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
                file_path = os.path.join('static/reports', filename)
                full_path = os.path.join(reports_dir, filename)
                
                file.save(full_path)
        
        # Create health report record
        health_report = HealthReport(
            patient_id=int(patient_id),
            doctor_id=current_user.id,
            report_type=report_type,
            description=description,
            file_path=file_path,
            generated_at=datetime.utcnow()
        )
        
        db.session.add(health_report)
        db.session.commit()
        
        # Send notification email to patient
        try:
            if patient and patient.email:
                from ..services.email_service import send_email
                email_body = f"""
Dear {patient.full_name},

A new medical record has been created for you by Dr. {current_user.full_name}:

Record Type: {report_type}
Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}
Description: {description}

You can view and download this record in your patient dashboard under "Medical Records".

Best regards,
GemCare Healthcare System
                """
                send_email(
                    to_email=patient.email,
                    subject=f"New Medical Record: {report_type}",
                    body=email_body
                )
        except Exception as e:
            print(f"⚠️ Could not send health report notification: {e}")
        
        return jsonify({
            "status": "success",
            "message": "Medical record created successfully",
            "report_id": health_report.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": f"Error creating health report: {str(e)}"}), 500
```

**ENDPOINT 2: Get Patient Health Reports**

```python
@advanced_api.route('/patient-health-reports/<int:patient_id>', methods=['GET'])
@login_required
def get_patient_health_reports(patient_id):
    """Get all health reports for a patient"""
    try:
        # Verify requesting user is a doctor
        if current_user.role != 'doctor':
            return jsonify({"status": "error", "message": "Only doctors can access this"}), 403
        
        # Verify patient exists
        patient = User.query.get(patient_id)
        if not patient:
            return jsonify({"status": "error", "message": "Patient not found"}), 404
        
        # Check if doctor has access to this patient
        assignment = DoctorPatientAssignment.query.filter_by(
            doctor_id=current_user.id,
            patient_id=patient_id
        ).first()
        if not assignment:
            return jsonify({"status": "error", "message": "You don't have access to this patient's records"}), 403
        
        # Get all health reports for patient
        reports = HealthReport.query.filter_by(patient_id=patient_id).order_by(
            HealthReport.generated_at.desc()
        ).all()
        
        reports_data = []
        for report in reports:
            reports_data.append({
                'id': report.id,
                'report_type': report.report_type,
                'description': report.description,
                'file_path': report.file_path,
                'generated_at': report.generated_at.isoformat() if report.generated_at else None,
                'created_at': report.created_at.isoformat() if report.created_at else None,
                'doctor_name': User.query.get(report.doctor_id).full_name if report.doctor_id else 'Unknown'
            })
        
        return jsonify({
            "status": "success",
            "reports": reports_data,
            "count": len(reports_data)
        }), 200
        
    except Exception as e:
        return jsonify({"status": "error", "message": f"Error retrieving reports: {str(e)}"}), 500
```

---

## 4️⃣ Download Endpoint

### File: `/backend/routes/main.py`

**NEW ENDPOINT: Download Health Report**

```python
@main.route('/download-health-report/<int:report_id>')
@login_required
def download_health_report(report_id):
    """Download a health report file"""
    from flask import send_file
    import mimetypes
    
    # Get the health report
    health_report = HealthReport.query.get(report_id)
    if not health_report:
        return {'error': 'Report not found'}, 404
    
    # Check if user has permission (doctor who created it or patient who owns it)
    if current_user.role == 'patient' and health_report.patient_id != current_user.id:
        return {'error': 'Access denied'}, 403
    if current_user.role == 'doctor' and health_report.doctor_id != current_user.id:
        return {'error': 'Access denied'}, 403
    
    # If file_path exists, download the actual file
    if health_report.file_path:
        import os
        file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), health_report.file_path)
        if os.path.exists(file_path):
            filename = os.path.basename(file_path)
            return send_file(file_path, as_attachment=True, download_name=filename)
        else:
            return {'error': 'File not found on server'}, 404
    
    # Otherwise generate PDF from description
    import io
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    
    pdf_buffer = io.BytesIO()
    doc = SimpleDocTemplate(pdf_buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []
    
    story.append(Paragraph(f"<b>{health_report.report_type or 'Medical Report'}</b>", styles['Heading1']))
    story.append(Spacer(1, 0.2*letter[1]))
    story.append(Paragraph(health_report.description or 'No details available', styles['Normal']))
    
    doc.build(story)
    pdf_buffer.seek(0)
    
    return send_file(pdf_buffer, mimetype='application/pdf', 
                    as_attachment=True, 
                    download_name=f"HealthReport_{report_id}.pdf")
```

---

## 5️⃣ Frontend Error Handling

### File: `/backend/templates/doctor_dashboard_pro.html`

**IMPROVED: Medical Records Form Submission**

```javascript
// ========== MEDICAL RECORDS FORM ==========
document.getElementById('medicalRecordsForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const patientId = document.getElementById('carePatientSelect').value;
    const recordType = document.getElementById('recordType').value;
    const description = document.getElementById('recordDescription').value;
    const fileInput = document.getElementById('recordFile');

    if (!patientId) {
        alert('❌ Please select a patient first');
        return;
    }

    if (!recordType || !description) {
        alert('❌ Please fill in all required fields');
        return;
    }

    if (!fileInput.files.length) {
        alert('❌ Please attach a file (PDF or image)');
        return;
    }

    const file = fileInput.files[0];
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (file.size > maxSize) {
        alert('❌ File size must be less than 10MB');
        return;
    }

    const formData = new FormData();
    formData.append('patient_id', patientId);
    formData.append('report_type', recordType);
    formData.append('description', description);
    formData.append('file', file);

    // Send to backend - IMPROVED ERROR HANDLING
    fetch('/api/create-health-report', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        // Check if response is JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            throw new Error(`Server error (HTTP ${response.status}). The endpoint may not exist.`);
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'success') {
            alert('✓ Medical record created successfully!');
            document.getElementById('medicalRecordsForm').reset();
            loadPatientRecords(); // Refresh the records list
        } else {
            alert('❌ Error: ' + (data.message || 'Unknown error'));
        }
    })
    .catch(error => {
        console.error('Detailed error:', error);
        alert('❌ Error creating medical record:\n' + error.message);
    });
});
```

**IMPROVED: Load Patient Records Function**

```javascript
// ========== LOAD PATIENT RECORDS ==========
function loadPatientRecords() {
    const patientId = document.getElementById('carePatientSelect').value;
    if (!patientId) {
        document.getElementById('patientRecordsList').innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 2rem; color: #999;">Select a patient to view their medical records</td></tr>';
        return;
    }

    fetch(`/api/patient-health-reports/${patientId}`)
        .then(response => {
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error(`Server error (HTTP ${response.status})`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success' && data.reports && data.reports.length > 0) {
                let html = '';
                data.reports.forEach(report => {
                    const date = new Date(report.generated_at || report.created_at).toLocaleDateString();
                    html += `
                        <tr>
                            <td>${report.report_type || 'N/A'}</td>
                            <td>${date}</td>
                            <td>${report.description ? report.description.substring(0, 50) + '...' : 'N/A'}</td>
                            <td>
                                <a href="/download-health-report/${report.id}" class="btn btn-sm" style="background: var(--accent-green); color: white; padding: 0.3rem 0.8rem; text-decoration: none; border-radius: 4px; font-size: 0.85rem;">📥 Download</a>
                            </td>
                        </tr>
                    `;
                });
                document.getElementById('patientRecordsList').innerHTML = html;
            } else {
                document.getElementById('patientRecordsList').innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 2rem; color: #999;">No medical records for this patient yet</td></tr>';
            }
        })
        .catch(error => {
            console.error('Error loading records:', error);
            document.getElementById('patientRecordsList').innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 2rem; color: #d9534f;">⚠️ Error loading records. Check console for details.</td></tr>';
        });
}
```

---

## 📊 Summary of Changes

| File | Change Type | What Changed |
|------|-------------|--------------|
| `/backend/models.py` | Model Update | Added: doctor_id, description, created_at |
| `/backend/routes/advanced_api.py` | New Endpoints | Added: 2 API endpoints for CRUD operations |
| `/backend/routes/main.py` | New Endpoint | Added: 1 download endpoint |
| `/backend/templates/doctor_dashboard_pro.html` | Error Handling | Improved: JSON error handling in frontend |

---

## ✅ Verification

All changes are:
- ✅ Syntactically correct (no errors)
- ✅ Follow existing code patterns
- ✅ Include proper error handling
- ✅ Include security checks (permissions, file validation)
- ✅ Include email notifications
- ✅ Include audit logging

