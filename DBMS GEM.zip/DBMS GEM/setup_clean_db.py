import mysql.connector

# Read the SQL file
with open(r"d:\HARISH\DBMS GEM\database\combined_schema.sql", "r") as f:
    sql_content = f.read()

# Connect to MySQL
try:
    conn = mysql.connector.connect(user='root', host='localhost')
    cursor = conn.cursor()
    
    # Split by semicolon and execute each statement
    statements = sql_content.split(';')
    for statement in statements:
        stmt = statement.strip()
        # Skip empty statements and comments
        if stmt and not stmt.startswith('--') and not stmt.startswith('/*'):
            try:
                cursor.execute(stmt, multi=True)
                # Consume any results to avoid "Unread result" errors
                for result in cursor.fetchall():
                    pass
                conn.commit()
            except mysql.connector.errors.ProgrammingError as e:
                # Skip SELECT statements that return results
                if "SELECT" in stmt:
                    cursor.execute(stmt)
                    cursor.fetchall()
                else:
                    print(f"Warning: {e}")
            except Exception as e:
                print(f"Error: {e}")
    
    cursor.close()
    conn.close()
    print("✓ Database 'gemcare' created successfully with no default data")
except Exception as e:
    print(f"Connection error: {e}")
