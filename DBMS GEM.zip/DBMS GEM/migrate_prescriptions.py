#!/usr/bin/env python3
"""
Migration helper: Add simplified prescription fields to database
Run this script to automatically migrate the prescriptions table
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from backend import db, create_app
from sqlalchemy import text

def migrate_prescriptions():
    """Add new prescription fields to database"""
    app = create_app()
    
    with app.app_context():
        try:
            print("Starting prescription table migration...")
            
            # Check if columns already exist
            inspector = db.inspect(db.engine)
            columns = [col['name'] for col in inspector.get_columns('prescriptions')]
            
            missing_columns = []
            if 'medicine_name' not in columns:
                missing_columns.append('medicine_name')
            if 'dosage' not in columns:
                missing_columns.append('dosage')
            if 'frequency' not in columns:
                missing_columns.append('frequency')
            if 'duration' not in columns:
                missing_columns.append('duration')
            
            if not missing_columns:
                print("All prescription fields already exist!")
                return True
            
            print(f"Adding missing columns: {', '.join(missing_columns)}")
            
            # Read and execute migration SQL
            migration_file = os.path.join(os.path.dirname(__file__), 'database', 'migrate_prescriptions.sql')
            
            with open(migration_file, 'r') as f:
                sql_commands = f.read().split(';')
            
            for command in sql_commands:
                command = command.strip()
                if command:
                    try:
                        db.session.execute(text(command))
                        print(f"Executed: {command[:80]}...")
                    except Exception as e:
                        print(f"Command failed: {str(e)}")
                        # Continue with other commands
            
            db.session.commit()
            print("Migration completed successfully!")
            return True
            
        except Exception as e:
            db.session.rollback()
            print(f"Migration failed: {str(e)}")
            return False

if __name__ == '__main__':
    success = migrate_prescriptions()
    sys.exit(0 if success else 1)
