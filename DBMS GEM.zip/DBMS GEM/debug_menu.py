#!/usr/bin/env python
"""Debug patient dashboard menu structure"""

from backend.app import create_app
from backend.models import User
import re

app = create_app()

with app.app_context():
    patient = User.query.filter_by(role='patient').first()
    if patient:
        with app.test_client() as client:
            # Simulate login
            with client.session_transaction() as sess:
                sess['_user_id'] = patient.id
                sess['_fresh'] = True
            
            response = client.get('/dashboard')
            html = response.get_data(as_text=True)
            
            print('=== DEBUGGING PATIENT DASHBOARD MENU ===\n')
            
            # Extract menu items
            menu_pattern = r'<li><a[^>]*class="nav-link[^"]*"[^>]*data-section="([^"]+)"[^>]*>([^<]+)</a></li>'
            menu_items = re.findall(menu_pattern, html)
            
            print(f'Found {len(menu_items)} menu items:\n')
            for i, (section_id, label) in enumerate(menu_items, 1):
                print(f'{i}. {label}')
                print(f'   data-section: {section_id}')
                print()
            
            # Extract sections
            section_pattern = r'<section id="([^"]+)"[^>]*class="([^"]*)"'
            sections = re.findall(section_pattern, html)
            
            print(f'\nFound {len(sections)} sections:\n')
            for section_id, classes in sections:
                print(f'- {section_id}: class="{classes}"')
            
            # Check for showSection function
            if 'function showSection' in html:
                print('\n✅ showSection function is defined')
                
                # Extract function signature
                func_match = re.search(r'function showSection\(([^)]+)\)', html)
                if func_match:
                    print(f'   Signature: showSection({func_match.group(1)})')
                
                # Check for key functionality
                if "classList.remove('active')" in html:
                    print('   ✅ Has active class removal')
                if "classList.add('active')" in html:
                    print('   ✅ Has active class addition')
                if "getElementById" in html:
                    print('   ✅ Uses getElementById for section lookup')
            else:
                print('\n❌ showSection function NOT found!')
            
            # Check for event listeners
            if 'addEventListener' in html:
                print('\n✅ Event listeners are used in JavaScript')
            else:
                print('\n⚠️  No addEventListener found (using inline onclick)')
            
            # Check for data-section attributes
            if 'data-section=' in html:
                print('✅ Menu items have data-section attributes for event delegation')
            
            # Check CSS for section styling
            if '.section {' in html:
                print('\n✅ .section CSS class found')
                
                # Extract section CSS
                css_match = re.search(r'\.section\s*\{([^}]+)\}', html)
                if css_match:
                    css = css_match.group(1)
                    print(f'   CSS: {css.strip()}')
                    
                    if 'display: none' in css:
                        print('   ✅ Hidden by default (display: none)')
                
                # Extract active CSS
                active_match = re.search(r'\.section\.active\s*\{([^}]+)\}', html)
                if active_match:
                    active_css = active_match.group(1)
                    print(f'   Active CSS: {active_css.strip()}')
            else:
                print('\n❌ .section CSS class NOT found!')
            
            print('\n=== TEST COMPLETE ===')
