#!/usr/bin/env python
"""Test doctor-patient assignment workflow"""

from backend.app import create_app, db
from backend.models import User
from backend.models_extended import DoctorPatientAssignment

app = create_app()
with app.app_context():
    # First, create an assignment
    doctor_id = 1
    patient_id = 2
    
    # Check if already exists
    existing = DoctorPatientAssignment.query.filter_by(
        doctor_id=doctor_id,
        patient_id=patient_id,
        status='active'
    ).first()
    
    if not existing:
        assignment = DoctorPatientAssignment(
            doctor_id=doctor_id,
            patient_id=patient_id,
            is_primary=True,
            status='active'
        )
        db.session.add(assignment)
        db.session.commit()
        print('✓ Assignment created for testing')
    else:
        print('✓ Assignment already exists')
    
    # Now test the get-assigned-doctors logic
    assignments = DoctorPatientAssignment.query.filter_by(
        patient_id=patient_id,
        status='active'
    ).all()
    
    doctors = []
    for assign in assignments:
        doctor = assign.doctor
        doctor_profile = doctor.doctor_profile if hasattr(doctor, 'doctor_profile') else None
        doctors.append({
            'id': doctor.id,
            'name': doctor.full_name,
            'email': doctor.email,
            'specialization': doctor_profile.specialization if doctor_profile else 'Medical Professional'
        })
    
    print(f'✓ Found {len(doctors)} doctor assigned to patient {patient_id}:')
    for doc in doctors:
        print(f'  - Dr. {doc["name"]}, Specialty: {doc["specialization"]}')
    
    # Test get-assigned-patients logic
    patient_assignments = DoctorPatientAssignment.query.filter_by(
        doctor_id=doctor_id,
        status='active'
    ).all()
    
    patients = []
    for assign in patient_assignments:
        patient = assign.patient
        patients.append({
            'id': patient.id,
            'name': patient.full_name,
            'email': patient.email
        })
    
    print(f'\n✓ Found {len(patients)} patient assigned to doctor {doctor_id}:')
    for pat in patients:
        print(f'  - {pat["name"]} ({pat["email"]})')
