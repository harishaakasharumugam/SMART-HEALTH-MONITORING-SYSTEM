# GemCare Setup & Testing Guide

## Quick Start

### Step 1: Database Setup

1. **Create the new database:**
   ```sql
   CREATE DATABASE gemcare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

2. **Run the schema files** (in order):
   ```bash
   # Terminal in the workspace root
   cd database
   
   # Run the combined schema (includes all tables)
   mysql -u root < combined_schema.sql
   
   # Or run individually:
   mysql -u root < schema.sql
   mysql -u root < schema_extended.sql
   mysql -u root < insert_hospital_settings.sql
   ```

3. **Verify the database was created:**
   ```sql
   USE gemcare;
   SHOW TABLES;
   ```

### Step 2: Update Environment Variables

Verify `.env` file has the correct database configuration:
```
DATABASE_URL=mysql+mysqlconnector://root@localhost/gemcare
```

### Step 3: Start the Python Virtual Environment

```bash
# Activate the virtual environment
.venv\Scripts\Activate.ps1  # For PowerShell on Windows
source .venv/bin/activate   # For Linux/Mac terminal

# Or if using the setup activation from context
& "d:\HARISH\DBMS GEM\.venv\Scripts\Activate.ps1"
```

### Step 4: Start the Flask Application

```bash
# From workspace root
python run.py
```

You should see:
```
 * Running on http://127.0.0.1:5000
```

### Step 5: Access the Application

1. **Landing Page:**
   - Open: http://localhost:5000/
   - You should see the new professional landing page

2. **Login:**
   - Click "Login" button
   - URL: http://localhost:5000/login
   - New professional login form with role selection

3. **Signup:**
   - Click "Sign Up" button  
   - URL: http://localhost:5000/signup
   - New professional signup form

---

## Testing Checklist

### Database Connection
```python
# Test in Python
from backend.app import create_app, db

app = create_app()
with app.app_context():
    result = db.session.execute('SELECT DATABASE()')
    print(f"Current database: {result.fetchone()}")
    # Should print: Current database: gemcare
```

### Frontend Testing

#### Landing Page (/)
- [ ] Navigation bar displays correctly
- [ ] Logo shows with GemCare branding
- [ ] Hero section loads
- [ ] All sections visible (Features, Booking, About, Services, Doctors, FAQ)
- [ ] Links in footer work
- [ ] Responsive on mobile (resize browser)

#### Login Page (/login)
- [ ] Page loads with professional design
- [ ] Role selector works (click Patient, Doctor, Caregiver)
- [ ] Form fields present (username, password)
- [ ] Login button functional
- [ ] Sign up link works
- [ ] Mobile responsive

#### Signup Page (/signup)
- [ ] Page loads with new design
- [ ] Progress indicator shows (1. Role Selection, 2. Your Details, 3. Confirmation)
- [ ] Role selection functional
- [ ] All form fields present
- [ ] Password strength indicator updates as you type
- [ ] Form submission works
- [ ] Mobile responsive

### Feature Testing

#### Patient Dashboard
- [ ] Loads after login
- [ ] Shows patient's vital signs
- [ ] Displays health score
- [ ] Shows recommendations
- [ ] All navigation links work

#### Doctor Dashboard
- [ ] Loads after doctor login
- [ ] Shows patient list
- [ ] Displays alerts
- [ ] All features accessible

#### Caregiver Dashboard
- [ ] Loads after caregiver login
- [ ] Shows linked patient info
- [ ] All caregiver features work

---

## Database Schema Verification

Run these queries to verify the database setup:

```sql
-- Check database exists
SHOW DATABASES LIKE 'gemcare';

-- Check all tables
USE gemcare;
SHOW TABLES;
SHOW TABLE STATUS;

-- Count tables
SELECT COUNT(*) as total_tables FROM information_schema.TABLES WHERE table_schema = 'gemcare';

-- List table names
SELECT TABLE_NAME FROM information_schema.TABLES WHERE table_schema = 'gemcare' ORDER BY TABLE_NAME;
```

Expected tables (13+):
- users
- patient_profiles
- patient_extended_profiles
- doctor_profiles
- vital_signs
- health_scores
- recommendations
- appointments
- consultation_notes
- treatment_plans
- lab_tests
- lab_orders
- lab_results
- medical_documents
- hospital_settings
- departments
- email_logs
- caregie assignments
- prescriptions
- medicines
- alerts

---

## Troubleshooting

### Issue: "Unknown database 'gemcare'"
**Solution:**
```sql
CREATE DATABASE gemcare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
mysql -u root gemcare < database/combined_schema.sql
```

### Issue: "Flask application won't connect to database"
**Solution:**
1. Verify MySQL is running
2. Check .env file has correct DATABASE_URL
3. Verify gemcare database exists
4. Check tables were created: `SHOW TABLES;`

### Issue: "Old pages still showing"
**Solution:**
1. Clear browser cache (Ctrl+F5)
2. Clear Flask cache
3. Restart Flask application
4. Check routes point to `_new.html` files

### Issue: "Styles not loading on new pages"
**Solution:**
1. Check CSS file path: `url_for('static', filename='css/...')`
2. Verify CSS files exist
3. Clear browser cache
4. Check Flask static folder configuration

### Issue: "Password mismatch in signup"
**Solution:**
- Ensure password and confirm_password fields match
- Check form has required attribute

---

## Environmental Setup Verification

```bash
# Check Python version
python --version
# Should be 3.8+

# Check virtual environment is active
# Prompt should show (.venv) or full path to venv

# Check required packages
pip list | findstr Flask
pip list | findstr SQLAlchemy
pip list | findstr mysql-connector

# Expected output
Flask==2.3.3
Flask-SQLAlchemy==3.1.1
mysql-connector-python==8.1.0
```

---

## API Testing (Optional)

To test the API endpoints:

```bash
# Test database connection endpoint (if available)
curl http://localhost:5000/api/health

# Test user login
curl -X POST http://localhost:5000/login \
  -d "username=testuser&password=testpass&role=patient"
```

---

## Performance Tips

1. **Optimize Database**
   - Add indexes on frequently queries fields
   - Run ANALYZE TABLE after data insertion
   - Monitor query performance

2. **Optimize Frontend**
   - Minify CSS/JS in production
   - Cache static assets
   - Optimize images
   - Use CDN for large assets

3. **Application Optimization**
   - Enable database connection pooling
   - Cache frequently accessed data
   - Use pagination for large datasets

---

## Documentation

For detailed documentation, see:
- `GEMCARE_REDESIGN_SUMMARY.md` - Complete redesign details
- `IMPLEMENTATION_GUIDE.md` - Original implementation guide
- `QUICK_START_GUIDE.md` - Original quick start
- Database README files in `/database` folder

---

## Support & Contact

- Email: harisharumugam35@gmail.com
- Application: GemCare Healthcare Management System
- Database: gemcare (MySQL)
- Version: 2.0 (Redesign)

---

**Last Updated:** April 2026
