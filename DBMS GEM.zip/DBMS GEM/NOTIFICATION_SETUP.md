# Email & SMS Notification System

## Overview
The system now automatically sends **professional HTML emails** with PDF attachments and **SMS messages** to patients when health reports are generated.

## Features

### 📧 Email Notifications
- **Professional HTML formatted emails** with HAPPY HEAL branding
- **PDF report attachment** included automatically
- **Styled sections** with colors and formatting
- **Next steps** and recommendations
- **Medical disclaimer** footer

### 📱 SMS Notifications
- **Instant SMS notification** when report is ready
- **Patient-friendly message** with quick summary
- **Uses Twilio** (optional) or operates in fallback mode
- **Logs all SMS attempts** for audit trail

---

## Configuration

### 1. Email Setup (Already Configured)

The system uses **Gmail SMTP** with the following settings:

```
SENDER_EMAIL=email.alert_tutorial@gmail.com
SENDER_PASSWORD=hkjbkylfubdistde
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
```

These credentials are stored in `.env` file.

### 2. SMS Setup (Optional - Twilio)

SMS is **optional**. If Twilio is not configured, the system will:
- Log SMS details locally
- Continue without interruption
- No errors thrown

To enable Twilio SMS:

1. **Create Twilio Account**: https://www.twilio.com
2. **Get Your Credentials**:
   - Account SID
   - Auth Token
   - Twilio Phone Number (e.g., +1234567890)

3. **Update `.env` file**:
```
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_token_here
TWILIO_PHONE_NUMBER=+1234567890
```

4. **Install Twilio Python Library**:
```bash
pip install twilio==8.10.0
```

---

## How It Works

### When Report is Generated

```
POST /api/generate-report
    ↓
1. Generate PDF Report
    ↓
2. Save to Database
    ↓
3. Send Email Notification
    ├─ Check if email exists
    ├─ Format HTML email
    ├─ Attach PDF
    └─ Send via Gmail SMTP
    ↓
4. Send SMS Notification
    ├─ Check if phone exists
    ├─ Format message
    ├─ Send via Twilio (or log)
    └─ Return status
    ↓
5. Return Response with Notification Status
```

### Response Example

```json
{
  "status": "success",
  "file_path": "static/reports/JohnDoe_2026-03-04.pdf",
  "notifications": {
    "email_sent": true,
    "sms_sent": true,
    "message": "Report generated and notifications sent successfully"
  }
}
```

---

## Patient Email Template

The email includes:

```
┌─────────────────────────────────────┐
│ 🏥 HAPPY HEAL                       │ ← Blue Header
│ Smart Health Monitoring System      │
└─────────────────────────────────────┘
│                                     │
│ Hello [Patient Name],               │ ← Personalized greeting
│                                     │
│ Your comprehensive health report    │ ← Body message
│ has been generated...               │
│                                     │
│ 📋 Report Details:                  │ ← Key info
│ Generated: [Date & Time]            │
│                                     │
│ Next Steps:                         │ ← Guidance
│ • Review your report                │
│ • Follow recommendations            │
│ • Schedule doctor visit             │
│ • Continue monitoring               │
│                                     │
│ ⚠️ Important Note: [Disclaimer]    │ ← Legal notice
│                                     │
├─────────────────────────────────────┤
│ © 2026 HAPPY HEAL                   │
│ Contact: support@happyheal.com      │
└─────────────────────────────────────┘
```

**Attachment**: PDF file automatically included

---

## SMS Message

```
Hi [FirstName], your health report from HAPPY HEAL has been generated. 
Check your email for the detailed PDF report. Stay healthy!
```

**Max Length**: Fits within SMS character limit (160 characters)

---

## Database Requirements

Ensure patient records have:

```sql
users table:
- email (VARCHAR, NOT NULL)
- phone (VARCHAR, OPTIONAL)
```

Users must have **email address** for email notification.
Users must have **phone number** for SMS notification.

---

## Troubleshooting

### Email Not Sending

**Check:**
1. Patient has valid email address
2. SMTP credentials in `.env` are correct
3. Gmail account has "Less secure app access" enabled
   - Go to: https://myaccount.google.com/lesssecureapps
   - Enable "Allow less secure apps"
4. Check console logs for error messages

**Error**: `SMTPAuthenticationError`
- Solution: Update SENDER_PASSWORD in `.env`

**Error**: `SMTPException: SMTP AUTH extension not supported by server`
- Solution: Ensure port 587 is used (not 465 or 25)

### SMS Not Sending

**If Twilio Not Configured:**
- SMS logs locally instead
- Check console for `[SMS LOG]` entries

**If Twilio Configured:**
1. Verify Account SID and Auth Token
2. Check Twilio phone number format (+1XXXXXXXXXX)
3. Check patient has valid phone number
4. Verify account has credits

**Error**: `TwilioRestException`
- Solution: Check Twilio console for account issues

---

## Testing

### Test Email Only
```python
from backend.services.notifier import send_email_alert

send_email_alert(
    recipient_email="test@example.com",
    subject="Test Email",
    body="This is a test",
    attachment_path="path/to/pdf.pdf",
    patient_name="John Doe"
)
```

### Test SMS Only
```python
from backend.services.notifier import trigger_sms_alert

trigger_sms_alert(
    phone_number="+1234567890",
    message="Test SMS from HAPPY HEAL"
)
```

### Test Full Report Notification
```bash
# Make POST request to generate-report endpoint
curl -X POST http://localhost:5000/api/generate-report \
  -H "Content-Type: application/json"
```

---

## Security Notes

⚠️ **Important Security Measures:**

1. **API Key Protection**
   - `.env` file is in `.gitignore`
   - Never commit credentials to Git
   - Use secure environment variables in production

2. **Email Security**
   - Credentials stored encrypted in environment
   - No plaintext passwords in code
   - Use app-specific passwords (not main Gmail password)

3. **SMS Security**
   - Twilio credentials protected
   - API accessible only to authenticated backend
   - No SMS exposure in frontend

4. **Production Deployment**
   - Use AWS Secrets Manager or similar
   - Rotate credentials regularly
   - Enable MFA on email/SMS accounts

---

## Advanced Configuration

### Custom Email Templates

To customize email HTML, edit the `send_email_alert()` function in:
```
backend/services/notifier.py (lines 35-75)
```

### SMS Message Customization

Edit `send_report_notification()` function in:
```
backend/services/notifier.py (lines 146-151)
```

### Change SMTP Server

For different email providers:
```python
# Gmail
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

# Outlook
SMTP_SERVER = "smtp.outlook.com"
SMTP_PORT = 587

# Custom SMTP
SMTP_SERVER = "mail.yourdomain.com"
SMTP_PORT = 587
```

---

## Performance

### Email
- Synchronous (user waits ~2-3 seconds)
- For async: Consider adding Celery/Redis

### SMS
- Synchronous via Twilio API (~1-2 seconds)
- Fallback logging is instant

### Optimization
```bash
# To add async processing (optional)
pip install celery redis
```

---

## Monitoring & Logs

### Check SMS Logs
```bash
# All [SMS LOG] entries in console output
tail -f app.log | grep "SMS LOG"
```

### Check Email Status
```bash
# All [Email] entries in console output
tail -f app.log | grep "Email"
```

### Database Tracking
Reports are stored in:
```sql
SELECT * FROM health_reports WHERE patient_id = X;
```

---

## Support

For issues:
1. Check console logs
2. Review `.env` configuration
3. Verify patient email/phone fields are populated
4. Test endpoints individually
5. Check service credentials (Twilio/Gmail)
