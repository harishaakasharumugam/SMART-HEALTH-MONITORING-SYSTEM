#!/usr/bin/env python3

# Read from combined_schema.sql
with open(r'd:\HARISH\DBMS GEM\database\combined_schema.sql', 'r', encoding='utf-8') as f:
    content = f.read()

# Write to schema.sql (overwrite)
with open(r'd:\HARISH\DBMS GEM\database\schema.sql', 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ schema.sql has been updated with complete database code (40 tables)")
print("✓ File synchronized with combined_schema.sql")
