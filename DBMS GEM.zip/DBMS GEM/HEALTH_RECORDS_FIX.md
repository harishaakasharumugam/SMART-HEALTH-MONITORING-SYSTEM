# Medical Records Feature - Setup & Troubleshooting Guide

## 🔴 Problem Identified

**Error Message:**
```
SyntaxError: Unexpected token '<', "<!doctype "... is not valid JSON
```

**Root Cause:**
The frontend was trying to call `/api/create-health-report` endpoint which **didn't exist**. When a non-existent route is called, Flask returns a 404 HTML error page instead of JSON, causing the JSON parser to fail.

---

## ✅ What Was Fixed

### 1. **Backend Endpoints Created**

Two new API endpoints were added to `/backend/routes/advanced_api.py`:

#### Endpoint 1: Create Medical Record
```
POST /api/create-health-report
```
- Accepts: FormData (not JSON) with file upload
- Fields: `patient_id`, `report_type`, `description`, `file` (optional)
- Returns: JSON response with success status
- Stores: File uploaded to `/backend/static/reports/`
- Database: Saves record to `health_reports` table

#### Endpoint 2: Get Patient Records
```
GET /api/patient-health-reports/{patient_id}
```
- Returns: All health reports for a patient
- JSON array with: id, report_type, description, file_path, generated_at, doctor_name
- Used to populate the Medical Records table

#### Endpoint 3: Download Report File
```
GET /download-health-report/{report_id}
```
- Allows download of uploaded files
- Supports: PDF, JPG, PNG formats
- Generates PDF if no file uploaded
- Permission: Doctor who created it or patient who owns it

### 2. **Database Model Updated**

Updated `HealthReport` model in `/backend/models.py`:

**Before:**
```python
class HealthReport(db.Model):
    id = db.Column(...)
    patient_id = db.Column(...)
    report_type = db.Column(...)
    file_path = db.Column(...)
    generated_at = db.Column(...)
```

**After:**
```python
class HealthReport(db.Model):
    id = db.Column(...)
    patient_id = db.Column(...)
    doctor_id = db.Column(...)              # NEW: Track creator
    report_type = db.Column(...)
    description = db.Column(db.Text)       # NEW: Store description
    file_path = db.Column(...)
    generated_at = db.Column(...)
    created_at = db.Column(...)              # NEW: Track creation time
```

### 3. **Frontend Error Handling Improved**

Enhanced error handling in `doctor_dashboard_pro.html`:

**Before:**
```javascript
fetch('/api/create-health-report', {...})
    .then(response => response.json())  // ❌ Fails if response is HTML
```

**After:**
```javascript
fetch('/api/create-health-report', {...})
    .then(response => {
        // ✅ Check if response is JSON before parsing
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            throw new Error(`Server error (HTTP ${response.status})`);
        }
        return response.json();
    })
    .catch(error => {
        console.error('Detailed error:', error);
        alert('❌ Error:\n' + error.message);
    })
```

---

## 🗄️ Database Setup Required

### Step 1: Apply Database Migration

Choose ONE of the following methods:

#### Method A: Automatic Migration (if using Flask-Migrate)
```bash
cd "d:\HARISH\DBMS GEM"
python migrate_health_reports.py
```

#### Method B: Manual SQL Migration
```bash
mysql -u root -p your_database_name < database/migrate_health_reports.sql
```

#### Method C: Direct MySQL Commands
Open MySQL client and run:
```sql
ALTER TABLE health_reports 
ADD COLUMN IF NOT EXISTS doctor_id INT UNSIGNED AFTER patient_id,
ADD COLUMN IF NOT EXISTS description LONGTEXT AFTER report_type,
ADD COLUMN IF NOT EXISTS created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER generated_at;

CREATE INDEX idx_health_reports_patient ON health_reports(patient_id);
CREATE INDEX idx_health_reports_doctor ON health_reports(doctor_id);
CREATE INDEX idx_health_reports_created ON health_reports(created_at);
```

### Step 2: Verify Database Changes

Run in MySQL:
```sql
DESCRIBE health_reports;
```

Should show columns:
- ✅ id
- ✅ patient_id
- ✅ doctor_id (NEW)
- ✅ report_type
- ✅ description (NEW)
- ✅ file_path
- ✅ generated_at
- ✅ created_at (NEW)

---

## 📂 File System Setup Required

### Create Reports Directory

The application needs a directory to store uploaded files:

```bash
# If not exists, create it:
mkdir -p "d:\HARISH\DBMS GEM\backend\static\reports"

# Or from Python:
import os
os.makedirs('backend/static/reports', exist_ok=True)
```

**Ensure directory permissions:**
- Windows: Right-click → Properties → Security → Full Control
- Linux/Mac: `chmod 755 backend/static/reports`

---

## 🚀 Testing the Fix

### Test 1: Create Medical Record

1. Start the application: `python run.py`
2. Login as doctor: http://127.0.0.1:5000/
3. Go to **Dashboard → Patient Care**
4. Select a patient
5. Click **📄 Medical Records** tab
6. Fill the form:
   - Record Type: "Lab Report"
   - Description: "Blood test complete"
   - Attach File: Select a PDF or JPG
7. Click **✓ Create Medical Record**

**Expected Result:**
- ✅ Alert: "Medical record created successfully!"
- ✅ Record appears in table below
- ✅ File saved to `/backend/static/reports/`
- ✅ Database record created

### Test 2: Download Medical Record

1. In records table, click **📥 Download**
2. File should download

**Expected Result:**
- ✅ File downloads with correct name
- ✅ No errors in console

### Test 3: Load Patient Records

1. Switch selected patient
2. Records table should update automatically

**Expected Result:**
- ✅ Different records show for different patients
- ✅ No console errors

### Test 4: Response Time

If response is slow (> 5 seconds):

**Causes & Solutions:**
```
Issue: File upload slow
Solution: Check file size (should be < 10MB)
         Check disk write speed
         Check network bandwidth

Issue: Database query slow
Solution: Enable query indexing (already in migration)
         Check if indexes are created

Issue: Network latency
Solution: Check browser Network tab (F12 → Network)
         Should see POST request to /api/create-health-report
         Response time in console
```

---

## 🔍 Troubleshooting

### Issue 1: "404 Not Found"

**Symptoms:** Getting HTML 404 page

**Causes & Solutions:**
```
1. Endpoint not registered
   → Check: /backend/routes/advanced_api.py
   → Verify: @advanced_api.route('/create-health-report') exists
   → Fix: Restart server after code changes

2. Wrong URL in frontend
   → Check: doctor_dashboard_pro.html line ~1453
   → Should be: fetch('/api/create-health-report', ...)
   → Should NOT be: fetch('create-health-report', ...)

3. Blueprint not registered
   → Check: /backend/app.py
   → Verify: app.register_blueprint(advanced_api)
   → Fix: Add if missing and restart
```

### Issue 2: "File size exceeds 10MB limit"

**Solution:** Check file size before uploading
```javascript
// In browser console:
document.getElementById('recordFile').files[0].size // bytes
```

### Issue 3: "Permission denied" when saving file

**Symptoms:** Error message or 500 error

**Causes & Solutions:**
```
1. Directory doesn't exist
   → Fix: mkdir -p backend/static/reports

2. Directory not writable
   → Windows: Right-click folder → Properties → Security
   → Linux: chmod 755 backend/static/reports

3. Flask process permission issue
   → Try: Run as Administrator (Windows)
   → Or: Run with higher privileges (Linux)
```

### Issue 4: "Database error"

**Symptoms:** "Error creating medical record" message

**Causes & Solutions:**
```
1. Columns don't exist
   → Fix: Run migration script
   → Verify: DESCRIBE health_reports;

2. Foreign key constraint
   → Check: doctor_id valid
   → Check: patient_id exists
   → Fix: Run migration without FK first

3. Connection pool exhausted
   → Restart Flask application
   → Close other open connections
```

### Issue 5: Slow Response Time (> 5 seconds)

**Debugging Steps:**

1. **Check Server Logs:**
```bash
# In terminal running "python run.py"
# Look for timing information
```

2. **Check Network Tab:**
```
Browser F12 → Network tab → Click "Create Medical Record"
Look at:
- Request time: POST /api/create-health-report
- Response time (should be < 2 seconds)
- File upload speed
```

3. **Check Database:**
```sql
-- Test query speed
SELECT COUNT(*) FROM health_reports;
SELECT * FROM health_reports WHERE doctor_id = 1 LIMIT 1;
```

4. **Check File I/O:**
```bash
# On Windows - Check disk write speed
# On Linux - Check disk usage: df -h
```

**Solutions for Slow Performance:**
```
1. Reduce file size
2. Check disk space (should be > 1GB free)
3. Check available RAM (should be > 500MB free)
4. Disable virus scanner temporarily during upload
5. Move reports folder to faster disk
6. Enable database query caching
```

---

## 📊 Files Modified/Created

### Modified Files:
1. ✅ `/backend/models.py` - Added fields to HealthReport
2. ✅ `/backend/routes/advanced_api.py` - Added 2 new endpoints
3. ✅ `/backend/routes/main.py` - Added download endpoint
4. ✅ `/backend/templates/doctor_dashboard_pro.html` - Improved error handling

### Created Files:
1. ✅ `/database/migrate_health_reports.sql` - Database migration
2. ✅ `/migrate_health_reports.py` - Python migration helper
3. ✅ `/HEALTH_RECORDS_FIX.md` - This guide

### Directory Created:
1. ✅ `/backend/static/reports/` - File storage (create if missing)

---

## 📋 Setup Checklist

- [ ] Database migration applied (columns added)
- [ ] `/backend/static/reports/` directory created
- [ ] Directory has write permissions
- [ ] Flask server restarted
- [ ] Tested Create Medical Record
- [ ] Tested Download Record
- [ ] Tested Load Records for different patients
- [ ] No console errors
- [ ] Response time acceptable (< 5 seconds)

---

## 🎯 Next Steps

1. **Verify Database:** Check that all columns exist
2. **Test Creation:** Try creating a medical record
3. **Check Logs:** Monitor console for errors
4. **Monitor Performance:** Check response times
5. **Test Patient View:** Verify patient can see records

---

## 📞 Support Commands

### Check if endpoints are registered:
```python
# In Python shell:
from backend import create_app
app = create_app()
print([rule for rule in app.url_map.iter_rules() if 'health-report' in str(rule)])
```

### Test endpoint directly:
```bash
# Using curl:
curl -X GET http://127.0.0.1:5000/api/patient-health-reports/1
curl -X POST http://127.0.0.1:5000/api/create-health-report -F "patient_id=1" -F "report_type=Test"
```

### Enable debug mode:
```python
# In run.py:
if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

