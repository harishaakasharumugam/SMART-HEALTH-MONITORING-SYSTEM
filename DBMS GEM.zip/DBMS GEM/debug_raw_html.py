#!/usr/bin/env python
"""Check actual rendered HTML including onclick handlers"""

from backend.app import create_app
from backend.models import User

app = create_app()

with app.app_context():
    patient = User.query.filter_by(role='patient').first()
    if patient:
        with app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = patient.id
                sess['_fresh'] = True
            
            response = client.get('/dashboard')
            html = response.get_data(as_text=True)
            
            # Find the first menu item
            import re
            first_link = re.search(r'<li><a.*?onclick="([^"]+)".*?>([^<]+)</a></li>', html)
            if first_link:
                print("FIRST MENU ITEM HTML:")
                print(f"Onclick: {first_link.group(1)}")
                print(f"Label: {first_link.group(2)}")
                print()
            
            # Check for switchSection function
            func_search = re.search(r'function switchSection\((.*?)\)', html)
            if func_search:
                print(f"✅ switchSection function found")
                print(f"   Parameters: {func_search.group(1)}")
            else:
                print("❌ switchSection function NOT found")
            
            # Look for the actual function definition
            func_def = re.search(r'function switchSection\(.*?\) \{(.*?)\n        \}', html, re.DOTALL)
            if func_def:
                func_body = func_def.group(1)[:300]
                print(f"\n   Function body (first 300 chars):\n   {func_body}")
            
            # Check sections
            sections = re.findall(r'<section id="([^"]+)"', html)
            print(f"\n✅ Found {len(sections)} sections: {sections}")
            
            # Simple test - extract small part around first section
            first_section = re.search(r'<section id="overview"[^>]*class="([^"]*)"', html)
            if first_section:
                print(f"\n✅ Overview section class: {first_section.group(1)}")
            
            # Check for basic HTML issues
            if '<html' not in html.lower():
                print("\n⚠️  HTML document doesn't start with <html>")
            if '</html>' not in html.lower():
                print("⚠️  HTML document doesn't end with </html>")
            
            print(f"\n📊 Total HTML size: {len(html)} bytes")
