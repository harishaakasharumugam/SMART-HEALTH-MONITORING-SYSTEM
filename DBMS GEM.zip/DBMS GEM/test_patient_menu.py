#!/usr/bin/env python
"""Test patient dashboard menu structure"""

from backend.app import create_app
from backend.models import User
import re

app = create_app()

with app.app_context():
    patient = User.query.filter_by(role='patient').first()
    if patient:
        with app.test_client() as client:
            # Simulate login
            with client.session_transaction() as sess:
                sess['_user_id'] = patient.id
                sess['_fresh'] = True
            
            response = client.get('/dashboard')
            html = response.get_data(as_text=True)
            
            print('=== PATIENT DASHBOARD MENU TEST ===\n')
            print(f'Dashboard Status: {response.status_code}')
            
            if 'function showSection(sectionId, clickedElement)' in html:
                print('✅ showSection function has clickedElement parameter')
            else:
                print('❌ showSection function NOT properly updated')
            
            # Count onclick patterns
            onclick_pattern = r'onclick="showSection\([^)]+,\s*this\)"'
            onclick_count = len(re.findall(onclick_pattern, html))
            print(f'✅ Menu items with fixed onclick: {onclick_count}/8')
            
            # Check specific menu items
            menu_items = ['overview', 'vitals', 'appointments', 'prescriptions', 'records', 'messages', 'digital-twin', 'profile']
            for item in menu_items:
                if f"onclick=\"showSection('{item}', this)\"" in html or f'onclick="showSection(\'{item}\', this)"' in html:
                    print(f'  ✅ {item} menu item configured correctly')
                else:
                    print(f'  ❌ {item} menu item NOT configured')
            
            print('\nAll menu items should be clickable now!')
