# Professional Hospital Theme - Developer Reference Guide

## Quick Reference

This guide provides developers with quick access to the professional hospital theme CSS classes and components.

---

## Color Variables

Use these CSS variables for consistent theming:

```css
--hospital-blue: #003366          /* Primary brand color */
--hospital-blue-dark: #002449     /* Darker shade */
--hospital-blue-light: #004d99    /* Lighter shade */
--medical-green: #00A86B          /* Action/CTA color */
--medical-green-dark: #008a52     /* Hover state */
--medical-green-light: #00c87d    /* Highlight color */
--professional-gray: #F5F5F5      /* Background color */
--gray-light: #E0E0E0             /* Borders */
--gray-medium: #999999            /* Secondary text */
--gray-dark: #666666              /* Body text */
--accent-orange: #FF8C42          /* Alerts/Warnings */
--accent-red: #E74C3C             /* Errors/Danger */
--accent-yellow: #F39C12          /* Warnings */
--text-dark: #2C3E50              /* Primary text */
--text-light: #666666             /* Secondary text */
```

### Usage Example

```css
.my-component {
    color: var(--text-dark);
    background: var(--professional-gray);
    border: 2px solid var(--medical-green);
}
```

---

## Button Classes

### Primary Button (Medical Green)
```html
<button class="btn btn-primary">Submit</button>
```

**Variations:**
```html
<!-- Small -->
<button class="btn btn-primary btn-small">Small Button</button>

<!-- Large -->
<button class="btn btn-primary btn-large">Large Button</button>

<!-- Full Width -->
<button class="btn btn-primary btn-full">Full Width Button</button>

<!-- Disabled -->
<button class="btn btn-primary" disabled>Disabled</button>
```

### Secondary Button (Hospital Blue)
```html
<a href="/dashboard" class="btn btn-secondary">Dashboard</a>
```

### Outline Button
```html
<button class="btn btn-outline">Cancel</button>
```

### Danger Button (Red)
```html
<button class="btn btn-danger">Delete</button>
```

### Warning Button (Orange)
```html
<button class="btn btn-warning">Confirm</button>
```

### Success Button (Green)
```html
<button class="btn btn-success">Approve</button>
```

---

## Form Components

### Basic Form Group
```html
<div class="form-group">
    <label for="email">Email Address</label>
    <input type="email" id="email" name="email" placeholder="Enter your email" required>
    <small class="form-help">We'll never share your email</small>
</div>
```

### Form with Validation
```html
<div class="form-group">
    <label for="password">Password</label>
    <input type="password" id="password" name="password" class="is-valid" required>
    <small class="form-error">{{ error_message }}</small>
</div>
```

### Select Dropdown
```html
<div class="form-group">
    <label for="role">User Role</label>
    <select id="role" name="role" required>
        <option value="">Select role...</option>
        <option value="patient">Patient</option>
        <option value="doctor">Doctor</option>
        <option value="admin">Admin</option>
    </select>
</div>
```

### Checkbox & Radio
```html
<div class="form-group">
    <div style="display: flex; gap: 1rem;">
        <label style="margin: 0; display: flex; gap: 0.5rem;">
            <input type="checkbox" name="remember" value="1">
            Remember me
        </label>
    </div>
</div>
```

### Textarea
```html
<div class="form-group">
    <label for="notes">Medical Notes</label>
    <textarea id="notes" name="notes" placeholder="Enter clinical notes..." required></textarea>
</div>
```

---

## Card Component

### Basic Card
```html
<div class="card">
    <div class="card-body">
        <p class="card-text">Basic card content</p>
    </div>
</div>
```

### Card with Header
```html
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Patient Information</h3>
    </div>
    <div class="card-body">
        <p>Card content goes here</p>
    </div>
</div>
```

### Card with Footer
```html
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Report</h3>
    </div>
    <div class="card-body">
        <p>Report details</p>
    </div>
    <div class="card-footer">
        <button class="btn btn-primary btn-small">Download</button>
    </div>
</div>
```

---

## Alert Component

### Success Alert
```html
<div class="alert alert-success">
    ✓ Patient record created successfully!
    <span class="alert-close">&times;</span>
</div>
```

### Danger Alert
```html
<div class="alert alert-danger">
    ✗ Failed to update prescription. Please try again.
    <span class="alert-close">&times;</span>
</div>
```

### Warning Alert
```html
<div class="alert alert-warning">
    ⚠ Drug interaction detected. Review before prescribing.
    <span class="alert-close">&times;</span>
</div>
```

### Info Alert
```html
<div class="alert alert-info">
    ℹ Lab results are now available for review.
    <span class="alert-close">&times;</span>
</div>
```

---

## Badge Component

### Color Variants
```html
<span class="badge badge-primary">Active</span>
<span class="badge badge-secondary">Secondary</span>
<span class="badge badge-success">Success</span>
<span class="badge badge-danger">Critical</span>
<span class="badge badge-warning">Pending</span>
<span class="badge badge-info">Info</span>
```

### Usage Examples
```html
<!-- Patient Status -->
<div>
    Status: <span class="badge badge-success">Stable</span>
</div>

<!-- Prescription Status -->
<div>
    Prescription: <span class="badge badge-warning">Pending</span>
</div>

<!-- Alert Level -->
<div>
    Alert: <span class="badge badge-danger">Critical</span>
</div>
```

---

## Table Component

### Basic Table
```html
<table class="table">
    <thead>
        <tr>
            <th>Patient Name</th>
            <th>Date</th>
            <th>Vital Signs</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>John Doe</td>
            <td>2024-01-15</td>
            <td>120/80 mmHg</td>
            <td><button class="btn btn-small btn-primary">View</button></td>
        </tr>
    </tbody>
</table>
```

---

## Modal Component

### Modal Trigger & Content
```html
<!-- Trigger Button -->
<button class="btn btn-primary" onclick="openModal('PatientModal')">Add Patient</button>

<!-- Modal -->
<div id="PatientModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title">Add New Patient</h2>
            <button class="modal-close" onclick="closeModal('PatientModal')">&times;</button>
        </div>
        <div class="modal-body">
            <!-- Form content -->
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="closeModal('PatientModal')">Cancel</button>
            <button class="btn btn-primary">Save Patient</button>
        </div>
    </div>
</div>
```

### JavaScript Functions
```javascript
function openModal(id) {
    document.getElementById(id).classList.add('show');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}

// Close on outside click
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('show');
    }
}
```

---

## Layout Classes

### Container
```html
<div class="container">
    <!-- Max-width: 1200px, centered with padding -->
</div>
```

### Grid System
```html
<div class="row">
    <div class="col">Column 1</div>
    <div class="col">Column 2</div>
    <div class="col">Column 3</div>
</div>
```

---

## Spacing Utilities

### Margin Classes
```html
<!-- Top margin -->
<div class="mt-1">Margin-top: 0.5rem</div>
<div class="mt-2">Margin-top: 1rem</div>
<div class="mt-3">Margin-top: 1.5rem</div>
<div class="mt-4">Margin-top: 2rem</div>
<div class="mt-5">Margin-top: 3rem</div>

<!-- Bottom margin -->
<div class="mb-1">Margin-bottom: 0.5rem</div>
<div class="mb-2">Margin-bottom: 1rem</div>
<div class="mb-3">Margin-bottom: 1.5rem</div>
```

### Padding Classes
```html
<div class="p-1">Padding: 0.5rem</div>
<div class="p-2">Padding: 1rem</div>
<div class="p-3">Padding: 1.5rem</div>
<div class="p-4">Padding: 2rem</div>
```

---

## Text Utilities

### Text Alignment
```html
<p class="text-left">Left aligned text</p>
<p class="text-center">Center aligned text</p>
<p class="text-right">Right aligned text</p>
```

### Text Colors
```html
<p class="text-muted">Muted text</p>
<p class="text-success">Success text</p>
<p class="text-danger">Danger text</p>
<p class="text-warning">Warning text</p>
<p class="text-info">Info text</p>
```

### Text Utilities
```html
<p class="hidden">This is hidden</p>
<p class="visible">This is visible</p>
```

---

## Responsive Design

### Mobile-First Approach
```html
<!-- Stack on mobile, 3 columns on desktop -->
<div class="row">
    <div class="col">Item 1</div>
    <div class="col">Item 2</div>
    <div class="col">Item 3</div>
</div>
```

### Media Query Breakpoints
```css
/* Mobile: < 768px (default) */
/* Tablet: 768px - 1199px */
/* Desktop: 1200px and above */

@media (max-width: 768px) {
    .desktop-only {
        display: none;
    }
}

@media (min-width: 1200px) {
    .container {
        max-width: 1200px;
    }
}
```

---

## Loading State

### Spinner/Loader
```html
<div class="loader">
    <div class="spinner"></div>
</div>
```

### Loading Button
```html
<button class="btn btn-primary loading">
    <span class="spinner"></span> Processing...
</button>
```

### Pulse Animation
```html
<div class="pulse">Content pulsing...</div>
```

---

## Breadcrumbs

```html
<ul class="breadcrumb">
    <li><a href="/">Home</a></li>
    <li><a href="/patients">Patients</a></li>
    <li class="active">Patient Profile</li>
</ul>
```

---

## Pagination

```html
<ul class="pagination">
    <li><a href="?page=1">Previous</a></li>
    <li><a href="?page=1">1</a></li>
    <li><a href="?page=2">2</a></li>
    <li class="active"><span>3</span></li>
    <li><a href="?page=4">4</a></li>
    <li><a href="?page=3">Next</a></li>
</ul>
```

---

## Complete Page Example

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard - Elite Medical Center</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/hospital_theme.css') }}">
</head>
<body>
    <!-- Navigation -->
    <nav style="background: var(--hospital-blue);">
        <div class="container" style="display: flex; justify-content: space-between; align-items: center; color: white;">
            <h1 style="margin: 0;">🏥 Elite Medical Center</h1>
            <ul style="list-style: none; display: flex; gap: 2rem;">
                <li><a href="/dashboard" style="color: white;">Dashboard</a></li>
                <li><a href="/profile" style="color: white;">Profile</a></li>
                <li><a href="/logout" style="color: white;">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container" style="margin-top: 2rem;">
        <!-- Page Title -->
        <h2>Welcome, {{ patient_name }}</h2>
        
        <!-- Alerts -->
        {% if alert_message %}
            <div class="alert alert-success">
                {{ alert_message }}
                <span class="alert-close">&times;</span>
            </div>
        {% endif %}

        <!-- Content Row -->
        <div class="row" style="margin-top: 2rem;">
            <!-- Left Column -->
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Your Health Status</h3>
                    </div>
                    <div class="card-body">
                        <p>Heart Rate: <strong>72 bpm</strong></p>
                        <p>Blood Pressure: <strong>120/80</strong></p>
                        <p>Status: <span class="badge badge-success">Stable</span></p>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Upcoming Appointments</h3>
                    </div>
                    <div class="card-body">
                        <p>Dr. Smith - Tomorrow at 2:00 PM</p>
                        <button class="btn btn-primary btn-small">View Details</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background: #1a1a1a; color: #ddd; padding: 2rem; margin-top: 3rem; text-align: center;">
        <p>&copy; 2024 Elite Medical Center | HIPAA Compliant</p>
    </footer>

    <script>
        // Close alert
        document.querySelectorAll('.alert-close').forEach(btn => {
            btn.addEventListener('click', function() {
                this.parentElement.style.display = 'none';
            });
        });
    </script>
</body>
</html>
```

---

## Tips & Best Practices

1. **Color Consistency**
   - Always use CSS variables instead of hardcoding hex colors
   - Maintain the color palette across all pages

2. **Spacing**
   - Use utility classes for margins and padding
   - Maintain consistent spacing between components

3. **Typography**
   - Use semantic HTML (h1, h2, h3, etc.)
   - Respect the font hierarchy

4. **Responsiveness**
   - Test on mobile, tablet, and desktop
   - Use the col class for flexible layouts

5. **Accessibility**
   - Always include alt text for images
   - Use proper label tags for form inputs
   - Test keyboard navigation

6. **Performance**
   - Minimize CSS file size
   - Use CSS variables for theming
   - Cache assets appropriately

---

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

---

For more information, refer to `DATABASE_CONSOLIDATION_GUIDE.md`
