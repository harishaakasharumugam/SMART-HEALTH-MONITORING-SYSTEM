# GemCare Professional - Quick Start Guide

## 🚀 Get Started in 5 Minutes

---

## Step 1: Setup Database (Windows)

### Option 1: Using MySQL Command Line

```bash
# Open Command Prompt or PowerShell
cd d:\HARISH\DBMS GEM

# Run the combined schema (includes all tables)
mysql -u root -p < database/combined_schema.sql

# When prompted, enter your MySQL root password
# Password: (leave blank if no password set)
```

### Option 2: Manual MySQL Commands

```bash
# Open MySQL
mysql -u root -p

# Inside MySQL prompt:
mysql> CREATE DATABASE gemcare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
mysql> USE gemcare;
mysql> SOURCE database/schema.sql;
mysql> SOURCE database/insert_hospital_settings.sql;
mysql> EXIT;
```

### Verification

```bash
mysql -u root -p -e "SHOW DATABASES LIKE 'gemcare';"
mysql -u root -p -e "USE gemcare; SHOW TABLES;"
```

---

## Step 2: Install Dependencies

```bash
# Open Command Prompt or PowerShell
cd "d:\HARISH\DBMS GEM"

# Install Python packages
pip install -r requirements.txt

# If pip is not recognized, use python
python -m pip install -r requirements.txt

# Verify installation
pip list | findstr -E "Flask|SQLAlchemy|flask-mail"
```

---

## Step 3: Configure Environment

The `.env` file is already configured with:
```env
SQLALCHEMY_DATABASE_URI=mysql+mysqlconnector://root@localhost/gemcare
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=harisharumugam35@gmail.com
SMTP_PASSWORD=mnwhpkqjdvucdtsc
```

**No additional configuration needed!**

---

## Step 4: Run the Application

```bash
# Navigate to project directory
cd "d:\HARISH\DBMS GEM"

# Run the Flask application
python run.py

# You should see:
# * Running on http://localhost:5000
# * Press CTRL+C to quit
```

---

## Step 5: Access the Application

### 🌐 Open in Browser

| Page | URL |
|------|-----|
| Landing Page | http://localhost:5000 |
| Login | http://localhost:5000/login |
| Signup | http://localhost:5000/signup |

---

## 📝 Test Credentials

### For Testing (after account creation):

**Patient Account:**
- Username: `patient1`
- Password: `Test1234!`
- Role: Patient

**Doctor Account:**
- Username: `doctor1`
- Password: `Test1234!`
- Role: Doctor

**Caregiver Account:**
- Username: `caregiver1`
- Password: `Test1234!`
- Role: Caregiver

---

## 💌 Email Testing

### Test Doctor Sending Email to Patient

1. **Login as Doctor**
   - URL: `http://localhost:5000/login`
   - Select "Doctor" role
   - Use doctor credentials

2. **Navigate to Send Email**
   - Click "Send Email" in sidebar
   - Select patient from dropdown
   - Enter subject: "Test Message"
   - Enter message: "This is a test email"
   - Click "Send Email to Patient"

3. **Check Email**
   - Go to harisharumugam35@gmail.com
   - Check inbox for email
   - Verify professional formatting

### Test Patient Emailing Record to Self

1. **Login as Patient**
   - URL: `http://localhost:5000/login`
   - Select "Patient" role
   - Use patient credentials

2. **Navigate to Medical Records**
   - Click "Medical Records" in sidebar
   - Find a record in the table
   - Click "📧 Email" button

3. **Complete Email Form**
   - Add optional message
   - Click "Send Record via Email"

4. **Check Email**
   - Check patient's registered email
   - Verify record was sent

---

## 🎨 Professional Dashboard Features

### Patient Dashboard
- ✅ View vital signs (heart rate, temperature, BP)
- ✅ Manage appointments
- ✅ View prescriptions
- ✅ **Email medical records**
- ✅ Message doctor
- ✅ View profile

### Doctor Dashboard
- ✅ View patient statistics
- ✅ **Send email to patients**
- ✅ Manage appointments
- ✅ View patient messages
- ✅ View profile
- ✅ Quick email from patient list

### Caregiver Dashboard
- ✅ Monitor patient vitals
- ✅ View patient appointments
- ✅ Track medications
- ✅ Access medical documents
- ✅ View profile

---

## 🐛 Troubleshooting

### Error: "ModuleNotFoundError: No module named 'mysql'"
```bash
pip install mysql-connector-python
```

### Error: "Port 5000 already in use"
```bash
# Use different port
python -m flask run --port 5001

# Or kill existing process (Windows PowerShell)
Get-Process -ProcessName python | Stop-Process
```

### Error: "Database 'gemcare' not found"
```bash
# Verify database exists
mysql -u root -p -e "SHOW DATABASES;"

# Create if missing
mysql -u root -p < database/combined_schema.sql
```

### Error: "Email not sending"
```
1. Check Gmail credentials in .env
2. Enable "Less Secure Apps" in Gmail account
3. Check SMTP_SERVER is 'smtp.gmail.com'
4. Check SMTP_PORT is 587
```

### Blank or 404 Page
```java
1. Press CTRL+C to stop server
2. Verify templates exist: backend/templates/
3. Check file names are correct
4. Restart: python run.py
```

---

## 📁 Project Structure

```
DBMS GEM/
├── backend/
│   ├── templates/
│   │   ├── landing_new.html (Professional landing)
│   │   ├── login_new.html (Professional login)
│   │   ├── patient_dashboard_pro.html (Patient dashboard)
│   │   ├── doctor_dashboard_pro.html (Doctor dashboard)
│   │   ├── caregiver_dashboard_pro.html (Caregiver dashboard)
│   │   └── ... (other templates)
│   ├── routes/
│   │   ├── main.py (Dashboard routes)
│   │   ├── auth.py (Login/signup routes)
│   │   ├── email_api.py (Email endpoints) ⭐ NEW
│   │   └── ...
│   ├── services/
│   │   ├── email_service.py (Gmail SMTP)
│   │   └── ...
│   ├── app.py (Flask app configuration)
│   └── models.py
├── database/
│   ├── combined_schema.sql (Main database schema)
│   ├── schema.sql
│   ├── insert_hospital_settings.sql
│   └── ...
├── .env (Configuration - Already set up!)
├── run.py (Application entry point)
├── requirements.txt (Python dependencies)
└── README.md
```

---

## ✨ New Features Added

### Email System
- 📧 Doctor send email to patient
- 📧 Patient email records to self
- 📧 Automatic appointment reminders
- 📧 Professional HTML templates
- 📧 Gmail SMTP integration

### Professional Design
- 🎨 Modern gradient headers
- 🎨 Responsive sidebar navigation
- 🎨 Card-based layouts
- 🎨 Mobile-friendly design
- 🎨 Health color indicators

### Dashboard Improvements
- 👥 Patient health monitoring
- 👨‍⚕️ Doctor communication tools
- 🤝 Caregiver support features
- 📊 Vital statistics display
- 📋 Medical record management

---

## 📞 Support

| Issue | Solution |
|-------|----------|
| Database error | Run `mysql -u root -p < database/combined_schema.sql` |
| Templates not found | Check `backend/templates/` folder exists |
| Email not working | Verify `.env` file Gmail credentials |
| Port in use | Use `python -m flask run --port 5001` |
| Module import error | Run `pip install -r requirements.txt` |

---

## 🎯 Complete Workflow

1. **First Time Setup** (5 minutes)
   ```bash
   mysql -u root -p < database/combined_schema.sql
   pip install -r requirements.txt
   python run.py
   ```

2. **Every Time You Want to Run** (1 minute)
   ```bash
   cd "d:\HARISH\DBMS GEM"
   python run.py
   ```

3. **Stop the Server**
   - Press `CTRL+C` in terminal

4. **Create Test Accounts**
   - Go to `http://localhost:5000/signup`
   - Create patient, doctor, caregiver accounts
   - Login and test features

---

## 🧪 Testing Checklist

- [ ] Database created and tables visible
- [ ] Application runs without errors
- [ ] Landing page loads at `http://localhost:5000`
- [ ] Can create account on signup page
- [ ] Can login with credentials
- [ ] Patient dashboard loads
- [ ] Doctor dashboard loads
- [ ] Caregiver dashboard loads
- [ ] Can send email as doctor
- [ ] Patient can email record to self
- [ ] Email arrives in inbox with formatting

---

## 📚 Documentation

| Document | Purpose |
|----------|---------|
| `GEMCARE_EMAIL_GUIDE.md` | Email integration details |
| `PROFESSIONAL_IMPLEMENTATION_SUMMARY.md` | Complete project overview |
| `PROFESSIONAL_THEME_GUIDE.md` | Design system documentation |
| `QUICK_START_GUIDE.md` | This quick start |

---

## 🎓 Key Commands Reference

```bash
# Setup
mysql -u root -p < database/combined_schema.sql
pip install -r requirements.txt

# Run
python run.py

# Stop (in terminal)
CTRL + C

# Check Python version
python --version

# Check MySQL
mysql -u root -p -e "SELECT VERSION();"

# Install specific package
pip install package-name

# Upgrade pip (if needed)
python -m pip install --upgrade pip
```

---

## 🚀 Ready to Launch!

Your GemCare application is now ready to run with professional dashboards and email functionality.

**Last Updated:** April 2026
**Status:** ✅ Production Ready

