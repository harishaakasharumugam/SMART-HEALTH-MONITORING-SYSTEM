# Admin Guide: Patient Care Menu Consolidation

## 🎯 Summary

**What Was Done:**
- Consolidated "Enter Vitals" + "Prescriptions" + "Medical Records" into a single **"Patient Care & Records"** menu item
- Created a **tabbed interface** for the three forms
- Added **single patient selector** at top (shared across all tabs)
- Added **medicine details** to prescriptions (Name, Dosage, Frequency)
- Added **medical records creation** with file upload
- **Auto-loads existing patient records** when patient selected

---

## 🚀 How to Access & Test

### Step 1: Login as Doctor
```
URL: http://127.0.0.1:5000/
Email: doctor@hospital.com
Password: password123
```

### Step 2: Navigate to Patient Care
```
Sidebar Menu:
1. Dashboard
2. Assign Patients
3. My Patients
4. Messages
5. Send Email
6. ⭐ Patient Care ← Click here (NEW!)
7. Appointments
8. My Profile
```

### Step 3: Verify Components
```
Page should show:

┌─ Top Section ─────────────────────────────┐
│                                            │
│  Select Patient*                           │
│  [Dropdown with patient list]              │
│                                            │
└────────────────────────────────────────────┘

┌─ Tab Navigation ──────────────────────────┐
│                                            │
│  [💊 Enter Vitals] [📋 Prescription]       │
│  [📄 Medical Records]                      │
│                                            │
└────────────────────────────────────────────┘

┌─ Tab Content (Changes per tab) ─────────┐
│                                          │
│  [Form for selected tab]                 │
│  [Buttons for form submission]           │
│                                          │
└──────────────────────────────────────────┘
```

---

## 🧪 Testing Scenarios

### **Test 1: Tab Navigation**

1. Click "Patient Care" menu
2. Click each tab repeatedly:
   - ✅ Should NOT submit form
   - ✅ Should switch visible content
   - ✅ Tab button appears highlighted
   - ✅ Other tabs hidden

**Expected:** Smooth tab switching without errors

### **Test 2: Enter Vitals**

```
Input:
✓ Select Patient: John Doe
✓ Heart Rate: 75 bpm
✓ Temperature: 98.6°F
✓ BP Systolic: 120
✓ BP Diastolic: 80  
✓ Oxygen: 98%
✓ Glucose: 100 mg/dL
✓ Notes: Patient doing well

Action: Click "✓ Record Vitals"

Expected:
✅ Alert: "Vitals recorded successfully!"
✅ Form clears
✅ John Doe's dashboard auto-updates
✅ Vitals appear in patient dashboard

Check Patient Side:
→ Go to Patient Dashboard (as John Doe)
→ Click "Digital Twin" / "View My Vitals"
→ Should see: 75 bpm, 98.6°F, 120/80, 98%, 100 mg/dL
```

### **Test 3: Add Prescription**

```
Action: Click Tab 2 (Prescription)

Input:
✓ Patient: Already selected (John Doe)
✓ Prescription Type: Medication
✓ Medicine Name: Amoxicillin ← NEW FIELD
✓ Dosage: 500mg ← NEW FIELD
✓ Frequency: Twice Daily ← NEW FIELD  
✓ Instructions: Take with food
✓ Start Date: 04/15/2026
✓ Duration: 7 days

Action: Click "✓ Create Prescription"

Expected:
✅ Alert: "Prescription created successfully!"
✅ Form clears
✅ Email sent to patient
✅ John Doe receives notification

Check Patient Side:
→ Go to Patient Dashboard (as John Doe)
→ Click "Prescriptions" tab
→ Should see new prescription:
   - Medicine: Amoxicillin
   - Dosage: 500mg
   - Frequency: Twice Daily
   - Duration: 7 days
```

### **Test 4: Create Medical Record**

```
Action: Click Tab 3 (Medical Records)

Input:
✓ Patient: Already selected (John Doe)
✓ Record Type: Lab Report
✓ Description: Blood test complete. Hemoglobin: 14.2 g/dL, all normal
✓ Attach File: lab-report.pdf (select from computer)

Action: Click "✓ Create Medical Record"

Expected:
✅ Alert: "Medical record created successfully!"
✅ File uploaded to server
✅ Form clears
✅ Record appears in table below form:

   TABLE: Patient's Medical Records
   ┌──────────────┬─────────┬────────────────┬─────────────┐
   │ Record Type  │ Date    │ Description    │ Actions     │
   ├──────────────┼─────────┼────────────────┼─────────────┤
   │ Lab Report   │ 04/15   │ Blood test...  │ [📥 DL]     │
   └──────────────┴─────────┴────────────────┴─────────────┘

✅ [📥 Download] link works
✅ File is downloadable as PDF

Check Patient Side:
→ Go to Patient Dashboard (as John Doe)
→ Click "Medical Records" tab
→ Should see new record:
   - Record Type: Lab Report
   - Date: 04/15/2026
   - Description: Blood test...
   - [📥 Download] button available
```

### **Test 5: Patient Switching**

```
Action:
1. Select "John Doe" from dropdown
2. Click Tab 3 (Medical Records)
3. Observe records table for John Doe

Then:
4. Select "Mary Smith" from dropdown
5. Observe: Records table updates automatically

Expected:
✅ Records instantly change
✅ No page reload needed  
✅ Shows Mary's records (not John's)
✅ No console errors
```

### **Test 6: Validation**

```
Test 1: No Patient Selected
→ Click "✓ Record Vitals" without selecting patient
→ Expected: Alert: "❌ Please select a patient first"

Test 2: Invalid Vitals
→ Select patient
→ Heart Rate: 300 bpm (invalid)
→ Expected: Alert: "Heart rate must be between 30-200 bpm"

Test 3: Missing Required Fields
→ Select patient  
→ Leave medicine name blank
→ Click Submit
→ Expected: Alert: "❌ Please fill in all required fields"

Test 4: File Size
→ Try to upload file > 10MB
→ Expected: Alert: "❌ File size must be less than 10MB"
```

---

## 🔍 Troubleshooting

### Issue: Tab buttons not working

**Solution:**
```
1. Hard refresh: Ctrl+Shift+R
2. Check browser console (F12)
3. Look for: "switchTab is not defined"
4. If found: JavaScript didn't load
   - Check file: doctor_dashboard_pro.html
   - Verify switchTab() function exists before </body>
```

### Issue: Patient selector not affecting forms

**Solution:**
```
1. Verify selector ID is "carePatientSelect"
2. Check that vitals form uses: 
   document.getElementById('carePatientSelect').value
3. Check that prescription form uses:
   document.getElementById('carePatientSelect').value
4. Check that medical form uses:
   document.getElementById('carePatientSelect').value
```

### Issue: Records not loading

**Solution:**
```
1. Check network tab (F12 → Network)
2. Look for request: /api/patient-health-reports/123
3. Verify response has records array
4. Check backend logs for errors
5. Ensure /api/patient-health-reports/{id} endpoint exists
```

### Issue: File upload fails

**Solution:**
```
1. Verify file is PDF/JPG/PNG
2. Verify file < 10MB
3. Check backend temporary files disk space
4. Verify /api/create-health-report endpoint accepts files
5. Check file permissions on server
```

---

## 📊 Data Flow Verification

### Vitals Flow
```
Doctor Tab 1 → Record Vitals
         ↓
   POST /api/vitals
         ↓
Database: Saves vital_reading record
         ↓
Patient Dashboard: Auto-fetches and displays new vitals
         ↓
Result: Patient sees new readings in Digital Twin
```

**Check:**
- Database: `SELECT * FROM vital_reading WHERE patient_id = {id} ORDER BY created_at DESC;`
- Should show latest vital

### Prescription Flow
```
Doctor Tab 2 → Create Prescription
         ↓
   POST /api/create-prescription
         ↓
Database: Saves prescription record
         ↓
Email: Sent to patient with details
         ↓
Patient Dashboard: Auto-fetches and displays prescription
         ↓
Result: Patient sees new prescription in Prescriptions tab
```

**Check:**
- Database: `SELECT * FROM prescription WHERE patient_id = {id};`
- Should show new prescription
- Email sent: Check patient email inbox

### Medical Record Flow
```
Doctor Tab 3 → Create Medical Record
         ↓
   POST /api/create-health-report (with file)
         ↓
Database: Saves health_report record
File Storage: Saves file to server
         ↓
Records Table: Auto-loads and displays
         ↓
Patient Dashboard: Auto-fetches record
         ↓
Result: Patient can view and download in Medical Records tab
```

**Check:**
- Database: `SELECT * FROM health_report WHERE patient_id = {id};`
- Should show new record
- File stored at: `/backend/static/reports/` or configured path

---

## 🔐 Security Checklist

- [x] Only doctors can access Patient Care forms
- [x] Doctor can only see assigned patients
- [x] Vitals saved with doctor_id + patient_id
- [x] Prescriptions saved with doctor_id + patient_id
- [x] Medical records saved with doctor_id + patient_id
- [x] Patient can only view own data
- [x] File upload validated (type + size)
- [x] File stored in secure location
- [x] Patient email notifications sent

---

## 📝 Browser Console Check

Open Developer Tools (F12) and look in Console tab:

**Expected: No Errors**

**If you see:**
```
ERROR: carePatientSelect is not defined
→ Selector element not found in HTML

ERROR: switchTab is not defined  
→ JavaScript function missing
```

**Success Indicators:**
```
✓ No red errors
✓ Tabs switch smoothly
✓ Forms submit
✓ Records load
```

---

## 🎉 Success Criteria

System is working correctly when:

- [x] Menu shows single "Patient Care" item
- [x] Page loads with 3 visible tabs
- [x] Patient selector works
- [x] All tabs display forms
- [x] Vitals submit and appear in patient dashboard
- [x] Prescription created with doctor details
- [x] Medical records file upload works
- [x] Existing records auto-load
- [x] Record download links work
- [x] No console errors
- [x] Patient sees all data automatically
- [x] Forms validate inputs correctly

---

## 📞 Quick Reference Commands

### Check if table exists
```sql
SELECT * FROM vital_reading LIMIT 1;
SELECT * FROM prescription LIMIT 1;
SELECT * FROM health_report LIMIT 1;
```

### View recent doctor activity
```sql
SELECT * FROM audit_log 
WHERE doctor_id = {doctor_id} 
ORDER BY created_at DESC LIMIT 10;
```

### Verify patient-doctor relationship
```sql
SELECT * FROM doctor_patient_assignment 
WHERE doctor_id = {doctor_id};
```

### Check file storage
```bash
ls -la /backend/static/reports/
```

