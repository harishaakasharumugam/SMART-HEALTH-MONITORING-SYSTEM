#!/usr/bin/env python
"""Test messaging system"""

from backend.app import create_app
from backend.models import User

app = create_app()

with app.app_context():
    patient = User.query.filter_by(role='patient').first()
    doctor = User.query.filter_by(role='doctor').first()
    
    if patient and doctor:
        print('=== TESTING MESSAGING SYSTEM ===\n')
        
        # Test 1: Patient fetching messages with doctor
        with app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = patient.id
                sess['_fresh'] = True
            
            resp = client.get(f'/api/messages/{doctor.id}')
            data = resp.get_json()
            print(f'✅ Patient ({patient.id}) fetching messages with doctor ({doctor.id}):')
            print(f'   Status: {resp.status_code}')
            print(f'   Messages: {len(data.get("messages", []))}')
            if data.get('messages'):
                msgs = data['messages']
                for i, msg in enumerate(msgs[-3:]):  # Show last 3
                    sender = 'Doctor' if msg['sender_id'] == doctor.id else 'Patient'
                    print(f'   {i+1}. [{sender}]: {msg["content"]}')
        
        # Test 2: Doctor fetching messages with patient
        with app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = doctor.id
                sess['_fresh'] = True
            
            resp = client.get(f'/api/messages/{patient.id}')
            data = resp.get_json()
            print(f'\n✅ Doctor ({doctor.id}) fetching messages with patient ({patient.id}):')
            print(f'   Status: {resp.status_code}')
            print(f'   Messages: {len(data.get("messages", []))}')
            if data.get('messages'):
                msgs = data['messages']
                for i, msg in enumerate(msgs[-3:]):  # Show last 3
                    sender = 'Doctor' if msg['sender_id'] == doctor.id else 'Patient'
                    print(f'   {i+1}. [{sender}]: {msg["content"]}')
        
        print(f'\n✅ MESSAGING SYSTEM VERIFIED - WORKING ON BOTH SIDES!')
