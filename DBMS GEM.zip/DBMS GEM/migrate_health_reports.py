"""
Database Migration: Add missing columns to health_reports table
Run this script to update the existing database schema
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

from backend import create_app
from backend.app import db

app = create_app()
with app.app_context():
    try:
        print("Starting health_reports table migration...")
        
        from sqlalchemy import text
        
        with db.engine.connect() as conn:
            # Add doctor_id column
            try:
                conn.execute(text("ALTER TABLE health_reports ADD COLUMN doctor_id INT UNSIGNED"))
                print("Added doctor_id column")
            except Exception as e:
                print(f"  doctor_id column skip: {e}")
            
            # Add description column  
            try:
                conn.execute(text("ALTER TABLE health_reports ADD COLUMN description LONGTEXT"))
                print("Added description column")
            except Exception as e:
                print(f"  description column skip: {e}")
            
            # Add created_at column
            try:
                conn.execute(text("ALTER TABLE health_reports ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP"))
                print("Added created_at column")
            except Exception as e:
                print(f"  created_at column skip: {e}")
            
            # Add foreign key for doctor_id
            try:
                conn.execute(text("ALTER TABLE health_reports ADD CONSTRAINT fk_reports_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE SET NULL"))
                print("Added foreign key constraint for doctor_id")
            except Exception as e:
                print(f"  foreign key skip: {e}")
                
            conn.commit()
            print("Migration completed successfully!")
                
    except Exception as e:
        print(f"Migration failed: {e}")
        print("\nPlease run these SQL commands manually:")
        print("""
ALTER TABLE health_reports ADD COLUMN doctor_id INT UNSIGNED;
ALTER TABLE health_reports ADD COLUMN description LONGTEXT;
ALTER TABLE health_reports ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE health_reports ADD CONSTRAINT fk_reports_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE SET NULL;
        """)
