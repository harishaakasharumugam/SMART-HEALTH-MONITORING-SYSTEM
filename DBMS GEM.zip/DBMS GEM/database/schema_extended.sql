-- ===============================================
-- EXTENDED HEALTHCARE SYSTEM DATABASE SCHEMA
-- Additional tables for professional features
-- ===============================================

USE gemcare;

-- ==================== EXTENDED PATIENT PROFILES ====================
CREATE TABLE IF NOT EXISTS patient_extended_profiles (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL UNIQUE,
    
    -- Surgical History
    previous_surgeries TEXT,
    
    -- Hospitalization History
    past_hospitalizations TEXT,
    
    -- Immunization Records
    immunization_records TEXT,
    
    -- Family Medical History
    family_medical_history TEXT,
    
    -- Medication Allergies (detailed)
    medication_allergies TEXT,
    other_allergies TEXT,
    
    -- Dietary Restrictions
    dietary_restrictions TEXT,
    
    -- Lifestyle Information
    smoking_status ENUM('never', 'current', 'quit') DEFAULT 'never',
    smoking_quit_date DATE,
    alcohol_consumption ENUM('none', 'occasional', 'moderate', 'heavy') DEFAULT 'none',
    exercise_frequency VARCHAR(50),
    sleep_hours_per_night INT,
    occupation VARCHAR(100),
    work_related_exposures TEXT,
    
    -- Insurance Information
    insurance_provider VARCHAR(100),
    policy_number VARCHAR(50),
    group_id VARCHAR(50),
    copay_amount DECIMAL(10,2),
    deductible DECIMAL(10,2),
    insurance_valid_from DATE,
    insurance_valid_to DATE,
    
    -- Additional Emergency Contacts
    emergency_contact_2_name VARCHAR(100),
    emergency_contact_2_phone VARCHAR(20),
    emergency_contact_2_relation VARCHAR(50),
    
    -- Preferences
    organ_donation_preference BOOLEAN DEFAULT FALSE,
    dnr_status BOOLEAN DEFAULT FALSE,
    preferred_language VARCHAR(50) DEFAULT 'English',
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    PRIMARY KEY (id),
    CONSTRAINT fk_ext_profile_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== MEDICINES DATABASE ====================
CREATE TABLE IF NOT EXISTS medicines (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) UNIQUE NOT NULL,
    generic_name VARCHAR(255),
    category VARCHAR(100),
    strength VARCHAR(100),
    form ENUM('tablet', 'capsule', 'liquid', 'injection', 'inhaler', 'other'),
    manufacturer VARCHAR(255),
    active_ingredients TEXT,
    cost DECIMAL(10,2),
    available BOOLEAN DEFAULT TRUE,
    registration_number VARCHAR(100),
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== MEDICINE INTERACTIONS ====================
CREATE TABLE IF NOT EXISTS medicine_interactions (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    medicine_1_id INT UNSIGNED NOT NULL,
    medicine_2_id INT UNSIGNED NOT NULL,
    severity ENUM('mild', 'moderate', 'severe', 'contraindicated') DEFAULT 'mild',
    description TEXT,
    recommendation TEXT,
    PRIMARY KEY (id),
    CONSTRAINT fk_inter_med1 FOREIGN KEY (medicine_1_id) REFERENCES medicines(id) ON DELETE CASCADE,
    CONSTRAINT fk_inter_med2 FOREIGN KEY (medicine_2_id) REFERENCES medicines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== MEDICINE ALLERGIES ====================
CREATE TABLE IF NOT EXISTS medicine_allergies (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    medicine_id INT UNSIGNED NOT NULL,
    allergy_name VARCHAR(100) NOT NULL,
    severity ENUM('mild', 'moderate', 'severe') DEFAULT 'mild',
    reaction TEXT,
    PRIMARY KEY (id),
    CONSTRAINT fk_allergy_med FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== PRESCRIPTIONS ====================
CREATE TABLE IF NOT EXISTS prescriptions (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    diagnosis VARCHAR(255),
    notes TEXT,
    status ENUM('active', 'expired', 'completed', 'cancelled') DEFAULT 'active',
    valid_from DATETIME DEFAULT CURRENT_TIMESTAMP,
    valid_until DATETIME,
    pharmacy_id INT UNSIGNED,
    pharmacy_notes TEXT,
    filled_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_presc_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_presc_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== PRESCRIPTION MEDICINES ====================
CREATE TABLE IF NOT EXISTS prescription_medicines (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    prescription_id INT UNSIGNED NOT NULL,
    medicine_id INT UNSIGNED NOT NULL,
    dosage VARCHAR(50),
    frequency VARCHAR(100),
    route ENUM('oral', 'injection', 'topical', 'inhalation', 'other') DEFAULT 'oral',
    duration_days INT,
    quantity INT,
    special_instructions TEXT,
    interactions_checked BOOLEAN DEFAULT FALSE,
    interactions_found TEXT,
    contraindication_checked BOOLEAN DEFAULT FALSE,
    contraindication_found TEXT,
    adherence_rate DECIMAL(5,2) DEFAULT 0,
    PRIMARY KEY (id),
    CONSTRAINT fk_presc_med_presc FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    CONSTRAINT fk_presc_med_med FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== APPOINTMENTS ====================
CREATE TABLE IF NOT EXISTS appointments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    appointment_date DATETIME NOT NULL,
    duration_minutes INT DEFAULT 30,
    appointment_type VARCHAR(100),
    reason TEXT,
    status ENUM('scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show') DEFAULT 'scheduled',
    consultation_notes TEXT,
    doctor_notes TEXT,
    cancelled_by VARCHAR(50),
    cancellation_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    scheduled_datetime DATETIME,
    PRIMARY KEY (id),
    CONSTRAINT fk_appt_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_appt_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_appt_date (appointment_date),
    INDEX idx_appt_patient (patient_id),
    INDEX idx_appt_doctor (doctor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== LAB TESTS ====================
CREATE TABLE IF NOT EXISTS lab_tests (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    test_name VARCHAR(255) UNIQUE NOT NULL,
    test_code VARCHAR(50) UNIQUE NOT NULL,
    category VARCHAR(100),
    cost DECIMAL(10,2),
    turnaround_hours INT,
    description TEXT,
    sample_type VARCHAR(100),
    preparation_instructions TEXT,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== LAB TEST PARAMETERS ====================
CREATE TABLE IF NOT EXISTS lab_test_parameters (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    lab_test_id INT UNSIGNED NOT NULL,
    parameter_name VARCHAR(255) NOT NULL,
    unit VARCHAR(50),
    normal_min DECIMAL(10,2),
    normal_max DECIMAL(10,2),
    is_critical BOOLEAN DEFAULT FALSE,
    critical_value DECIMAL(10,2),
    PRIMARY KEY (id),
    CONSTRAINT fk_param_test FOREIGN KEY (lab_test_id) REFERENCES lab_tests(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== LAB ORDERS ====================
CREATE TABLE IF NOT EXISTS lab_orders (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    required_date DATETIME,
    status ENUM('pending', 'sample_collected', 'in_process', 'completed', 'cancelled') DEFAULT 'pending',
    sample_collected_date DATETIME,
    sample_collection_location VARCHAR(255),
    clinical_indication TEXT,
    special_instructions TEXT,
    PRIMARY KEY (id),
    CONSTRAINT fk_order_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_order_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== LAB RESULTS ====================
CREATE TABLE IF NOT EXISTS lab_results (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    lab_order_id INT UNSIGNED NOT NULL,
    parameter_id INT UNSIGNED NOT NULL,
    result_value DECIMAL(10,2) NOT NULL,
    result_text VARCHAR(255),
    status ENUM('normal', 'abnormal', 'critical') DEFAULT 'normal',
    reference_range VARCHAR(100),
    test_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    reported_date DATETIME,
    PRIMARY KEY (id),
    CONSTRAINT fk_result_order FOREIGN KEY (lab_order_id) REFERENCES lab_orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_result_param FOREIGN KEY (parameter_id) REFERENCES lab_test_parameters(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== CONSULTATION NOTES (SOAP FORMAT) ====================
CREATE TABLE IF NOT EXISTS consultation_notes (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    appointment_id INT UNSIGNED,
    subjective TEXT,
    objective TEXT,
    assessment TEXT,
    plan TEXT,
    differential_diagnosis TEXT,
    vital_signs_json TEXT,
    lab_results_json TEXT,
    version INT DEFAULT 1,
    is_current BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    signed_by VARCHAR(100),
    signed_at DATETIME,
    PRIMARY KEY (id),
    CONSTRAINT fk_cons_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cons_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cons_appt FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== TREATMENT PLANS ====================
CREATE TABLE IF NOT EXISTS treatment_plans (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    diagnosis VARCHAR(255) NOT NULL,
    objectives TEXT,
    start_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    end_date DATETIME,
    review_date DATETIME,
    status ENUM('active', 'completed', 'abandoned', 'on_hold') DEFAULT 'active',
    medical_interventions TEXT,
    lifestyle_modifications TEXT,
    dietary_recommendations TEXT,
    exercise_plan TEXT,
    monitoring_parameters TEXT,
    monitoring_frequency VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_plan_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_plan_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== TREATMENT PLAN PHASES ====================
CREATE TABLE IF NOT EXISTS treatment_plan_phases (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    plan_id INT UNSIGNED NOT NULL,
    phase_number INT NOT NULL,
    phase_name VARCHAR(100),
    description TEXT,
    start_date DATETIME,
    end_date DATETIME,
    duration_days INT,
    goals TEXT,
    status ENUM('pending', 'in_progress', 'completed', 'on_hold') DEFAULT 'pending',
    completion_percentage INT DEFAULT 0,
    PRIMARY KEY (id),
    CONSTRAINT fk_phase_plan FOREIGN KEY (plan_id) REFERENCES treatment_plans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== MEDICAL DOCUMENTS ====================
CREATE TABLE IF NOT EXISTS medical_documents (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    uploaded_by INT UNSIGNED NOT NULL,
    document_type VARCHAR(50),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    mime_type VARCHAR(50),
    original_filename VARCHAR(255),
    body_part VARCHAR(100),
    imaging_date DATETIME,
    radiologist_name VARCHAR(100),
    findings TEXT,
    impression TEXT,
    visibility ENUM('patient', 'doctor', 'all_doctors', 'public') DEFAULT 'all_doctors',
    version INT DEFAULT 1,
    is_latest BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_doc_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_doc_uploader FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== HOSPITAL SETTINGS ====================
CREATE TABLE IF NOT EXISTS hospital_settings (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    hospital_name VARCHAR(255) UNIQUE NOT NULL,
    hospital_registration_number VARCHAR(100),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    postal_code VARCHAR(20),
    country VARCHAR(100),
    phone VARCHAR(20),
    fax VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(255),
    accreditation TEXT,
    license_number VARCHAR(100),
    license_expiry DATE,
    logo_path VARCHAR(500),
    opening_time VARCHAR(10),
    closing_time VARCHAR(10),
    currency VARCHAR(10) DEFAULT 'USD',
    tax_rate DECIMAL(5,2),
    smtp_server VARCHAR(100),
    smtp_port INT,
    smtp_username VARCHAR(100),
    smtp_password VARCHAR(255),
    smtp_from_email VARCHAR(100),
    smtp_from_name VARCHAR(100),
    sms_gateway_enabled BOOLEAN DEFAULT FALSE,
    sms_api_key VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== DEPARTMENTS ====================
CREATE TABLE IF NOT EXISTS departments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    hospital_id INT UNSIGNED,
    department_name VARCHAR(100) NOT NULL,
    description TEXT,
    head_doctor_id INT UNSIGNED,
    phone VARCHAR(20),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_dept_hospital FOREIGN KEY (hospital_id) REFERENCES hospital_settings(id) ON DELETE SET NULL,
    CONSTRAINT fk_dept_head FOREIGN KEY (head_doctor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== DEPARTMENT ASSIGNMENTS ====================
CREATE TABLE IF NOT EXISTS department_assignments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    doctor_id INT UNSIGNED NOT NULL,
    department_id INT UNSIGNED NOT NULL,
    role VARCHAR(50),
    join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    leave_date DATETIME,
    is_active BOOLEAN DEFAULT TRUE,
    PRIMARY KEY (id),
    CONSTRAINT fk_assign_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_assign_dept FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE,
    UNIQUE KEY unique_assignment (doctor_id, department_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== EMAIL LOGS ====================
CREATE TABLE IF NOT EXISTS email_logs (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    recipient_email VARCHAR(100) NOT NULL,
    recipient_user_id INT UNSIGNED,
    subject VARCHAR(255),
    body LONGTEXT,
    email_type VARCHAR(50),
    attachment_count INT DEFAULT 0,
    attachment_paths TEXT,
    status ENUM('sent', 'pending', 'failed', 'bounced') DEFAULT 'pending',
    sent_at DATETIME,
    error_message TEXT,
    related_object_type VARCHAR(50),
    related_object_id INT UNSIGNED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_email_user FOREIGN KEY (recipient_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_email_status (status),
    INDEX idx_email_type (email_type),
    INDEX idx_email_recipient (recipient_email),
    INDEX idx_email_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== INDEXES FOR PERFORMANCE ====================

CREATE INDEX idx_prescription_patient ON prescriptions(patient_id);
CREATE INDEX idx_prescription_doctor ON prescriptions(doctor_id);
CREATE INDEX idx_prescription_status ON prescriptions(status);

CREATE INDEX idx_appointment_patient ON appointments(patient_id);
CREATE INDEX idx_appointment_doctor ON appointments(doctor_id);
CREATE INDEX idx_appointment_status ON appointments(status);

CREATE INDEX idx_consultation_patient ON consultation_notes(patient_id);
CREATE INDEX idx_consultation_doctor ON consultation_notes(doctor_id);

CREATE INDEX idx_treatment_plan_patient ON treatment_plans(patient_id);
CREATE INDEX idx_treatment_plan_doctor ON treatment_plans(doctor_id);

CREATE INDEX idx_lab_order_patient ON lab_orders(patient_id);
CREATE INDEX idx_lab_order_status ON lab_orders(status);

CREATE INDEX idx_medical_doc_patient ON medical_documents(patient_id);
CREATE INDEX idx_medical_doc_type ON medical_documents(document_type);

-- ==================== INITIAL DATA ====================

-- Insert sample medicines (optional)
-- UNCOMMENT THESE TO ADD SAMPLE DATA

/*
INSERT INTO medicines (name, generic_name, category, strength, form, manufacturer, cost, available) VALUES
('Lisinopril', 'Lisinopril', 'ACE Inhibitor', '5mg', 'tablet', 'Generic', 10.00, TRUE),
('Metformin', 'Metformin', 'Antidiabetic', '500mg', 'tablet', 'Generic', 15.00, TRUE),
('Amoxicillin', 'Amoxicillin', 'Antibiotic', '500mg', 'capsule', 'Generic', 20.00, TRUE),
('Ibuprofen', 'Ibuprofen', 'NSAID', '400mg', 'tablet', 'Generic', 5.00, TRUE),
('Omeprazole', 'Omeprazole', 'PPI', '20mg', 'capsule', 'Generic', 25.00, TRUE);
*/

-- ==================== VERIFICATION ====================
SELECT COUNT(*) as table_count FROM information_schema.tables 
WHERE table_schema = 'gemcare' 
AND table_name IN (
    'patient_extended_profiles', 'medicines', 'prescriptions',
    'appointments', 'consultation_notes', 'treatment_plans',
    'lab_tests', 'lab_orders', 'lab_results',
    'medical_documents', 'hospital_settings', 'departments',
    'email_logs'
);

-- Expected: 13 tables

SHOW TABLES LIKE '%extended%';
SHOW TABLES LIKE '%prescription%';
SHOW TABLES LIKE '%appointment%';
SHOW TABLES LIKE '%lab_%';
SHOW TABLES LIKE '%consultation%';
SHOW TABLES LIKE '%treatment%';
SHOW TABLES LIKE '%medical_document%';
SHOW TABLES LIKE '%hospital%';
SHOW TABLES LIKE '%department%';
SHOW TABLES LIKE '%email%';

-- ==================== END OF SCHEMA ====================
