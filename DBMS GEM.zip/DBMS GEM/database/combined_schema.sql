-- ===============================================
-- PROFESSIONAL HOSPITAL MANAGEMENT SYSTEM
-- Combined Database Schema
-- Database: gemcare
-- ===============================================

-- Drop and recreate database completely (clears all tablespace files)
DROP DATABASE IF EXISTS gemcare;
CREATE DATABASE gemcare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gemcare;

-- CRITICAL: Disable checks for initialization
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

-- ===============================================
-- CORE TABLES
-- ===============================================

-- 1. Users Table (Central user management)
CREATE TABLE users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('doctor', 'patient', 'caregiver', 'admin') NOT NULL,
    full_name VARCHAR(100),
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_role (role),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Patient Profiles (Basic patient information)
CREATE TABLE patient_profiles (
    patient_id INT UNSIGNED NOT NULL,
    dob DATE,
    gender ENUM('male', 'female', 'other'),
    medical_history TEXT,
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    blood_group VARCHAR(5),
    primary_doctor_id INT UNSIGNED,
    allergies TEXT,
    chronic_conditions TEXT,
    address TEXT,
    medical_history_doctor_locked BOOLEAN DEFAULT FALSE,
    PRIMARY KEY (patient_id),
    CONSTRAINT fk_profile_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_profile_doc FOREIGN KEY (primary_doctor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2b. Extended Patient Profiles (Professional healthcare details)
CREATE TABLE patient_extended_profiles (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL UNIQUE,
    previous_surgeries TEXT,
    past_hospitalizations TEXT,
    immunization_records TEXT,
    family_medical_history TEXT,
    medication_allergies TEXT,
    other_allergies TEXT,
    dietary_restrictions TEXT,
    smoking_status ENUM('never', 'current', 'quit') DEFAULT 'never',
    smoking_quit_date DATE,
    alcohol_consumption ENUM('none', 'occasional', 'moderate', 'heavy') DEFAULT 'none',
    exercise_frequency VARCHAR(50),
    sleep_hours_per_night INT,
    occupation VARCHAR(100),
    work_related_exposures TEXT,
    insurance_provider VARCHAR(100),
    policy_number VARCHAR(50),
    group_id VARCHAR(50),
    copay_amount DECIMAL(10,2),
    deductible DECIMAL(10,2),
    insurance_valid_from DATE,
    insurance_valid_to DATE,
    emergency_contact_2_name VARCHAR(100),
    emergency_contact_2_phone VARCHAR(20),
    emergency_contact_2_relation VARCHAR(50),
    organ_donation_preference BOOLEAN DEFAULT FALSE,
    dnr_status BOOLEAN DEFAULT FALSE,
    preferred_language VARCHAR(50) DEFAULT 'English',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_ext_profile_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2c. Doctor Profiles (Professional credentials)
CREATE TABLE doctor_profiles (
    doctor_id INT UNSIGNED NOT NULL,
    designation VARCHAR(100),
    specialization VARCHAR(100),
    hospital_name VARCHAR(100),
    years_experience INT,
    clinic_address TEXT,
    bio TEXT,
    license_number VARCHAR(100),
    medical_council_registration VARCHAR(100),
    PRIMARY KEY (doctor_id),
    CONSTRAINT fk_doctor_user FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2d. Caregiver Profiles
CREATE TABLE caregiver_profiles (
    caregiver_id INT UNSIGNED NOT NULL,
    relationship_to_patient VARCHAR(50),
    caregiver_notes TEXT,
    PRIMARY KEY (caregiver_id),
    CONSTRAINT fk_caregiver_user FOREIGN KEY (caregiver_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- VITAL SIGNS & MONITORING
-- ===============================================

-- 3. Vital Signs (Patient health measurements)
CREATE TABLE vital_signs (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    heart_rate DECIMAL(5,2),
    blood_pressure_sys INT,
    blood_pressure_dia INT,
    temperature DECIMAL(4,2),
    oxygen_level DECIMAL(5,2),
    glucose_level DECIMAL(5,2),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_vitals_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_vital_patient (patient_id),
    INDEX idx_vital_timestamp (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Thresholds (Normal value ranges)
CREATE TABLE thresholds (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    vital_type VARCHAR(50),
    min_value DECIMAL(10,2),
    max_value DECIMAL(10,2),
    is_adaptive BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_thresholds_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Alerts (Abnormal reading notifications)
CREATE TABLE alerts (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    vital_id INT UNSIGNED,
    alert_type VARCHAR(50),
    severity ENUM('warning', 'critical') DEFAULT 'warning',
    status ENUM('active', 'acknowledged', 'escalated', 'resolved', 'closed') DEFAULT 'active',
    description TEXT,
    explanation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_alerts_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_alerts_vital FOREIGN KEY (vital_id) REFERENCES vital_signs(id) ON DELETE SET NULL,
    INDEX idx_alert_patient (patient_id),
    INDEX idx_alert_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Alert Escalation (Alert history tracking)
CREATE TABLE alert_escalations (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    alert_id INT UNSIGNED NOT NULL,
    previous_level ENUM('warning', 'critical'),
    current_level ENUM('warning', 'critical'),
    escalation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_escalation_alert FOREIGN KEY (alert_id) REFERENCES alerts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Health Scores (Overall patient health assessment)
CREATE TABLE health_scores (
    patient_id INT UNSIGNED NOT NULL,
    current_score INT DEFAULT 100,
    risk_level ENUM('low', 'moderate', 'high') DEFAULT 'low',
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (patient_id),
    CONSTRAINT fk_scores_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- SYMPTOMS & MEDICAL OBSERVATIONS
-- ===============================================

-- 8. Symptoms (Patient reported symptoms)
CREATE TABLE symptoms (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    description TEXT,
    severity INT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_symptoms_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_symptom_patient (patient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Doctor Notes (Medical documentation)
CREATE TABLE doctor_notes (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    content TEXT,
    version INT DEFAULT 1,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_notes_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_notes_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- MEDICATIONS & PRESCRIPTIONS
-- ===============================================

-- 10. Medicines Database
CREATE TABLE medicines (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) UNIQUE NOT NULL,
    generic_name VARCHAR(255),
    category VARCHAR(100),
    strength VARCHAR(100),
    form ENUM('tablet', 'capsule', 'liquid', 'injection', 'inhaler', 'other'),
    manufacturer VARCHAR(255),
    active_ingredients TEXT,
    cost DECIMAL(10,2),
    available BOOLEAN DEFAULT TRUE,
    registration_number VARCHAR(100),
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_med_name (name),
    INDEX idx_med_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Medicine Interactions
CREATE TABLE medicine_interactions (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    medicine_1_id INT UNSIGNED NOT NULL,
    medicine_2_id INT UNSIGNED NOT NULL,
    severity ENUM('mild', 'moderate', 'severe', 'contraindicated') DEFAULT 'mild',
    description TEXT,
    recommendation TEXT,
    PRIMARY KEY (id),
    CONSTRAINT fk_inter_med1 FOREIGN KEY (medicine_1_id) REFERENCES medicines(id) ON DELETE CASCADE,
    CONSTRAINT fk_inter_med2 FOREIGN KEY (medicine_2_id) REFERENCES medicines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Medicine Allergies
CREATE TABLE medicine_allergies (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    medicine_id INT UNSIGNED NOT NULL,
    allergy_name VARCHAR(100) NOT NULL,
    severity ENUM('mild', 'moderate', 'severe') DEFAULT 'mild',
    reaction TEXT,
    PRIMARY KEY (id),
    CONSTRAINT fk_allergy_med FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. Prescriptions
CREATE TABLE prescriptions (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    diagnosis VARCHAR(255),
    notes TEXT,
    status ENUM('active', 'expired', 'completed', 'cancelled') DEFAULT 'active',
    valid_from DATETIME DEFAULT CURRENT_TIMESTAMP,
    valid_until DATETIME,
    pharmacy_id INT UNSIGNED,
    pharmacy_notes TEXT,
    filled_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_presc_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_presc_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_prescription_patient (patient_id),
    INDEX idx_prescription_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. Prescription Medicines
CREATE TABLE prescription_medicines (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    prescription_id INT UNSIGNED NOT NULL,
    medicine_id INT UNSIGNED NOT NULL,
    dosage VARCHAR(50),
    frequency VARCHAR(100),
    route ENUM('oral', 'injection', 'topical', 'inhalation', 'other') DEFAULT 'oral',
    duration_days INT,
    quantity INT,
    special_instructions TEXT,
    interactions_checked BOOLEAN DEFAULT FALSE,
    interactions_found TEXT,
    contraindication_checked BOOLEAN DEFAULT FALSE,
    contraindication_found TEXT,
    adherence_rate DECIMAL(5,2) DEFAULT 0,
    PRIMARY KEY (id),
    CONSTRAINT fk_presc_med_presc FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    CONSTRAINT fk_presc_med_med FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- APPOINTMENTS & SCHEDULING
-- ===============================================

-- 15. Appointments
CREATE TABLE appointments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    appointment_date DATETIME NOT NULL,
    duration_minutes INT DEFAULT 30,
    appointment_type VARCHAR(100),
    reason TEXT,
    status ENUM('scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show') DEFAULT 'scheduled',
    consultation_notes TEXT,
    doctor_notes TEXT,
    cancelled_by VARCHAR(50),
    cancellation_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    scheduled_datetime DATETIME,
    PRIMARY KEY (id),
    CONSTRAINT fk_appt_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_appt_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_appt_date (appointment_date),
    INDEX idx_appt_patient (patient_id),
    INDEX idx_appt_doctor (doctor_id),
    INDEX idx_appt_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- LABORATORY & DIAGNOSTICS
-- ===============================================

-- 16. Lab Tests (Test templates)
CREATE TABLE lab_tests (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    test_name VARCHAR(255) UNIQUE NOT NULL,
    test_code VARCHAR(50) UNIQUE NOT NULL,
    category VARCHAR(100),
    cost DECIMAL(10,2),
    turnaround_hours INT,
    description TEXT,
    sample_type VARCHAR(100),
    preparation_instructions TEXT,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. Lab Test Parameters
CREATE TABLE lab_test_parameters (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    lab_test_id INT UNSIGNED NOT NULL,
    parameter_name VARCHAR(255) NOT NULL,
    unit VARCHAR(50),
    normal_min DECIMAL(10,2),
    normal_max DECIMAL(10,2),
    is_critical BOOLEAN DEFAULT FALSE,
    critical_value DECIMAL(10,2),
    PRIMARY KEY (id),
    CONSTRAINT fk_param_test FOREIGN KEY (lab_test_id) REFERENCES lab_tests(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. Lab Orders
CREATE TABLE lab_orders (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    required_date DATETIME,
    status ENUM('pending', 'sample_collected', 'in_process', 'completed', 'cancelled') DEFAULT 'pending',
    sample_collected_date DATETIME,
    sample_collection_location VARCHAR(255),
    clinical_indication TEXT,
    special_instructions TEXT,
    PRIMARY KEY (id),
    CONSTRAINT fk_order_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_order_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_lab_order_patient (patient_id),
    INDEX idx_lab_order_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 19. Lab Results
CREATE TABLE lab_results (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    lab_order_id INT UNSIGNED NOT NULL,
    parameter_id INT UNSIGNED NOT NULL,
    result_value DECIMAL(10,2) NOT NULL,
    result_text VARCHAR(255),
    status ENUM('normal', 'abnormal', 'critical') DEFAULT 'normal',
    reference_range VARCHAR(100),
    test_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    reported_date DATETIME,
    PRIMARY KEY (id),
    CONSTRAINT fk_result_order FOREIGN KEY (lab_order_id) REFERENCES lab_orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_result_param FOREIGN KEY (parameter_id) REFERENCES lab_test_parameters(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- CONSULTATION & CLINICAL DOCUMENTATION
-- ===============================================

-- 20. Consultation Notes (SOAP format)
CREATE TABLE consultation_notes (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    appointment_id INT UNSIGNED,
    subjective TEXT,
    objective TEXT,
    assessment TEXT,
    plan TEXT,
    differential_diagnosis TEXT,
    vital_signs_json TEXT,
    lab_results_json TEXT,
    version INT DEFAULT 1,
    is_current BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    signed_by VARCHAR(100),
    signed_at DATETIME,
    PRIMARY KEY (id),
    CONSTRAINT fk_cons_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cons_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cons_appt FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL,
    INDEX idx_consultation_patient (patient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- TREATMENT & CARE PLANNING
-- ===============================================

-- 21. Treatment Plans
CREATE TABLE treatment_plans (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    doctor_id INT UNSIGNED NOT NULL,
    diagnosis VARCHAR(255) NOT NULL,
    objectives TEXT,
    start_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    end_date DATETIME,
    review_date DATETIME,
    status ENUM('active', 'completed', 'abandoned', 'on_hold') DEFAULT 'active',
    medical_interventions TEXT,
    lifestyle_modifications TEXT,
    dietary_recommendations TEXT,
    exercise_plan TEXT,
    monitoring_parameters TEXT,
    monitoring_frequency VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_plan_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_plan_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 22. Treatment Plan Phases
CREATE TABLE treatment_plan_phases (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    plan_id INT UNSIGNED NOT NULL,
    phase_number INT NOT NULL,
    phase_name VARCHAR(100),
    description TEXT,
    start_date DATETIME,
    end_date DATETIME,
    duration_days INT,
    goals TEXT,
    status ENUM('pending', 'in_progress', 'completed', 'on_hold') DEFAULT 'pending',
    completion_percentage INT DEFAULT 0,
    PRIMARY KEY (id),
    CONSTRAINT fk_phase_plan FOREIGN KEY (plan_id) REFERENCES treatment_plans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 23. Recommendations
CREATE TABLE recommendations (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    suggestion TEXT,
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_rec_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- MEDICAL DOCUMENTS & IMAGING
-- ===============================================

-- 24. Medical Documents (X-rays, scans, reports)
CREATE TABLE medical_documents (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    uploaded_by INT UNSIGNED,
    document_type VARCHAR(50),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    mime_type VARCHAR(50),
    original_filename VARCHAR(255),
    body_part VARCHAR(100),
    imaging_date DATETIME,
    radiologist_name VARCHAR(100),
    findings TEXT,
    impression TEXT,
    visibility ENUM('patient', 'doctor', 'all_doctors', 'public') DEFAULT 'all_doctors',
    version INT DEFAULT 1,
    is_latest BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_doc_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_doc_uploader FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_medical_doc_patient (patient_id),
    INDEX idx_medical_doc_type (document_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- HOSPITAL ORGANIZATION
-- ===============================================

-- 25. Hospital Settings
CREATE TABLE hospital_settings (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    hospital_name VARCHAR(255) UNIQUE NOT NULL,
    hospital_registration_number VARCHAR(100),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    postal_code VARCHAR(20),
    country VARCHAR(100),
    phone VARCHAR(20),
    fax VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(255),
    accreditation TEXT,
    license_number VARCHAR(100),
    license_expiry DATE,
    logo_path VARCHAR(500),
    opening_time VARCHAR(10),
    closing_time VARCHAR(10),
    currency VARCHAR(10) DEFAULT 'USD',
    tax_rate DECIMAL(5,2),
    smtp_server VARCHAR(100),
    smtp_port INT,
    smtp_username VARCHAR(100),
    smtp_password VARCHAR(255),
    smtp_from_email VARCHAR(100),
    smtp_from_name VARCHAR(100),
    sms_gateway_enabled BOOLEAN DEFAULT FALSE,
    sms_api_key VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 26. Departments
CREATE TABLE departments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    hospital_id INT UNSIGNED,
    department_name VARCHAR(100) NOT NULL,
    description TEXT,
    head_doctor_id INT UNSIGNED,
    phone VARCHAR(20),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_dept_hospital FOREIGN KEY (hospital_id) REFERENCES hospital_settings(id) ON DELETE SET NULL,
    CONSTRAINT fk_dept_head FOREIGN KEY (head_doctor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 27. Department Assignments
CREATE TABLE department_assignments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    doctor_id INT UNSIGNED NOT NULL,
    department_id INT UNSIGNED NOT NULL,
    role VARCHAR(50),
    join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    leave_date DATETIME,
    is_active BOOLEAN DEFAULT TRUE,
    PRIMARY KEY (id),
    CONSTRAINT fk_assign_doctor FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_assign_dept FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE,
    UNIQUE KEY unique_assignment (doctor_id, department_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- COMMUNICATION & COLLABORATION
-- ===============================================

-- 28. Messaging (Secure communication)
CREATE TABLE messages (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    sender_id INT UNSIGNED NOT NULL,
    receiver_id INT UNSIGNED NOT NULL,
    content_encrypted TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_msg_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_msg_receiver FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_msg_receiver (receiver_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- CAREGIVER MANAGEMENT
-- ===============================================

-- 29. Caregiver Assignments
CREATE TABLE caregiver_assignments (
    caregiver_id INT UNSIGNED NOT NULL,
    patient_id INT UNSIGNED NOT NULL,
    access_level ENUM('view', 'manage') DEFAULT 'view',
    PRIMARY KEY (caregiver_id, patient_id),
    CONSTRAINT fk_care_caregiver FOREIGN KEY (caregiver_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_care_patient FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- AUDIT & COMPLIANCE
-- ===============================================

-- 30. Audit Logs (Compliance and security)
CREATE TABLE audit_logs (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED,
    action VARCHAR(255),
    details TEXT,
    ip_address VARCHAR(45),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_user (user_id),
    INDEX idx_audit_timestamp (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 31. Email Logs (Notification tracking)
CREATE TABLE email_logs (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    recipient_email VARCHAR(100) NOT NULL,
    recipient_user_id INT UNSIGNED,
    subject VARCHAR(255),
    body LONGTEXT,
    email_type VARCHAR(50),
    attachment_count INT DEFAULT 0,
    attachment_paths TEXT,
    status ENUM('sent', 'pending', 'failed', 'bounced') DEFAULT 'pending',
    sent_at DATETIME,
    error_message TEXT,
    related_object_type VARCHAR(50),
    related_object_id INT UNSIGNED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_email_user FOREIGN KEY (recipient_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_email_status (status),
    INDEX idx_email_type (email_type),
    INDEX idx_email_recipient (recipient_email),
    INDEX idx_email_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 32. Health Reports (Generated reports)
CREATE TABLE health_reports (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    report_type VARCHAR(50),
    file_path VARCHAR(255),
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_reports_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- SYSTEM & POLICIES
-- ===============================================

-- 33. Medical Policies (Clinical guidelines)
CREATE TABLE medical_policies (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    policy_name VARCHAR(255),
    rule_definition_json JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 34. Medical Consent (HIPAA compliance)
CREATE TABLE patient_consent (
    patient_id INT UNSIGNED NOT NULL,
    research_consent BOOLEAN DEFAULT FALSE,
    data_sharing_consent BOOLEAN DEFAULT FALSE,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (patient_id),
    CONSTRAINT fk_consent_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 35. Validation Flags (Data quality)
CREATE TABLE validation_flags (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    entity_type VARCHAR(50),
    entity_id INT UNSIGNED NOT NULL,
    error_message TEXT,
    is_resolved BOOLEAN DEFAULT FALSE,
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 36. Digital Twins (Advanced analytics - optional)
CREATE TABLE digital_twins (
    patient_id INT UNSIGNED NOT NULL,
    model_data JSON,
    last_simulation TIMESTAMP,
    PRIMARY KEY (patient_id),
    CONSTRAINT fk_twin_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 37. Care Paths (Treatment pathways)
CREATE TABLE care_paths (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id INT UNSIGNED NOT NULL,
    steps_json JSON,
    status ENUM('pending', 'in-progress', 'completed'),
    PRIMARY KEY (id),
    CONSTRAINT fk_path_user FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===============================================
-- RE-ENABLE CONSTRAINTS
-- ===============================================

SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;

-- ===============================================
-- VERIFICATION QUERIES
-- ===============================================

-- Verify database and tables created
SELECT 'Database: gemcare' as Status;
SELECT COUNT(*) as Total_Tables FROM information_schema.tables 
WHERE table_schema = 'gemcare';

-- Show all created tables
SHOW TABLES;

-- Expected: 37 tables total

-- ===============================================
-- END OF SCHEMA
-- Database: gemcare (Combined - Complete)
-- Version: 2.0 (Schema - No Default Data)
-- ===============================================
