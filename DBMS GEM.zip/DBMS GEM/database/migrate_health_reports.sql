-- Database Migration Script
-- Add missing columns to health_reports table for Medical Records feature
-- Run this script using: mysql -u root -p database_name < migrate_health_reports.sql

-- Check if columns already exist before adding
ALTER TABLE health_reports 
ADD COLUMN IF NOT EXISTS doctor_id INT UNSIGNED AFTER patient_id,
ADD COLUMN IF NOT EXISTS description LONGTEXT AFTER report_type,
ADD COLUMN IF NOT EXISTS created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER generated_at;

-- Add foreign key constraint for doctor_id (if it doesn't already exist)
-- This will need to be done carefully to avoid duplicates
-- Uncomment if needed:
-- ALTER TABLE health_reports 
-- ADD CONSTRAINT fk_health_reports_doctor 
-- FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE SET NULL;

-- Create index for faster queries
CREATE INDEX idx_health_reports_patient ON health_reports(patient_id);
CREATE INDEX idx_health_reports_doctor ON health_reports(doctor_id);
CREATE INDEX idx_health_reports_created ON health_reports(created_at);

-- Verify the changes
-- SELECT COLUMN_NAME, COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS 
-- WHERE TABLE_NAME = 'health_reports' AND TABLE_SCHEMA = DATABASE();
