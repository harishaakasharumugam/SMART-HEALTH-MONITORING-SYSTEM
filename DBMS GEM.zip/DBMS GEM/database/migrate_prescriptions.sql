-- Migration: Add simplified prescription fields to prescriptions table
-- This adds medicine_name, dosage, frequency, duration fields for easier prescription display

ALTER TABLE prescriptions 
ADD COLUMN IF NOT EXISTS medicine_name VARCHAR(255) AFTER diagnosis;

ALTER TABLE prescriptions 
ADD COLUMN IF NOT EXISTS dosage VARCHAR(50) AFTER medicine_name;

ALTER TABLE prescriptions 
ADD COLUMN IF NOT EXISTS frequency VARCHAR(100) AFTER dosage;

ALTER TABLE prescriptions 
ADD COLUMN IF NOT EXISTS duration INT AFTER frequency;

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient ON prescriptions(patient_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_doctor ON prescriptions(doctor_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_status ON prescriptions(status);
CREATE INDEX IF NOT EXISTS idx_prescriptions_created ON prescriptions(created_at DESC);

-- Verify the migration
SELECT 'Migration completed successfully!' AS status;
DESCRIBE prescriptions;
