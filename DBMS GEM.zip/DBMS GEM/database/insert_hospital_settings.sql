-- ===============================================
-- Hospital Settings - DEFAULT DATA DISABLED
-- Database initialized with no default data
-- ===============================================

USE gemcare;

-- No default data inserted
-- All tables are created empty and ready for use

-- When needed, add hospital settings via:
-- INSERT INTO hospital_settings (...) VALUES (...);
);

-- Verify insertion
SELECT * FROM hospital_settings LIMIT 1;

-- ===============================================
-- SUCCESS: Hospital settings have been configured!
-- Email notifications are now ready to use.
-- ===============================================
