#!/usr/bin/env python3
"""
Direct database migration script - adds missing columns to health_reports table
"""

import os
import mysql.connector
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get database connection details
db_host = os.getenv('DB_HOST', 'localhost')
db_user = os.getenv('DB_USER', 'root')
db_password = os.getenv('DB_PASSWORD', '')
db_name = os.getenv('DB_NAME', 'gemcare')

try:
    # Connect to MySQL
    conn = mysql.connector.connect(
        host=db_host,
        user=db_user,
        password=db_password,
        database=db_name
    )
    cursor = conn.cursor()
    
    print("Running migration: Adding missing columns to health_reports table...")
    print("=" * 60)
    
    # Check current columns
    cursor.execute("""
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'health_reports' AND TABLE_SCHEMA = %s
        ORDER BY ORDINAL_POSITION
    """, (db_name,))
    existing_columns = [row[0] for row in cursor.fetchall()]
    print("Current columns: " + str(existing_columns))
    print("=" * 60)
    
    # Add doctor_id if missing
    if 'doctor_id' not in existing_columns:
        print("Adding doctor_id column...")
        cursor.execute("""
            ALTER TABLE health_reports 
            ADD COLUMN doctor_id INT UNSIGNED AFTER patient_id
        """)
        print("✓ doctor_id added")
    else:
        print("✓ doctor_id already exists")
    
    # Add description if missing
    if 'description' not in existing_columns:
        print("Adding description column...")
        cursor.execute("""
            ALTER TABLE health_reports 
            ADD COLUMN description LONGTEXT AFTER report_type
        """)
        print("✓ description added")
    else:
        print("✓ description already exists")
    
    # Add created_at if missing
    if 'created_at' not in existing_columns:
        print("Adding created_at column...")
        cursor.execute("""
            ALTER TABLE health_reports 
            ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER generated_at
        """)
        print("✓ created_at added")
    else:
        print("✓ created_at already exists")
    
    conn.commit()
    print("=" * 60)
    print("✅ All columns added successfully!")
    
    # Verify
    cursor.execute("""
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'health_reports' AND TABLE_SCHEMA = %s
        ORDER BY ORDINAL_POSITION
    """, (db_name,))
    final_columns = [row[0] for row in cursor.fetchall()]
    print("\n📋 Final table structure:")
    for i, col in enumerate(final_columns, 1):
        print(f"  {i}. {col}")
    
    cursor.close()
    conn.close()
    print("\n✅ Migration completed!")
    
except Exception as e:
    print("Error: " + str(e))
    import traceback
    traceback.print_exc()
