# GemCare Email Integration & Professional Dashboard Guide

## Overview
This guide covers the complete email integration and professional dashboard implementation for GemCare healthcare management system.

---

## Email Features

### 1. Gmail Configuration

The system uses Gmail SMTP for sending emails. Configuration is already set up in `.env`:

```env
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=harisharumugam35@gmail.com
SMTP_PASSWORD=mnwhpkqjdvucdtsc
SMTP_FROM_EMAIL=harisharumugam35@gmail.com
SMTP_FROM_NAME=GemCare Healthcare
```

### 2. Doctor to Patient Email (Send Email Feature)

**Location:** Doctor Dashboard → Send Email Section

**Features:**
- Select patient from dropdown
- Compose email with subject and message
- Optional: Attach medical reports
- Professional HTML email template
- Automatic logging and tracking

**API Endpoint:**
```
POST /api/send-doctor-email
```

**Request Parameters:**
```json
{
    "patient_email": "patient@example.com",
    "subject": "Your Appointment Reminder",
    "message": "Your appointment is scheduled for...",
    "attach_report": false
}
```

**Response:**
```json
{
    "success": true,
    "message": "Email sent successfully to patient@example.com"
}
```

### 3. Patient Medical Record Email

**Location:** Patient Dashboard → Medical Records → Email Button

**Features:**
- One-click email sending
- Automatic record attachment
- Personal message support
- Medical record encryption
- HIPAA-compliant delivery

**How to Use:**
1. Navigate to "Medical Records" section
2. Click "📧 Email" button on desired record
3. Add optional personal message
4. Click "Send Record via Email"
5. Record will be sent to patient's registered email

**API Endpoint:**
```
POST /api/send-record-email
```

**Request Parameters:**
```json
{
    "record_id": "report_1",
    "message": "Optional personal message"
}
```

### 4. Appointment Reminder Email

**Location:** Used by system automatically when appointments are scheduled

**Features:**
- Automatic reminder 24 hours before appointment
- Appointment date, time, and doctor information
- Professional formatted email
- CTA to confirm or reschedule

**API Endpoint:**
```
POST /api/send-appointment-reminder
```

**Request Parameters:**
```json
{
    "patient_id": 123,
    "appointment_date": "2026-04-15",
    "appointment_time": "10:00 AM",
    "doctor_name": "Dr. Rajesh Kumar"
}
```

---

## Professional Dashboards

### Patient Dashboard (`patient_dashboard_pro.html`)

**Key Sections:**
1. **Dashboard Overview**
   - Heart Rate, Temperature, Blood Pressure, Health Score
   - Recent Activity
   - Quick Stats

2. **My Vitals**
   - Table of vital measurements
   - Historical data
   - Trends and patterns

3. **Appointments**
   - Upcoming appointments
   - Book new appointments
   - View appointment details

4. **Prescriptions**
   - Current medications
   - Dosage and frequency
   - Duration of treatment
   - Prescribed by information

5. **Medical Records**
   - Download records
   - **Email records to self**
   - Track document history

6. **Messages**
   - Direct communication with doctors
   - Real-time chat interface
   - Message history

7. **My Profile**
   - Personal information
   - Health profile
   - Contact details

**Email Feature on This Dashboard:**
- Records tab has email functionality
- Click "📧 Email" to send record to registered email
- Automatic encryption and secure delivery

### Doctor Dashboard (`doctor_dashboard_pro.html`)

**Key Sections:**
1. **Dashboard Overview**
   - Total patients managed
   - Pending reports
   - Critical alerts
   - Today's appointments

2. **My Patients**
   - Complete patient list
   - Last visit dates
   - Current status
   - Quick email button for each patient

3. **Messages**
   - Patient messages inbox
   - Reply directly
   - Message history

4. **Send Email** ⭐ **NEW**
   - **Dedicated email sending interface**
   - Select patient from dropdown
   - Compose subject and message
   - Optional report attachment
   - Send to single or multiple patients

5. **Appointments**
   - Upcoming appointment schedule
   - Confirmation status
   - Doctor notes

6. **My Profile**
   - Doctor credentials
   - Specialization
   - License information

**Email Features on This Dashboard:**
- **Primary Email Section:** Full email composition interface
- **Patient List Email Buttons:** Quick email from patient list
- **Message Reply:** Send messages via email option

### Caregiver Dashboard (`caregiver_dashboard_pro.html`)

**Key Sections:**
1. **Patient Information Card**
   - Shows managed patient
   - Connection status
   - Quick reference

2. **Dashboard**
   - Patient's recent vitals
   - Overall health summary
   - Care summary

3. **Vitals & Health**
   - Patient's vital measurements
   - Historical tracking
   - Trend analysis

4. **Appointments**
   - Patient's upcoming appointments
   - Doctor information
   - Appointment type and notes

5. **Medications**
   - Current medications for patient
   - Dosage schedule
   - Duration

6. **Documents**
   - Medical records
   - Lab results
   - View documents

7. **My Profile**
   - Caregiver information
   - Relationship status
   - Contact details

---

## Email Templates

### Professional Email Template - Doctor to Patient

```html
<html>
    <body style="font-family: Segoe UI, Arial, sans-serif;">
        <div style="max-width: 600px; margin: 0 auto; background: #f5f7fa; padding: 20px; border-radius: 8px;">
            <div style="background: linear-gradient(135deg, #003366 0%, #004d99 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
                <h1 style="margin: 0;">GemCare Healthcare Management</h1>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">Medical Communication</p>
            </div>
            <div style="background: white; padding: 30px;">
                <p>Dear Patient,</p>
                <div style="background: #f9f9f9; padding: 20px; border-left: 4px solid #00A86B; margin: 20px 0;">
                    <!-- Message content here -->
                </div>
                <p>Regards,<br/>Dr. [Doctor Name]</p>
            </div>
        </div>
    </body>
</html>
```

---

## API Endpoints Summary

| Endpoint | Method | Purpose | Auth Required |
|----------|--------|---------|----------------|
| `/api/send-doctor-email` | POST | Doctor sends email to patient | Yes (Doctor) |
| `/api/send-record-email` | POST | Patient requests record via email | Yes (Patient) |
| `/api/send-appointment-reminder` | POST | Send appointment reminder | Yes (Doctor) |

---

## Sending Emails Programmatically

### From Python Code

```python
from backend.services.email_service import EmailService

# Initialize
email_service = EmailService()

# Send email
result = email_service._send_email_smtp(
    recipient_email="patient@example.com",
    subject="Your Health Report",
    html_body="<html>...</html>",
    text_body="Plain text version",
    attachments=["/path/to/file.pdf"]  # Optional
)

if result['success']:
    print("Email sent successfully!")
else:
    print(f"Error: {result['error']}")
```

### From Frontend (JavaScript)

```javascript
// Send doctor email to patient
fetch('/api/send-doctor-email', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        patient_email: 'patient@example.com',
        subject: 'Your Appointment',
        message: 'Your appointment is scheduled for...',
        attach_report: false
    })
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        alert('Email sent successfully!');
    } else {
        alert('Error: ' + data.error);
    }
});
```

---

## Design Features

### Color Scheme
- **Primary:** #003366 (Professional Blue)
- **Accent Green:** #00A86B (Health/Success)
- **Accent Orange:** #FF8C42 (Warmth)
- **Light Gray:** #F5F5F5 (Background)

### Components
- Modern gradient headers
- Responsive grid layout
- Smooth hover effects
- Professional card design
- Intuitive navigation sidebar
- Mobile-responsive design

### Key UI Elements
- 📧 Email buttons for quick access
- 📥 Download buttons for records
- 🔒 Security indicators
- ✓ Status badges
- 📊 Statistics cards
- 📋 Data tables

---

## Security & Privacy

### Email Security
1. **Encryption:** Emails sent over TLS
2. **Authentication:** Gmail OAuth when available
3. **Rate Limiting:** Prevent spam
4. **Logging:** All emails logged for audit trail
5. **HIPAA Compliance:** Medical data protection

### Data Protection
- Patient data encrypted at rest
- Secure transmission (HTTPS)
- Access control based on user roles
- Activity logging and monitoring
- Secure password hashing

---

## Testing Email Functionality

### Manual Testing

1. **Doctor Sends Email to Patient:**
   - Login as doctor
   - Go to Doctor Dashboard → Send Email
   - Select patient from dropdown
   - Enter subject and message
   - Click "Send Email to Patient"
   - Check patient's email inbox

2. **Patient Requests Record via Email:**
   - Login as patient
   - Go to Patient Dashboard → Medical Records
   - Find a record
   - Click "📧 Email" button
   - Add optional message
   - Click "Send Record via Email"
   - Check patient's email inbox

3. **Test Appointment Reminder:**
   - Login as doctor
   - Schedule appointment (or use API)
   - Email should be automatically sent
   - Check patient email

### Troubleshooting

**Problem:** Emails not sending
- **Solution:** Check SMTP credentials in `.env`
- Verify Gmail account allows "Less Secure Apps"
- Check email service logs

**Problem:** Wrong email address received
- **Solution:** Verify patient email in system
- Check email form for typos
- Use dropdown to ensure correct selection

**Problem:** Styling not showing in email
- **Solution:** Some email clients don't support all CSS
- Use inline styles (already configured)
- Test in different email clients

---

## Best Practices

### For Doctors
1. Use clear, professional subject lines
2. Keep messages concise and actionable
3. Include patient name for personalization
4. Verify patient email before sending
5. Attach reports when relevant
6. Follow HIPAA guidelines

### For Patients
1. Check email regularly for important updates
2. Verify sender before clicking links
3. Don't share patient portal password
4. Report suspicious emails
5. Keep medical records safe

### For System Administrators
1. Monitor email delivery rates
2. Keep SMTP credentials secure
3. Review email logs regularly
4. Maintain email queue
5. Update email templates as needed

---

## Customization

### Email Template Customization

Edit template in `backend/routes/email_api.py`:

```python
html_body = f"""
<html>
    <!-- Customize HTML here -->
    <body>
        <!-- Your custom HTML -->
    </body>
</html>
"""
```

### Dashboard Customization

Edit templates:
- `patient_dashboard_pro.html`
- `doctor_dashboard_pro.html`
- `caregiver_dashboard_pro.html`

Add new sections:
```html
<section id="new-section" class="section">
    <div class="card full-width">
        <!-- Your content -->
    </div>
</section>
```

---

## Performance Optimization

### Email Sending
- Emails sent asynchronously (non-blocking)
- Batch email sending support
- Queue management
- Rate limiting to prevent overload

### Dashboard Loading
- Lazy loading for records
- Paginated data tables
- Cached API responses
- Optimized CSS and JavaScript

---

## Future Enhancements

### Planned Features
1. SMS notifications
2. Push notifications
3. Email scheduling
4. Bulk email sending
5. Email templates library
6. Automated recurring emails
7. Email analytics dashboard
8. Multi-language support
9. Advanced email filtering
10. Email encryption options

---

## Support & Contact

- **Email:** harisharumugam35@gmail.com
- **System:** GemCare Healthcare Management
- **Database:** gemcare
- **Version:** 2.0 (Professional Design with Email)

---

**Last Updated:** April 2026
**Status:** Production Ready
