# Gemini API Integration Guide

## Overview
The AI Symptom Checker now uses Google's Gemini API for intelligent symptom analysis instead of Ollama.

## What Changed

### 1. New Service File
- **File**: `backend/services/gemini_service.py`
- **Functions**:
  - `get_symptom_analysis(symptoms_text)` - Analyzes patient symptoms
  - `get_health_projection(vitals_summary)` - Generates health projections
  - `analyze_health_metrics(metrics_data)` - Advanced health metrics analysis

### 2. Updated Dependencies
Added to `requirements.txt`:
```
google-generativeai==0.3.0
python-dotenv==1.0.0
```

### 3. API Routes Updated
- **Route**: `/api/symptoms/search`
- **Old**: Used Ollama local service
- **New**: Uses Google Gemini API

## Configuration

### API Key Setup
The API key is already configured:
```
GEMINI_API_KEY=AIzaSyCwgx93-IQg9fueTnDflvmB_gMT5j5sv-0
```

#### Option 1: Using Environment Variables (Recommended)
1. A `.env` file has been created in the project root
2. The `gemini_service.py` automatically loads this via `python-dotenv`
3. No additional configuration needed

#### Option 2: System Environment Variable
```bash
# Windows PowerShell
$env:GEMINI_API_KEY="AIzaSyCwgx93-IQg9fueTnDflvmB_gMT5j5sv-0"

# Linux/Mac
export GEMINI_API_KEY="AIzaSyCwgx93-IQg9fueTnDflvmB_gMT5j5sv-0"
```

## Installation

1. Install the new dependencies:
```bash
pip install -r requirements.txt
```

2. Ensure `.env` file is in the project root with the API key

## Usage

### Symptom Analysis Endpoint
```
GET /api/symptoms/search?q=<symptoms>
```

**Example Request**:
```
GET /api/symptoms/search?q=headache%20and%20fever
```

**Response**:
```json
{
  "matches": [
    {
      "patient_id": 1,
      "description": "headache and high fever",
      "severity": "high",
      "timestamp": "2024-03-01"
    }
  ],
  "ai_analysis": "Your symptoms of headache and fever could indicate a viral or bacterial infection. Monitor your temperature regularly and stay hydrated. If symptoms persist for more than 3 days or worsen, please consult a physician immediately."
}
```

## Model Information

- **Model**: Google Gemini 1.5 Flash
- **Features**: 
  - Fast response times
  - Medical-aware language model
  - Long context understanding
  - Cost-effective

## Error Handling

The service includes graceful error handling:
- If Gemini API fails, a fallback message is returned
- Errors are logged in the console
- User experience is not disrupted

## Security Notes

⚠️ **Important**:
1. `.env` file is in `.gitignore` to prevent API key exposure
2. Do NOT commit `.env` to version control
3. Keep the API key confidential
4. For production, use secure secret management (AWS Secrets Manager, etc.)

## Testing the Integration

```bash
# Start the Flask app
python run.py

# In another terminal, test the endpoint
curl "http://localhost:5000/api/symptoms/search?q=headache%20and%20dizziness"
```

## Switching Models

To use a different Gemini model, edit `gemini_service.py`:
```python
MODEL_NAME = "gemini-1.5-pro"  # For higher accuracy
# or
MODEL_NAME = "gemini-2.0-flash"  # When available
```

## Additional Features Available

The `gemini_service.py` also provides:
- `get_health_projection()` - Can be used for predicting health trends
- `analyze_health_metrics()` - For comprehensive health analysis

These can be integrated into other features as needed.

## Support & Documentation

- [Google Generative AI Documentation](https://ai.google.dev/docs)
- [Gemini API Reference](https://ai.google.dev/api/python)
