# Prescription & Medical Records Workflow Guide

## 📋 How Data Flows Between Doctor and Patient

### 1. PRESCRIPTIONS WORKFLOW

```
DOCTOR SIDE (Doctor Dashboard)
├─ Doctor sees "Prescriptions Management" form
├─ Doctor fills:
│   ├─ Select Patient (dropdown of assigned patients)
│   ├─ Prescription Type (e.g., "Antihypertensive", "Antibiotic")
│   ├─ Notes (treatment instructions)
│   ├─ Start Date (when to begin)
│   └─ Duration Days (how long to take)
└─ Doctor clicks SUBMIT
    ↓
BACKEND DATABASE (Prescription Table)
├─ Record stored with:
│   ├─ patient_id (which patient)
│   ├─ doctor_id (which doctor prescribed)
│   ├─ diagnosis (prescription type)
│   ├─ notes (instructions)
│   ├─ valid_from (start date)
│   ├─ valid_until (end date calculated from duration)
│   └─ status: 'active'
├─ Patient gets EMAIL notification
└─ Entry saved in database
    ↓
PATIENT SIDE (Patient Dashboard > Prescriptions)
├─ Patient clicks "Prescriptions" section
├─ System queries: SELECT * FROM prescriptions WHERE patient_id = {current_patient}
├─ Displays TABLE with:
│   ├─ Medicine Name (from notes/diagnosis)
│   ├─ Dosage (from notes)
│   ├─ Frequency (from notes)
│   ├─ Duration (valid_until - valid_from)
│   └─ Prescribed By (doctor name from doctor_id)
└─ Patient can view/manage prescriptions
```

### Prescription API Endpoint

**POST** `/create-prescription` (Doctor-only)

```json
{
  "patient_id": 123,
  "prescription_type": "Antihypertensive",
  "notes": "Take 2 tablets twice daily with meals",
  "start_date": "2024-04-15",
  "duration": 30
}
```

Response:
```json
{
  "status": "success",
  "message": "Prescription created successfully",
  "prescription_id": 456
}
```

---

## 📄 MEDICAL RECORDS WORKFLOW

```
DOCTOR SIDE (Doctor Dashboard)
├─ Doctor sees "Medical Records" form
├─ Doctor fills:
│   ├─ Select Patient
│   ├─ Record Type (e.g., "Lab Report", "X-Ray", "Consultation Notes")
│   ├─ Description (findings, diagnosis, recommendations)
│   └─ File upload (PDF, image)
└─ Doctor clicks SUBMIT
    ↓
BACKEND DATABASE (HealthReport Table)
├─ Record stored with:
│   ├─ patient_id (which patient)
│   ├─ doctor_id (which doctor created it)
│   ├─ report_type (type of record)
│   ├─ description (medical findings)
│   ├─ file_path (if file uploaded)
│   └─ generated_at (timestamp)
├─ Patient gets EMAIL notification
└─ Entry saved and indexed
    ↓
PATIENT SIDE (Patient Dashboard > Medical Records)
├─ Patient clicks "Medical Records" section
├─ System queries: SELECT * FROM health_reports WHERE patient_id = {current_patient}
├─ Displays TABLE with:
│   ├─ Record Type (Lab Report, X-Ray, etc.)
│   ├─ Date (when created by doctor)
│   ├─ Description (first 50 characters)
│   └─ Actions:
│       ├─ 📧 Email (request copy via email)
│       └─ 📥 Download (as PDF)
└─ Patient can view/download/share records
```

### Medical Records API Endpoint

**POST** `/create-health-report` (Doctor-only)

```json
{
  "patient_id": 123,
  "report_type": "Lab Report",
  "description": "Blood test results: RBC 4.8M/µL, WBC 7.2K/µL, Hemoglobin 14.2 g/dL. All values within normal range.",
  "file": "(optional PDF file)"
}
```

---

## 🔗 DATABASE RELATIONSHIPS

```
┌─────────────┐
│  User (id)  │
│  Doctor: 1  │
│  Patient: 1 │
└─────────────┘
       │
       ├── doctor_id = 5 (Doctor Profile)
       │
       ├── PRESCRIPTIONS (patient_id = 123)
       │   ├─ prescribed_by_doctor.full_name (fetches from User where id = doctor_id)
       │   └─ valid_from, valid_until, notes, status
       │
       └── HEALTH_REPORTS (patient_id = 123)
           ├─ doctor_id = 5 (which doctor created it)
           ├─ report_type, description
           └─ file_path (for downloads)
```

---

## ✅ PATIENT VIEW UPDATES

### Current Prescriptions Section
- **Empty State**: "No active prescriptions. Your doctor will add prescriptions here."
- **With Data**: Shows table of all prescriptions doctor has created for patient
- **Refresh Button**: Reloads prescriptions from database

### Medical Records Section
- **Empty State**: "No medical records available yet. Your doctor will create them."
- **With Data**: Shows table of all reports doctor has created for patient
- **Email Action**: Send copy of record to email
- **Download Action**: Download record as PDF

---

## 📱 USER ACTIONS SUMMARY

### For DOCTOR:
1. Go to Doctor Dashboard
2. Find "Prescriptions Management" section
3. Fill form & submit → Saved to database
4. Patient receives email notification
5. Prescription appears in patient's dashboard automatically

### For PATIENT:
1. Go to Patient Dashboard
2. Click "Prescriptions" tab → Shows all prescriptions doctor created
3. Click "Medical Records" tab → Shows all reports doctor created
4. Can email or download records

---

## 🔄 NO MANUAL DATA ENTRY NEEDED

- ✅ Doctor creates prescription → Patient sees it automatically
- ✅ Patient doesn't fill prescriptions (doctor does)
- ✅ Doctor creates medical records → Patient sees them automatically
- ✅ Patient doesn't fill medical records (doctor does)
- ✅ All data linked by patient_id and doctor_id

---

## 🚀 NEXT STEPS

1. **Doctor creates prescription** via form endpoint
2. **Email sent to patient** with prescription details
3. **Patient refreshes page** → prescription appears
4. **Patient can request email copy** or **download as PDF**
5. **Doctor can view all prescriptions** they created for each patient

