#!/usr/bin/env python
"""Debug patient dashboard menu structure - NEW VERSION"""

from backend.app import create_app
from backend.models import User
import re

app = create_app()

with app.app_context():
    patient = User.query.filter_by(role='patient').first()
    if patient:
        with app.test_client() as client:
            # Simulate login
            with client.session_transaction() as sess:
                sess['_user_id'] = patient.id
                sess['_fresh'] = True
            
            response = client.get('/dashboard')
            html = response.get_data(as_text=True)
            
            print('=== DEBUGGING PATIENT DASHBOARD MENU (SIMPLE VERSION) ===\n')
            
            # Extract menu items - looking for onclick handlers with clickedLink parameter
            menu_pattern = r"<li><a\s+onclick=\"switchSection\('([^']+)',\s*this\);\s*return\s+false;\"[^>]*>([^<]+)</a></li>"
            menu_items = re.findall(menu_pattern, html)
            
            print(f'Found {len(menu_items)} menu items:\n')
            if len(menu_items) == 0:
                print('❌ No menu items found with onclick handlers!')
                print('Checking for ANY nav-link menu items...')
                all_links = re.findall(r'<a\s+[^>]*class="nav-link[^"]*"[^>]*>([^<]+)</a>', html)
                print(f'Found {len(all_links)} nav-link elements: {all_links}')
            else:
                for i, (section_id, label) in enumerate(menu_items, 1):
                    print(f'{i}. {label}')
                    print(f'   onclick: switchSection(\'{section_id}\', this)')
                    print()
            
            # Extract sections
            section_pattern = r'<section id="([^"]+)"[^>]*class="([^"]*)"'
            sections = re.findall(section_pattern, html)
            
            print(f'\nFound {len(sections)} sections:\n')
            for section_id, classes in sections:
                active = '✅ ACTIVE' if 'active' in classes else '  hidden'
                print(f'{active} - {section_id}: class="{classes}"')
            
            # Check for switchSection function
            if 'function switchSection' in html:
                print('\n✅ switchSection function is defined')
                
                # Extract function signature
                func_match = re.search(r'function switchSection\(([^)]+)\)', html)
                if func_match:
                    print(f'   Signature: switchSection({func_match.group(1)})')
                
                # Check for key functionality
                if ".classList.remove('active')" in html:
                    print('   ✅ Removes active class')
                if ".classList.add('active')" in html:
                    print('   ✅ Adds active class')
                if "getElementById" in html:
                    print('   ✅ Uses getElementById')
            else:
                print('\n❌ switchSection function NOT found!')
            
            # Check CSS
            if '.section {' in html:
                print('\n✅ .section CSS defined')
                
                css_match = re.search(r'\.section\s*\{([^}]+)\}', html)
                if css_match:
                    css = css_match.group(1).strip()
                    if 'display: none' in css:
                        print('   ✅ Hidden by default (display: none)')
                
                active_match = re.search(r'\.section\.active\s*\{([^}]+)\}', html)
                if active_match:
                    active_css = active_match.group(1).strip()
                    if 'display: grid' in active_css:
                        print('   ✅ Active sections show as grid')
                    print(f'   Active CSS: {active_css[:100]}...')
            
            print('\n=== TEST COMPLETE ===')
            print('\n✅ READY - Try clicking menu items in the browser!')
