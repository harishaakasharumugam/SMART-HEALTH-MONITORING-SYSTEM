#!/usr/bin/env python3
"""
Database integrity checker
"""
import sys
import os
from backend.app import create_app, db
from backend.models import User, PatientProfile, DoctorProfile, VitalSign, Alert, HealthScore, HealthReport
from backend.models_extended import (
    DoctorPatientAssignment, Appointment, Prescription, 
    ConsultationNote, MedicalDocument
)

app = create_app()

with app.app_context():
    print("=" * 60)
    print("DATABASE INTEGRITY CHECK")
    print("=" * 60)
    
    # Check existing tables
    tables = [
        ("Users", User),
        ("Patient Profiles", PatientProfile),
        ("Doctor Profiles", DoctorProfile),
        ("Vital Signs", VitalSign),
        ("Alerts", Alert),
        ("Health Scores", HealthScore),
        ("Doctor-Patient Assignments", DoctorPatientAssignment),
        ("Appointments", Appointment),
        ("Prescriptions", Prescription),
        ("Health Reports", HealthReport),
        ("Consultation Notes", ConsultationNote),
        ("Medical Documents", MedicalDocument),
    ]
    
    print("\nTABLE STATUS:")
    print("-" * 60)
    
    for table_name, model in tables:
        try:
            count = db.session.query(model).count()
            print(f"✓ {table_name:30} | Records: {count:6}")
        except Exception as e:
            print(f"✗ {table_name:30} | Error: {str(e)[:40]}")
    
    # Check for recent records
    print("\nRECENT ACTIVITY:")
    print("-" * 60)
    
    try:
        doctor_count = db.session.query(User).filter_by(role='doctor').count()
        patient_count = db.session.query(User).filter_by(role='patient').count()
        caregiver_count = db.session.query(User).filter_by(role='caregiver').count()
        admin_count = db.session.query(User).filter_by(role='admin').count()
        
        print(f"Doctors:    {doctor_count}")
        print(f"Patients:   {patient_count}")
        print(f"Caregivers: {caregiver_count}")
        print(f"Admins:     {admin_count}")
    except Exception as e:
        print(f"Error counting users: {e}")
    
    try:
        assignments = db.session.query(DoctorPatientAssignment).count()
        print(f"\nDoctor-Patient Assignments: {assignments}")
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n" + "=" * 60)
    print("DATABASE INTEGRITY CHECK COMPLETE")
    print("=" * 60)
