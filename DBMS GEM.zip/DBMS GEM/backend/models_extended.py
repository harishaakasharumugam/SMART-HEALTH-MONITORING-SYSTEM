"""
Extended Database Models for Advanced Healthcare Features
Includes: Enhanced patient profiles, prescriptions, appointments, lab results, treatment plans
"""

from .app import db
from flask_login import UserMixin
from datetime import datetime
from sqlalchemy.dialects.mysql import INTEGER

# ==================== EXTENDED PATIENT DATA ====================

class PatientExtendedProfile(db.Model):
    """Extended patient information for comprehensive medical history"""
    __tablename__ = 'patient_extended_profiles'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), unique=True, nullable=False)
    
    # Surgical History
    previous_surgeries = db.Column(db.Text)  # JSON: [{"name": "...", "date": "...", "outcome": "..."}]
    
    # Hospitalization History
    past_hospitalizations = db.Column(db.Text)  # JSON list
    
    # Immunization Records
    immunization_records = db.Column(db.Text)  # JSON: [{"vaccine": "...", "date": "..."}]
    
    # Family Medical History
    family_medical_history = db.Column(db.Text)  # Description
    
    # Medication Allergies (more specific)
    medication_allergies = db.Column(db.Text)  # Details
    
    # Other Allergies
    other_allergies = db.Column(db.Text)
    
    # Dietary Restrictions
    dietary_restrictions = db.Column(db.Text)
    
    # Lifestyle Information
    smoking_status = db.Column(db.Enum('never', 'current', 'quit'), default='never')
    smoking_quit_date = db.Column(db.Date)
    alcohol_consumption = db.Column(db.Enum('none', 'occasional', 'moderate', 'heavy'), default='none')
    exercise_frequency = db.Column(db.String(50))  # "3 times/week", "2-3 times/week", etc.
    sleep_hours_per_night = db.Column(db.Integer)
    occupation = db.Column(db.String(100))
    work_related_exposures = db.Column(db.Text)
    
    # Insurance Information
    insurance_provider = db.Column(db.String(100))
    policy_number = db.Column(db.String(50))
    group_id = db.Column(db.String(50))
    copay_amount = db.Column(db.Numeric(10, 2))
    deductible = db.Column(db.Numeric(10, 2))
    insurance_valid_from = db.Column(db.Date)
    insurance_valid_to = db.Column(db.Date)
    
    # Additional Emergency Contacts
    emergency_contact_2_name = db.Column(db.String(100))
    emergency_contact_2_phone = db.Column(db.String(20))
    emergency_contact_2_relation = db.Column(db.String(50))
    
    # Preferences
    organ_donation_preference = db.Column(db.Boolean, default=False)
    dnr_status = db.Column(db.Boolean, default=False)  # Do Not Resuscitate
    preferred_language = db.Column(db.String(50), default='English')
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    patient = db.relationship('User', foreign_keys=[patient_id])


# ==================== PRESCRIPTIONS ====================

class Prescription(db.Model):
    """Medicine prescriptions from doctors"""
    __tablename__ = 'prescriptions'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    
    # Prescription details
    diagnosis = db.Column(db.String(255))
    notes = db.Column(db.Text)
    
    # Simplified prescription fields for display
    medicine_name = db.Column(db.String(255))  # Medicine name for simple display
    dosage = db.Column(db.String(50))  # "500mg", "2 tablets", etc.
    frequency = db.Column(db.String(100))  # "Once daily", "Twice daily", etc.
    duration = db.Column(db.Integer)  # Duration in days
    
    # Status and validity
    status = db.Column(db.Enum('active', 'expired', 'completed', 'cancelled'), default='active')
    valid_from = db.Column(db.DateTime, default=datetime.utcnow)
    valid_until = db.Column(db.DateTime)
    
    # Pharmacy information
    pharmacy_id = db.Column(INTEGER(unsigned=True))  # Link to pharmacy if available
    pharmacy_notes = db.Column(db.Text)
    filled_date = db.Column(db.DateTime)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    patient = db.relationship('User', foreign_keys=[patient_id])
    doctor = db.relationship('User', foreign_keys=[doctor_id], overlaps="prescribed_by_doctor")
    prescribed_by_doctor = db.relationship('User', foreign_keys=[doctor_id], overlaps="doctor", viewonly=True)


class PrescriptionMedicine(db.Model):
    """Individual medicines in a prescription"""
    __tablename__ = 'prescription_medicines'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    prescription_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('prescriptions.id'), nullable=False)
    medicine_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('medicines.id'), nullable=False)
    
    # Dosage information
    dosage = db.Column(db.String(50))  # "500mg", "2 tablets", etc.
    frequency = db.Column(db.String(100))  # "Once daily", "Twice daily", "Every 8 hours"
    route = db.Column(db.Enum('oral', 'injection', 'topical', 'inhalation', 'other'), default='oral')
    duration_days = db.Column(db.Integer)
    quantity = db.Column(db.Integer)  # Number of days supply
    
    # Instructions
    special_instructions = db.Column(db.Text)  # "Take with food", "Before bedtime", etc.
    
    # Safety information
    interactions_checked = db.Column(db.Boolean, default=False)
    interactions_found = db.Column(db.Text)  # If any interactions found
    contraindication_checked = db.Column(db.Boolean, default=False)
    contraindication_found = db.Column(db.Text)  # If any contraindications found
    
    # Tracking
    adherence_rate = db.Column(db.Numeric(5, 2), default=0)  # Percentage
    
    prescription = db.relationship('Prescription', backref='medicines')
    medicine = db.relationship('Medicine')


class Medicine(db.Model):
    """Medicine/Drug database"""
    __tablename__ = 'medicines'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False, unique=True)
    generic_name = db.Column(db.String(255))
    category = db.Column(db.String(100))  # "Antibiotic", "Pain Reliever", etc.
    
    # Pharmaceutical information
    strength = db.Column(db.String(100))  # "500mg", "250mg/5ml", etc.
    form = db.Column(db.Enum('tablet', 'capsule', 'liquid', 'injection', 'inhaler', 'other'))
    manufacturer = db.Column(db.String(255))
    
    # Composition
    active_ingredients = db.Column(db.Text)  # JSON
    
    # Cost and availability
    cost = db.Column(db.Numeric(10, 2))
    available = db.Column(db.Boolean, default=True)
    
    # Regulatory
    registration_number = db.Column(db.String(100))
    expiry_date = db.Column(db.Date)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class MedicineInteraction(db.Model):
    """Known drug-drug interactions"""
    __tablename__ = 'medicine_interactions'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    medicine_1_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('medicines.id'), nullable=False)
    medicine_2_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('medicines.id'), nullable=False)
    
    severity = db.Column(db.Enum('mild', 'moderate', 'severe', 'contraindicated'), default='mild')
    description = db.Column(db.Text)  # Description of interaction
    recommendation = db.Column(db.Text)  # What to do
    
    medicine_1 = db.relationship('Medicine', foreign_keys=[medicine_1_id])
    medicine_2 = db.relationship('Medicine', foreign_keys=[medicine_2_id])


class MedicineAllergy(db.Model):
    """Known medicine-allergy contraindications"""
    __tablename__ = 'medicine_allergies'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    medicine_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('medicines.id'), nullable=False)
    allergy_name = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.Enum('mild', 'moderate', 'severe'), default='mild')
    reaction = db.Column(db.Text)
    
    medicine = db.relationship('Medicine')


# ==================== APPOINTMENTS ====================

class Appointment(db.Model):
    """Doctor-Patient appointments"""
    __tablename__ = 'appointments'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    
    # Appointment timing
    appointment_date = db.Column(db.DateTime, nullable=False)
    duration_minutes = db.Column(db.Integer, default=30)
    
    # Details
    appointment_type = db.Column(db.String(100))  # "Consultation", "Follow-up", "Check-up"
    reason = db.Column(db.Text)  # Why patient is coming
    
    # Status tracking
    status = db.Column(
        db.Enum('scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show'),
        default='scheduled'
    )
    
    # Notes
    consultation_notes = db.Column(db.Text)
    doctor_notes = db.Column(db.Text)
    
    # Cancellation tracking
    cancelled_by = db.Column(db.String(50))  # 'patient', 'doctor', 'admin'
    cancellation_reason = db.Column(db.Text)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    scheduled_datetime = db.Column(db.DateTime)  # When it was scheduled
    
    patient = db.relationship('User', foreign_keys=[patient_id])
    doctor = db.relationship('User', foreign_keys=[doctor_id])


# ==================== LAB TESTS & RESULTS ====================

class LabTest(db.Model):
    """Lab test templates and definitions"""
    __tablename__ = 'lab_tests'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    test_name = db.Column(db.String(255), nullable=False, unique=True)
    test_code = db.Column(db.String(50), nullable=False, unique=True)
    category = db.Column(db.String(100))  # "Blood", "Urine", "Imaging", etc.
    
    # Cost and turnaround
    cost = db.Column(db.Numeric(10, 2))
    turnaround_hours = db.Column(db.Integer)  # How long to get results
    
    description = db.Column(db.Text)
    sample_type = db.Column(db.String(100))  # "Blood", "Urine", "Stool", etc.
    preparation_instructions = db.Column(db.Text)  # Fasting requirement, etc.
    
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class LabTestParameter(db.Model):
    """Individual parameters in a lab test"""
    __tablename__ = 'lab_test_parameters'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    lab_test_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('lab_tests.id'), nullable=False)
    
    parameter_name = db.Column(db.String(255), nullable=False)
    unit = db.Column(db.String(50))  # "mg/dL", "mm/hr", etc.
    
    # Reference ranges
    normal_min = db.Column(db.Numeric(10, 2))
    normal_max = db.Column(db.Numeric(10, 2))
    
    # Status determination
    is_critical = db.Column(db.Boolean, default=False)
    critical_value = db.Column(db.Numeric(10, 2))  # If result > this, it's critical
    
    lab_test = db.relationship('LabTest', backref='parameters')


class LabOrder(db.Model):
    """Lab test orders from doctor"""
    __tablename__ = 'lab_orders'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    
    # Tests ordered
    order_date = db.Column(db.DateTime, default=datetime.utcnow)
    required_date = db.Column(db.DateTime)
    
    # Status
    status = db.Column(
        db.Enum('pending', 'sample_collected', 'in_process', 'completed', 'cancelled'),
        default='pending'
    )
    
    # Sample tracking
    sample_collected_date = db.Column(db.DateTime)
    sample_collection_location = db.Column(db.String(255))
    
    # Notes
    clinical_indication = db.Column(db.Text)  # Why the test is ordered
    special_instructions = db.Column(db.Text)
    
    patient = db.relationship('User', foreign_keys=[patient_id])
    doctor = db.relationship('User', foreign_keys=[doctor_id])


class LabResult(db.Model):
    """Lab test results"""
    __tablename__ = 'lab_results'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    lab_order_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('lab_orders.id'), nullable=False)
    parameter_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('lab_test_parameters.id'), nullable=False)
    
    # Result value
    result_value = db.Column(db.Numeric(10, 2), nullable=False)
    result_text = db.Column(db.String(255))  # For non-numeric results
    
    # Status
    status = db.Column(db.Enum('normal', 'abnormal', 'critical'), default='normal')
    
    # Reference info
    reference_range = db.Column(db.String(100))
    
    # Metadata
    test_date = db.Column(db.DateTime, default=datetime.utcnow)
    reported_date = db.Column(db.DateTime)
    
    lab_order = db.relationship('LabOrder', backref='results')
    parameter = db.relationship('LabTestParameter')


# ==================== TREATMENT PLANS ====================

class TreatmentPlan(db.Model):
    """Comprehensive treatment plans for patients"""
    __tablename__ = 'treatment_plans'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    
    # Plan details
    diagnosis = db.Column(db.String(255), nullable=False)
    objectives = db.Column(db.Text)  # Treatment objectives
    
    # Dates
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime)
    review_date = db.Column(db.DateTime)
    
    # Status
    status = db.Column(db.Enum('active', 'completed', 'abandoned', 'on_hold'), default='active')
    
    # Plan content
    medical_interventions = db.Column(db.Text)  # JSON
    lifestyle_modifications = db.Column(db.Text)
    dietary_recommendations = db.Column(db.Text)
    exercise_plan = db.Column(db.Text)
    
    # Monitoring
    monitoring_parameters = db.Column(db.Text)  # What to monitor
    monitoring_frequency = db.Column(db.String(100))  # "Weekly", "Monthly", etc.
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    patient = db.relationship('User', foreign_keys=[patient_id])
    doctor = db.relationship('User', foreign_keys=[doctor_id])


class TreatmentPlanPhase(db.Model):
    """Phases/Milestones in a treatment plan"""
    __tablename__ = 'treatment_plan_phases'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    plan_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('treatment_plans.id'), nullable=False)
    
    phase_number = db.Column(db.Integer, nullable=False)
    phase_name = db.Column(db.String(100))
    description = db.Column(db.Text)
    
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)
    duration_days = db.Column(db.Integer)
    
    # Goals
    goals = db.Column(db.Text)  # What should be achieved in this phase
    
    # Status
    status = db.Column(db.Enum('pending', 'in_progress', 'completed', 'on_hold'), default='pending')
    completion_percentage = db.Column(db.Integer, default=0)
    
    plan = db.relationship('TreatmentPlan', backref='phases')


# ==================== CONSULTATION NOTES (SOAP Format) ====================

class ConsultationNote(db.Model):
    """Detailed SOAP format consultation notes"""
    __tablename__ = 'consultation_notes'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    appointment_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('appointments.id'))
    
    # SOAP Components
    # Subjective - What patient reports
    subjective = db.Column(db.Text)  # Chief complaint, history of present illness
    
    # Objective - Clinical findings
    objective = db.Column(db.Text)  # Physical exam, vital signs, test results
    
    # Assessment - Diagnosis
    assessment = db.Column(db.Text)  # Clinical impression, diagnosis
    
    # Plan - Treatment plan
    plan = db.Column(db.Text)  # Treatment, medications, follow-up
    
    # Additional information
    differential_diagnosis = db.Column(db.Text)  # Other possible diagnoses
    
    # Attachments/References
    vital_signs_json = db.Column(db.Text)  # JSON of relevant vitals
    lab_results_json = db.Column(db.Text)  # JSON of relevant lab results
    
    # Versioning
    version = db.Column(db.Integer, default=1)
    is_current = db.Column(db.Boolean, default=True)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Doctor signature tracking
    signed_by = db.Column(db.String(100))
    signed_at = db.Column(db.DateTime)
    
    patient = db.relationship('User', foreign_keys=[patient_id])
    doctor = db.relationship('User', foreign_keys=[doctor_id])


# ==================== MEDICAL DOCUMENTS ====================

class MedicalDocument(db.Model):
    """Upload and manage medical documents (X-rays, scans, reports, etc.)"""
    __tablename__ = 'medical_documents'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    uploaded_by = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    
    # Document details
    document_type = db.Column(db.String(50))  # 'xray', 'ct_scan', 'mri', 'ultrasound', 'report', 'other'
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    
    # File information
    file_path = db.Column(db.String(500), nullable=False)
    file_size = db.Column(db.Integer)  # In bytes
    mime_type = db.Column(db.String(50))
    original_filename = db.Column(db.String(255))
    
    # Clinical information
    body_part = db.Column(db.String(100))  # 'Chest', 'Head', 'Abdomen', etc.
    imaging_date = db.Column(db.DateTime)  # When the image was taken
    
    # Interpretation
    radiologist_name = db.Column(db.String(100))
    findings = db.Column(db.Text)  # Clinical findings
    impression = db.Column(db.Text)  # Overall impression
    
    # Access control
    visibility = db.Column(db.Enum('patient', 'doctor', 'all_doctors', 'public'), default='all_doctors')
    
    # Metadata
    version = db.Column(db.Integer, default=1)
    is_latest = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    patient = db.relationship('User', foreign_keys=[patient_id])
    uploader = db.relationship('User', foreign_keys=[uploaded_by])


# ==================== HOSPITAL SETTINGS ====================

class HospitalSettings(db.Model):
    """Hospital-wide configuration"""
    __tablename__ = 'hospital_settings'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    
    # Hospital Information
    hospital_name = db.Column(db.String(255), nullable=False, unique=True)
    hospital_registration_number = db.Column(db.String(100))
    
    # Contact Information
    address = db.Column(db.Text)
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))
    postal_code = db.Column(db.String(20))
    country = db.Column(db.String(100))
    
    phone = db.Column(db.String(20))
    fax = db.Column(db.String(20))
    email = db.Column(db.String(100))
    website = db.Column(db.String(255))
    
    # Accreditation
    accreditation = db.Column(db.Text)  # JSON: ["ISO 9001", "JCI", etc.]
    license_number = db.Column(db.String(100))
    license_expiry = db.Column(db.Date)
    
    # Logo and Branding
    logo_path = db.Column(db.String(500))
    
    # Operating Hours
    opening_time = db.Column(db.String(10))  # "08:00"
    closing_time = db.Column(db.String(10))  # "18:00"
    
    # Financial Settings
    currency = db.Column(db.String(10), default='USD')
    tax_rate = db.Column(db.Numeric(5, 2))  # Percentage
    
    # Email Settings
    smtp_server = db.Column(db.String(100))
    smtp_port = db.Column(db.Integer)
    smtp_username = db.Column(db.String(100))
    smtp_password = db.Column(db.String(255))  # Should be encrypted
    smtp_from_email = db.Column(db.String(100))
    smtp_from_name = db.Column(db.String(100))
    
    # SMS Settings
    sms_gateway_enabled = db.Column(db.Boolean, default=False)
    sms_api_key = db.Column(db.String(255))
    
    # Created/Updated
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Department(db.Model):
    """Hospital departments"""
    __tablename__ = 'departments'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    hospital_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('hospital_settings.id'))
    
    department_name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    head_doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    
    phone = db.Column(db.String(20))
    email = db.Column(db.String(100))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    hospital = db.relationship('HospitalSettings')


class DepartmentAssignment(db.Model):
    """Doctor assignments to departments"""
    __tablename__ = 'department_assignments'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    department_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('departments.id'), nullable=False)
    
    role = db.Column(db.String(50))  # 'Senior Doctor', 'Specialist', 'Resident', etc.
    is_primary = db.Column(db.Boolean, default=False)
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=True)
    join_date = db.Column(db.DateTime, default=datetime.utcnow)
    leave_date = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    
    doctor = db.relationship('User', foreign_keys=[doctor_id])
    department = db.relationship('Department')


# ==================== EMAIL TRACKING ====================

class EmailLog(db.Model):
    """Track all emails sent to patients"""
    __tablename__ = 'email_logs'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    recipient_email = db.Column(db.String(100), nullable=False)
    recipient_user_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    
    # Email details
    subject = db.Column(db.String(255))
    body = db.Column(db.Text)
    email_type = db.Column(db.String(50))  # 'report_notification', 'alert', 'appointment_reminder', etc.
    
    # Attachment
    attachment_count = db.Column(db.Integer, default=0)
    attachment_paths = db.Column(db.Text)  # JSON list of file paths
    
    # Status
    status = db.Column(db.Enum('sent', 'pending', 'failed', 'bounced'), default='pending')
    sent_at = db.Column(db.DateTime)
    error_message = db.Column(db.Text)
    
    # Related records
    related_object_type = db.Column(db.String(50))  # 'consultation_note', 'alert', 'appointment', etc.
    related_object_id = db.Column(INTEGER(unsigned=True))
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    recipient = db.relationship('User', foreign_keys=[recipient_user_id])


# ==================== DOCTOR-PATIENT ASSIGNMENT ====================

class DoctorPatientAssignment(db.Model):
    """Tracks multiple doctors assigned to a patient (many-to-many relationship)"""
    __tablename__ = 'doctor_patient_assignments'
    
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), nullable=False)
    
    # Assignment details
    is_primary = db.Column(db.Boolean, default=False)  # Primary doctor for patient
    specialization_note = db.Column(db.String(100))  # Why this doctor (e.g., "Cardiologist", "Specialist")
    reason_for_assignment = db.Column(db.Text)  # Additional notes
    
    # Status
    status = db.Column(db.Enum('active', 'inactive', 'ended'), default='active')
    
    # Timeline
    assigned_at = db.Column(db.DateTime, default=datetime.utcnow)
    active_from = db.Column(db.DateTime, default=datetime.utcnow)
    active_until = db.Column(db.DateTime, nullable=True)  # NULL = ongoing
    
    # Relationships
    doctor = db.relationship('User', foreign_keys=[doctor_id], backref='patient_assignments')
    patient = db.relationship('User', foreign_keys=[patient_id], backref='doctor_assignments')
    
    def __repr__(self):
        return f"<DoctorPatientAssignment doctor_id={self.doctor_id} patient_id={self.patient_id}>"
