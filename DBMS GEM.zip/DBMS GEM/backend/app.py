from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_required, current_user
from flask_mail import Mail
import os
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables at startup
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
env_file = os.path.join(project_root, '.env')
print("[INFO] Loading .env from: " + env_file)
load_dotenv(dotenv_path=env_file)

from flask_socketio import SocketIO

db = SQLAlchemy()
socketio = SocketIO()
mail = Mail()

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = 'dev-secret-key-123'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost/gemcare'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Flask-Mail Configuration
    app.config['MAIL_SERVER'] = os.getenv('SMTP_SERVER')
    app.config['MAIL_PORT'] = int(os.getenv('SMTP_PORT', 587))
    app.config['MAIL_USE_TLS'] = True
    app.config['MAIL_USERNAME'] = os.getenv('SMTP_USERNAME')
    app.config['MAIL_PASSWORD'] = os.getenv('SMTP_PASSWORD')
    app.config['MAIL_DEFAULT_SENDER'] = os.getenv('SMTP_FROM_EMAIL')

    db.init_app(app)
    socketio.init_app(app, cors_allowed_origins="*", engineio_logger=False, async_mode='eventlet')
    mail.init_app(app)

    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    from .models import User
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Register Blueprints
    from .routes.auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint)

    from .routes.main import main as main_blueprint
    app.register_blueprint(main_blueprint)

    from .routes.api import api as api_blueprint
    app.register_blueprint(api_blueprint)

    from .routes.email_api import email_api as email_api_blueprint
    app.register_blueprint(email_api_blueprint)

    from .routes.profile import profile as profile_blueprint
    app.register_blueprint(profile_blueprint)

    from .routes.advanced_api import advanced_api as advanced_api_blueprint
    app.register_blueprint(advanced_api_blueprint)

    # SocketIO events for messaging
    @socketio.on('send_message')
    @login_required
    def handle_message(data):
        from .models import Message, db
        from flask import request
        
        receiver_id = data.get('receiver_id')
        content = data.get('message')
        
        # Core 17: Secure Messaging (Persistence)
        new_msg = Message(
            sender_id=current_user.id,
            receiver_id=receiver_id,
            content_encrypted=content # Placeholder for encryption
        )
        db.session.add(new_msg)
        db.session.commit()
        
        # Emit to specific users
        socketio.emit('new_message', {
            'sender_id': current_user.id,
            'message': content,
            'timestamp': datetime.utcnow().isoformat()
        }, room=f"user_{receiver_id}")
        
    @socketio.on('join')
    @login_required
    def on_join(data):
        from flask_socketio import join_room
        join_room(f"user_{current_user.id}")
        if current_user.role == 'patient':
            join_room(f"patient_{current_user.id}")

    return app

if __name__ == "__main__":
    app = create_app()
    socketio.run(app, debug=True)
