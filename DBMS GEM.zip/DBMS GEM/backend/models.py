from .app import db
from flask_login import UserMixin
from datetime import datetime
from sqlalchemy.dialects.mysql import INTEGER

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum('doctor', 'patient', 'caregiver', 'admin'), nullable=False)
    full_name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    profile_picture_url = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    patient_profile = db.relationship('PatientProfile', backref='user', uselist=False, foreign_keys='PatientProfile.patient_id')
    doctor_profile = db.relationship('DoctorProfile', backref='user', uselist=False, foreign_keys='DoctorProfile.doctor_id')
    caregiver_profile = db.relationship('CaregiverProfile', backref='user', uselist=False, foreign_keys='CaregiverProfile.caregiver_id')

class PatientProfile(db.Model):
    __tablename__ = 'patient_profiles'
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), primary_key=True)
    dob = db.Column(db.Date)
    gender = db.Column(db.Enum('male', 'female', 'other'))
    medical_history = db.Column(db.Text)
    emergency_contact_name = db.Column(db.String(100))
    emergency_contact_phone = db.Column(db.String(20))
    blood_group = db.Column(db.String(5))
    primary_doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    allergies = db.Column(db.Text)
    chronic_conditions = db.Column(db.Text)
    address = db.Column(db.Text)
    medical_history_doctor_locked = db.Column(db.Boolean, default=False)
    
    primary_doctor = db.relationship('User', foreign_keys=[primary_doctor_id])

class DoctorProfile(db.Model):
    __tablename__ = 'doctor_profiles'
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), primary_key=True)
    designation = db.Column(db.String(100))
    specialization = db.Column(db.String(100))
    hospital_name = db.Column(db.String(100))
    years_experience = db.Column(db.Integer)
    clinic_address = db.Column(db.Text)
    bio = db.Column(db.Text)

class CaregiverProfile(db.Model):
    __tablename__ = 'caregiver_profiles'
    caregiver_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), primary_key=True)
    relationship_to_patient = db.Column(db.String(50))
    caregiver_notes = db.Column(db.Text)

class VitalSign(db.Model):
    __tablename__ = 'vital_signs'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    heart_rate = db.Column(db.Numeric(5, 2))
    blood_pressure_sys = db.Column(db.Integer)
    blood_pressure_dia = db.Column(db.Integer)
    temperature = db.Column(db.Numeric(4, 2))
    oxygen_level = db.Column(db.Numeric(5, 2))
    glucose_level = db.Column(db.Numeric(5, 2))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class Threshold(db.Model):
    __tablename__ = 'thresholds'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    vital_type = db.Column(db.String(50))
    min_value = db.Column(db.Numeric(10, 2))
    max_value = db.Column(db.Numeric(10, 2))
    is_adaptive = db.Column(db.Boolean, default=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Alert(db.Model):
    __tablename__ = 'alerts'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    vital_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('vital_signs.id'))
    alert_type = db.Column(db.String(50))
    severity = db.Column(db.Enum('warning', 'critical'), default='warning')
    status = db.Column(db.Enum('active', 'acknowledged', 'escalated', 'resolved', 'closed'), default='active')
    description = db.Column(db.Text)
    explanation = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AlertEscalation(db.Model):
    __tablename__ = 'alert_escalations'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    alert_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('alerts.id'))
    previous_level = db.Column(db.Enum('warning', 'critical'))
    current_level = db.Column(db.Enum('warning', 'critical'))
    escalation_time = db.Column(db.DateTime, default=datetime.utcnow)

class Message(db.Model):
    __tablename__ = 'messages'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    sender_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    receiver_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    content_encrypted = db.Column(db.Text)
    is_read = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class DoctorNote(db.Model):
    __tablename__ = 'doctor_notes'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    content = db.Column(db.Text)
    version = db.Column(db.Integer, default=1)
    is_deleted = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Symptom(db.Model):
    __tablename__ = 'symptoms'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    description = db.Column(db.Text)
    severity = db.Column(db.Integer)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    user_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    action = db.Column(db.String(255))
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(45))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class HealthScore(db.Model):
    __tablename__ = 'health_scores'
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), primary_key=True)
    current_score = db.Column(db.Integer, default=100)
    risk_level = db.Column(db.Enum('low', 'moderate', 'high'), default='low')
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)

class Recommendation(db.Model):
    __tablename__ = 'recommendations'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    suggestion = db.Column(db.Text)
    category = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class CaregiverAssignment(db.Model):
    __tablename__ = 'caregiver_assignments'
    caregiver_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), primary_key=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), primary_key=True)
    access_level = db.Column(db.Enum('view', 'manage'), default='view')

class MedicalPolicy(db.Model):
    __tablename__ = 'medical_policies'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    policy_name = db.Column(db.String(255))
    rule_definition_json = db.Column(db.JSON)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class DigitalTwin(db.Model):
    __tablename__ = 'digital_twins'
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), primary_key=True)
    model_data = db.Column(db.JSON)
    last_simulation = db.Column(db.DateTime)

class CarePath(db.Model):
    __tablename__ = 'care_paths'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    steps_json = db.Column(db.JSON)
    status = db.Column(db.Enum('pending', 'in-progress', 'completed'))

class PatientConsent(db.Model):
    __tablename__ = 'patient_consent'
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'), primary_key=True)
    research_consent = db.Column(db.Boolean, default=False)
    data_sharing_consent = db.Column(db.Boolean, default=False)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)

class HealthReport(db.Model):
    __tablename__ = 'health_reports'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    patient_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    doctor_id = db.Column(INTEGER(unsigned=True), db.ForeignKey('users.id'))
    report_type = db.Column(db.String(50))
    description = db.Column(db.Text)
    file_path = db.Column(db.String(255))
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ValidationFlag(db.Model):
    __tablename__ = 'validation_flags'
    id = db.Column(INTEGER(unsigned=True), primary_key=True, autoincrement=True)
    entity_type = db.Column(db.String(50))
    entity_id = db.Column(INTEGER(unsigned=True))
    error_message = db.Column(db.Text)
    is_resolved = db.Column(db.Boolean, default=False)
    checked_at = db.Column(db.DateTime, default=datetime.utcnow)
