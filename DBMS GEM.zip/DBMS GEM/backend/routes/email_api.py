"""
Email API Routes for GemCare
Handles sending emails from doctors to patients and patients to doctors
"""

from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from ..services.email_service import EmailService
from ..models import User
from ..app import db

email_api = Blueprint('email_api', __name__, url_prefix='/api')

@email_api.route('/send-doctor-email', methods=['POST'])
@login_required
def send_doctor_email():
    """
    Doctor sends email to patient
    POST /api/send-doctor-email
    {
        "patient_email": "patient@example.com",
        "subject": "Email subject",
        "message": "Email message",
        "attach_report": false
    }
    """
    try:
        if current_user.role != 'doctor':
            return jsonify({'error': 'Only doctors can send emails to patients'}), 403

        data = request.get_json()
        patient_email = data.get('patient_email')
        subject = data.get('subject')
        message = data.get('message')
        attach_report = data.get('attach_report', False)

        if not patient_email or not subject or not message:
            return jsonify({'error': 'Missing required fields: patient_email, subject, message'}), 400

        # Initialize email service
        email_service = EmailService()

        # Create professional HTML email
        html_body = f"""
        <html>
            <body style="font-family: Segoe UI, Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; background: #f5f7fa; padding: 20px; border-radius: 8px;">
                    <div style="background: linear-gradient(135deg, #003366 0%, #004d99 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
                        <h1 style="margin: 0; font-size: 24px;">GemCare Healthcare Management</h1>
                        <p style="margin: 5px 0 0 0; opacity: 0.9;">Medical Communication</p>
                    </div>
                    <div style="background: white; padding: 30px; border-radius: 0 0 8px 8px;">
                        <p style="color: #666;">Dear Patient,</p>
                        <div style="background: #f9f9f9; padding: 20px; border-left: 4px solid #00A86B; margin: 20px 0; border-radius: 4px;">
                            <p style="margin: 0; color: #333; font-size: 16px; line-height: 1.6;">{message}</p>
                        </div>
                        <p style="color: #666; margin-top: 20px;">Regards,<br/>
                        <strong>Dr. {current_user.full_name}</strong><br/>
                        {current_user.doctor_profile.specialization if current_user.doctor_profile else 'Healthcare Professional'}</p>
                        
                        <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
                        <p style="color: #999; font-size: 12px; text-align: center;">
                            This is an automated medical communication from GemCare Healthcare System.<br/>
                            Please do not reply to this email. Use the patient portal to send messages.
                        </p>
                    </div>
                </div>
            </body>
        </html>
        """

        text_body = f"Dear Patient,\n\n{message}\n\nRegards,\nDr. {current_user.full_name}"

        # Send email
        result = email_service._send_email_smtp(
            recipient_email=patient_email,
            subject=f"[GemCare] {subject}",
            html_body=html_body,
            text_body=text_body
        )

        if result['success']:
            return jsonify({
                'success': True,
                'message': f'Email sent successfully to {patient_email}'
            }), 200
        else:
            return jsonify({
                'error': result.get('error', 'Failed to send email')
            }), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@email_api.route('/send-record-email', methods=['POST'])
@login_required
def send_record_email():
    """
    Patient requests medical record via email
    POST /api/send-record-email
    {
        "record_id": "record_123",
        "message": "Optional message"
    }
    """
    try:
        if current_user.role != 'patient':
            return jsonify({'error': 'Only patients can request record emails'}), 403

        data = request.get_json()
        record_id = data.get('record_id')
        message = data.get('message', '')

        if not record_id:
            return jsonify({'error': 'Missing required field: record_id'}), 400

        # Initialize email service
        email_service = EmailService()

        # Create professional HTML email
        html_body = f"""
        <html>
            <body style="font-family: Segoe UI, Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; background: #f5f7fa; padding: 20px; border-radius: 8px;">
                    <div style="background: linear-gradient(135deg, #003366 0%, #004d99 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
                        <h1 style="margin: 0; font-size: 24px;">GemCare Medical Record</h1>
                        <p style="margin: 5px 0 0 0; opacity: 0.9;">Your Requested Document</p>
                    </div>
                    <div style="background: white; padding: 30px; border-radius: 0 0 8px 8px;">
                        <p style="color: #666;">Dear {current_user.full_name},</p>
                        <div style="background: #f0fff4; padding: 20px; border-left: 4px solid #00A86B; margin: 20px 0; border-radius: 4px;">
                            <p style="margin: 0; color: #333; font-size: 14px;">
                                ✓ Your medical record <strong>{record_id}</strong> has been prepared and is ready for download.<br/>
                                ✓ You can access it from your patient portal anytime.<br/>
                                ✓ The record is securely encrypted and protected.
                            </p>
                        </div>
                        <p style="color: #666; margin-top: 20px;">
                            <strong>Record Details:</strong><br/>
                            Type: {record_id}<br/>
                            Generated: {__import__('datetime').datetime.now().strftime('%B %d, %Y at %I:%M %p')}<br/>
                            Status: Ready for Download
                        </p>

                        {f'<p style="color: #666; margin-top: 15px;"><strong>Your Note:</strong><br/><em>{message}</em></p>' if message else ''}
                        
                        <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
                        <p style="color: #999; font-size: 12px; text-align: center;">
                            This email contains your confidential medical information.<br/>
                            If you did not request this record, please contact us immediately.
                        </p>
                    </div>
                </div>
            </body>
        </html>
        """

        text_body = f"Dear {current_user.full_name},\n\nYour medical record {record_id} has been prepared. You can download it from your patient portal."

        # Send email
        result = email_service._send_email_smtp(
            recipient_email=current_user.email,
            subject=f"[GemCare] Your Medical Record - {record_id}",
            html_body=html_body,
            text_body=text_body
        )

        if result['success']:
            return jsonify({
                'success': True,
                'message': f'Medical record sent to {current_user.email}'
            }), 200
        else:
            return jsonify({
                'error': result.get('error', 'Failed to send email')
            }), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@email_api.route('/send-appointment-reminder', methods=['POST'])
@login_required
def send_appointment_reminder():
    """
    Send appointment reminder email to patient
    POST /api/send-appointment-reminder
    {
        "patient_id": 123,
        "appointment_date": "2026-04-15",
        "appointment_time": "10:00 AM",
        "doctor_name": "Dr. Rajesh Kumar"
    }
    """
    try:
        if current_user.role != 'doctor':
            return jsonify({'error': 'Only doctors can send appointment reminders'}), 403

        data = request.get_json()
        patient_id = data.get('patient_id')
        appointment_date = data.get('appointment_date')
        appointment_time = data.get('appointment_time')
        doctor_name = data.get('doctor_name', f'Dr. {current_user.full_name}')

        if not patient_id or not appointment_date or not appointment_time:
            return jsonify({'error': 'Missing required fields'}), 400

        # Get patient
        patient = User.query.get(patient_id)
        if not patient or patient.role != 'patient':
            return jsonify({'error': 'Patient not found'}), 404

        # Initialize email service
        email_service = EmailService()

        # Create professional HTML email
        html_body = f"""
        <html>
            <body style="font-family: Segoe UI, Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; background: #f5f7fa; padding: 20px; border-radius: 8px;">
                    <div style="background: linear-gradient(135deg, #003366 0%, #004d99 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
                        <h1 style="margin: 0; font-size: 24px;">Appointment Reminder</h1>
                        <p style="margin: 5px 0 0 0; opacity: 0.9;">GemCare Healthcare System</p>
                    </div>
                    <div style="background: white; padding: 30px; border-radius: 0 0 8px 8px;">
                        <p style="color: #666;">Dear {patient.full_name},</p>
                        <div style="background: #e7f3ff; padding: 20px; border-left: 4px solid #003366; margin: 20px 0; border-radius: 4px;">
                            <p style="margin: 0 0 10px 0; color: #003366; font-weight: bold; font-size: 16px;">📅 Appointment Scheduled</p>
                            <p style="margin: 5px 0; color: #333;">Doctor: <strong>{doctor_name}</strong></p>
                            <p style="margin: 5px 0; color: #333;">Date: <strong>{appointment_date}</strong></p>
                            <p style="margin: 5px 0; color: #333;">Time: <strong>{appointment_time}</strong></p>
                        </div>
                        <p style="color: #666; margin-top: 20px;">Please arrive 5-10 minutes early. If you need to reschedule, please notify us at least 24 hours in advance.</p>
                        <p style="color: #666; margin-top: 15px;">You can access the appointment details through your patient portal at any time.</p>
                        
                        <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
                        <p style="color: #999; font-size: 12px; text-align: center;">
                            GemCare Healthcare Management System
                        </p>
                    </div>
                </div>
            </body>
        </html>
        """

        text_body = f"Dear {patient.full_name},\n\nYou have an appointment scheduled:\nDoctor: {doctor_name}\nDate: {appointment_date}\nTime: {appointment_time}\n\nPlease arrive early."

        # Send email
        result = email_service._send_email_smtp(
            recipient_email=patient.email,
            subject=f"[GemCare] Appointment Reminder - {appointment_date}",
            html_body=html_body,
            text_body=text_body
        )

        if result['success']:
            return jsonify({
                'success': True,
                'message': f'Appointment reminder sent to {patient.email}'
            }), 200
        else:
            return jsonify({
                'error': result.get('error', 'Failed to send email')
            }), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500
