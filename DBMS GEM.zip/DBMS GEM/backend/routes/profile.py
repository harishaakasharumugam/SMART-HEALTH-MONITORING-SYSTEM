from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from ..models import User, PatientProfile, DoctorProfile, CaregiverProfile
from ..models_extended import PatientExtendedProfile
from ..app import db
import os
from datetime import datetime

profile = Blueprint('profile', __name__)

# Configure upload folder
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), '..', 'static', 'uploads', 'profiles')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@profile.route('/profile', methods=['GET', 'POST'])
@login_required
def unified_profile():
    """Unified profile page that redirects to appropriate profile based on role"""
    if current_user.role == 'patient':
        return redirect(url_for('profile.patient_profile'))
    elif current_user.role == 'doctor':
        return redirect(url_for('profile.doctor_profile'))
    elif current_user.role == 'caregiver':
        return redirect(url_for('profile.caregiver_profile'))
    else:
        return redirect(url_for('main.dashboard'))

@profile.route('/upload-profile-picture', methods=['POST'])
@login_required
def upload_profile_picture():
    """Upload user profile picture"""
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file provided'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'success': False, 'message': 'File type not allowed. Use PNG, JPG, JPEG, or GIF'}), 400
    
    try:
        # Generate unique filename
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = f"{current_user.id}_{datetime.utcnow().timestamp()}.{ext}"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        
        # Save file
        file.save(filepath)
        
        # Update user profile picture URL
        profile_url = f"/static/uploads/profiles/{filename}"
        current_user.profile_picture_url = profile_url
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Profile picture uploaded successfully',
            'profile_picture_url': profile_url
        }), 200
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error uploading file: {str(e)}'}), 500

@profile.route('/patient-profile', methods=['GET', 'POST'])
@login_required
def patient_profile():
    """View/Edit patient profile"""
    if current_user.role != 'patient':
        return redirect(url_for('main.dashboard'))
    
    patient_profile = PatientProfile.query.get(current_user.id)
    patient_extended = PatientExtendedProfile.query.get(current_user.id) if PatientExtendedProfile else None
    
    if request.method == 'POST':
        try:
            # Update basic profile
            patient_profile.dob = request.form.get('dob') if request.form.get('dob') else None
            patient_profile.gender = request.form.get('gender')
            patient_profile.blood_group = request.form.get('blood_group')
            patient_profile.address = request.form.get('address')
            patient_profile.allergies = request.form.get('allergies')
            patient_profile.chronic_conditions = request.form.get('chronic_conditions')
            patient_profile.emergency_contact_name = request.form.get('emergency_contact_name')
            patient_profile.emergency_contact_phone = request.form.get('emergency_contact_phone')
            
            # Update extended profile if exists, create if not
            if not patient_extended:
                patient_extended = PatientExtendedProfile(patient_id=current_user.id)
                db.session.add(patient_extended)
            
            patient_extended.occupation = request.form.get('occupation')
            patient_extended.smoking_status = request.form.get('smoking_status')
            patient_extended.alcohol_consumption = request.form.get('alcohol_consumption')
            patient_extended.exercise_frequency = request.form.get('exercise_frequency')
            patient_extended.insurance_provider = request.form.get('insurance_provider')
            patient_extended.policy_number = request.form.get('policy_number')
            
            db.session.commit()
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('profile.patient_profile'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating profile: {str(e)}', 'error')
    
    return render_template('patient_profile.html', patient=patient_profile, patient_extended=patient_extended)

@profile.route('/doctor-profile', methods=['GET', 'POST'])
@login_required
def doctor_profile():
    """View/Edit doctor profile"""
    if current_user.role != 'doctor':
        return redirect(url_for('main.dashboard'))
    
    doctor_profile = DoctorProfile.query.get(current_user.id)
    
    if request.method == 'POST':
        try:
            if not doctor_profile:
                doctor_profile = DoctorProfile(doctor_id=current_user.id)
                db.session.add(doctor_profile)
            
            doctor_profile.specialization = request.form.get('specialization')
            doctor_profile.designation = request.form.get('designation')
            doctor_profile.hospital_name = request.form.get('hospital_name')
            doctor_profile.clinic_address = request.form.get('clinic_address')
            doctor_profile.years_experience = int(request.form.get('years_experience')) if request.form.get('years_experience') else None
            doctor_profile.bio = request.form.get('bio')
            doctor_profile.license_number = request.form.get('license_number')
            doctor_profile.medical_council_registration = request.form.get('medical_council_registration')
            
            db.session.commit()
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('profile.doctor_profile'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating profile: {str(e)}', 'error')
    
    return render_template('doctor_profile.html', doctor=doctor_profile)

@profile.route('/caregiver-profile', methods=['GET', 'POST'])
@login_required
def caregiver_profile():
    """View/Edit caregiver profile"""
    if current_user.role != 'caregiver':
        return redirect(url_for('main.dashboard'))
    
    caregiver_profile = CaregiverProfile.query.get(current_user.id)
    
    if request.method == 'POST':
        try:
            if not caregiver_profile:
                caregiver_profile = CaregiverProfile(caregiver_id=current_user.id)
                db.session.add(caregiver_profile)
            
            caregiver_profile.relationship_to_patient = request.form.get('relationship_to_patient')
            caregiver_profile.profession = request.form.get('profession')
            caregiver_profile.availability = request.form.get('availability')
            caregiver_profile.can_administer_medications = request.form.get('can_administer_medications') == 'on'
            caregiver_profile.can_assist_mobility = request.form.get('can_assist_mobility') == 'on'
            
            db.session.commit()
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('profile.caregiver_profile'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating profile: {str(e)}', 'error')
    
    return render_template('caregiver_profile.html', caregiver=caregiver_profile)
