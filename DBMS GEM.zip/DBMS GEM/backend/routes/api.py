from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from ..models import VitalSign, Alert, db
from datetime import datetime
import os

api = Blueprint('api', __name__)

from ..services.vitals_checker import check_vitals, ensure_default_thresholds
from ..app import socketio
from sqlalchemy import or_

from ..services.audit_service import log_audit

@api.route('/api/vitals', methods=['POST'])
@login_required
@log_audit("Added Vitals Reading")
def add_vitals():
    data = request.json or {}
    
    # Cast incoming data to appropriate types for validation/db
    try:
        if data.get('heart_rate'): data['heart_rate'] = float(data['heart_rate'])
        if data.get('blood_pressure_sys'): data['blood_pressure_sys'] = int(data['blood_pressure_sys'])
        if data.get('blood_pressure_dia'): data['blood_pressure_dia'] = int(data['blood_pressure_dia'])
        if data.get('oxygen_level'): data['oxygen_level'] = float(data['oxygen_level'])
        if data.get('temperature'): data['temperature'] = float(data['temperature'])
        if data.get('glucose_level'): data['glucose_level'] = float(data['glucose_level'])
    except (ValueError, TypeError):
        return jsonify({"status": "error", "errors": ["Invalid numeric data provided."]}), 400
    
    # Advanced 21: Consistency Validation
    from ..services.advanced_logic import validate_health_data
    errors = validate_health_data(data)
    if errors:
        return jsonify({"status": "error", "errors": errors}), 400

    target_patient_id = data.get('patient_id') if current_user.role == 'doctor' else current_user.id
    if not target_patient_id:
        return jsonify({"status": "error", "message": "Missing patient ID"}), 400

    new_vital = VitalSign(
        patient_id=target_patient_id,
        heart_rate=data.get('heart_rate'),
        blood_pressure_sys=data.get('blood_pressure_sys'),
        blood_pressure_dia=data.get('blood_pressure_dia'),
        temperature=data.get('temperature', 98.6),
        oxygen_level=data.get('oxygen_level'),
        glucose_level=data.get('glucose_level', 90)
    )
    db.session.add(new_vital)
    db.session.commit()
    
    # Core 4: Abnormal Reading Detection & Core 5: Alert Generation
    alerts = check_vitals(target_patient_id, new_vital)
    
    if alerts:
        from ..models import User
        target_patient = User.query.get(target_patient_id)
        for alert in alerts:
            socketio.emit('new_alert', {
                'id': alert.id,
                'type': alert.alert_type,
                'severity': alert.severity,
                'message': alert.description
            }, room=f"patient_{target_patient_id}")
            
            socketio.emit('doctor_alert', {
                'patient_name': target_patient.full_name if target_patient else "Unknown",
                'type': alert.alert_type,
                'severity': alert.severity
            })

    # Core 9: Generate personalized recommendations after vitals are logged
    from ..services.risk_assessment import calculate_health_score, generate_recommendations
    try:
        h_score = calculate_health_score(target_patient_id)
        generate_recommendations(target_patient_id, h_score)
        print(f"✓ Recommendations generated for patient {target_patient_id}")
    except Exception as e:
        print(f"⚠️  Could not generate recommendations: {e}")

    # Generate Digital Twin after vitals recorded
    try:
        _generate_digital_twin_data(target_patient_id)
    except Exception as e:
        print(f"⚠️  Could not generate digital twin: {e}")

    return jsonify({"status": "success", "alert_count": len(alerts) if alerts else 0}), 201

@api.route('/api/risk-assessment', methods=['GET'])
@login_required
def get_risk_assessment():
    from ..services.risk_assessment import calculate_health_score, generate_recommendations
    h_score = calculate_health_score(current_user.id)
    recs = generate_recommendations(current_user.id, h_score)
    return jsonify({
        "score": h_score.current_score,
        "risk_level": h_score.risk_level,
        "recommendations": recs
    })

@api.route('/api/generate-report', methods=['POST'])
@login_required
def generate_report():
    try:
        from ..services.report_generator import generate_patient_report
        from ..services.notifier import send_report_notification
        from ..models import User, VitalSign, Alert, HealthReport
        
        vitals = VitalSign.query.filter_by(patient_id=current_user.id).order_by(VitalSign.timestamp.desc()).all()
        alerts = Alert.query.filter_by(patient_id=current_user.id).order_by(Alert.created_at.desc()).all()
        
        reports_dir = os.path.join(os.getcwd(), 'static', 'reports')
        filepath = generate_patient_report(current_user, vitals, alerts, reports_dir)
        
        new_report = HealthReport(
            patient_id=current_user.id,
            report_type='Full Health Summary',
            file_path=filepath
        )
        db.session.add(new_report)
        db.session.commit()
        
        # Send notification via email and SMS
        notification_result = send_report_notification(current_user, filepath)
        
        return jsonify({
            "status": "success", 
            "file_path": filepath,
            "notifications": {
                "email_sent": notification_result["email_sent"],
                "sms_sent": notification_result["sms_sent"],
                "message": "Report generated and notifications sent successfully"
            }
        })
    except Exception as e:
        import traceback
        error_msg = str(e)
        print(f"✗ Report Generation Error: {error_msg}")
        print(traceback.format_exc())
        return jsonify({
            "status": "error",
            "message": f"Failed to generate report: {error_msg}"
        }), 500

@api.route('/api/alerts', methods=['GET'])
@login_required
def get_alerts():
    from ..models import Alert
    if current_user.role == 'doctor':
        alerts = Alert.query.order_by(Alert.created_at.desc()).all()
    else:
        alerts = Alert.query.filter_by(patient_id=current_user.id).order_by(Alert.created_at.desc()).all()
    
    return jsonify([{
        "id": a.id,
        "type": a.alert_type,
        "severity": a.severity,
        "status": a.status,
        "description": a.description,
        "explanation": a.explanation,
        "created_at": a.created_at.isoformat(),
        "patient_name": a.patient.full_name if a.patient else "Unknown"
    } for a in alerts])

@api.route('/api/missed-data', methods=['GET'])
@login_required
def check_missed_data():
    """ Feature 14: Missed Health Data Detection """
    from ..models import VitalSign
    from datetime import datetime, timedelta
    last_vital = VitalSign.query.filter_by(patient_id=current_user.id).order_by(VitalSign.timestamp.desc()).first()
    if not last_vital or last_vital.timestamp < datetime.utcnow() - timedelta(hours=24):
        return jsonify({"status": "missing", "message": "You haven't logged vitals in over 24 hours. Please update your records."})
    return jsonify({"status": "ok"})
@api.route('/api/alerts/<int:alert_id>/acknowledge', methods=['POST'])
@login_required
@log_audit("Acknowledged Alert")
def acknowledge_alert(alert_id):
    alert = Alert.query.get_or_404(alert_id)
    alert.status = 'acknowledged'
    db.session.commit()
    return jsonify({"status": "success"})

@api.route('/api/symptoms/search', methods=['GET'])
@login_required
def search_symptoms():
    from ..services.symptom_search import find_similar_symptoms
    from ..services.ollama_service import get_symptom_analysis
    query = request.args.get('q', '')
    if not query:
        return jsonify({"matches": [], "ai_analysis": None})
        
    matches = find_similar_symptoms(query)
    ai_analysis = get_symptom_analysis(query)
    
    # Ensure ai_analysis is never None
    if ai_analysis is None:
        ai_analysis = "Analysis unavailable. Your symptoms have been recorded for your physician's review."
    
    return jsonify({
        "matches": matches,
        "ai_analysis": ai_analysis
    })

@api.route('/api/analyze-symptoms', methods=['POST'])
@login_required
def analyze_symptoms():
    """AI-Powered Symptom Analysis using Gemini for the symptom checker chatbot"""
    data = request.json or {}
    symptoms = data.get('symptoms', '').strip()
    
    if not symptoms:
        return jsonify({"status": "error", "message": "Please provide symptoms to analyze"}), 400
    
    try:
        # Use Gemini service for AI analysis
        from ..services.gemini_service import get_symptom_analysis
        
        analysis = get_symptom_analysis(symptoms)
        
        if analysis:
            return jsonify({
                "status": "success",
                "analysis": analysis
            })
        else:
            return jsonify({
                "status": "error",
                "message": "Unable to analyze symptoms at this moment"
            }), 500
            
    except Exception as e:
        print(f"Error in symptom analysis: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "status": "error",
            "message": f"Server error: {str(e)[:100]}"
        }), 500

def _generate_digital_twin_data(patient_id):
    """Helper function to generate and store digital twin data"""
    from ..services.digital_twin import simulate_health_outcome
    from ..models import DigitalTwin
    
    vitals = VitalSign.query.filter_by(patient_id=patient_id).order_by(VitalSign.timestamp.desc()).limit(20).all()
    if not vitals:
        return None
    
    # Generate simulation
    result = simulate_health_outcome(patient_id, vitals)
    
    if result.get("status") == "success":
        # Check if digital twin exists
        digital_twin = DigitalTwin.query.filter_by(patient_id=patient_id).first()
        
        if not digital_twin:
            # Create new digital twin record
            digital_twin = DigitalTwin(
                patient_id=patient_id,
                model_data={
                    "predictions": result.get("predictions", []),
                    "summary": result.get("summary", ""),
                    "trends": result.get("trends", {}),
                    "simulation_timestamp": result.get("simulation_timestamp")
                },
                last_simulation=datetime.utcnow()
            )
            db.session.add(digital_twin)
        else:
            # Update existing digital twin
            digital_twin.model_data = {
                "predictions": result.get("predictions", []),
                "summary": result.get("summary", ""),
                "trends": result.get("trends", {}),
                "simulation_timestamp": result.get("simulation_timestamp")
            }
            digital_twin.last_simulation = datetime.utcnow()
        
        db.session.commit()
        return digital_twin
    return None

@api.route('/api/digital-twin/simulate', methods=['GET'])
@login_required
def simulate_twin():
    from ..services.digital_twin import simulate_health_outcome
    vitals = VitalSign.query.filter_by(patient_id=current_user.id).order_by(VitalSign.timestamp.desc()).limit(20).all()
    result = simulate_health_outcome(current_user.id, vitals)
    return jsonify(result)

@api.route('/api/doctor-notes', methods=['POST'])
@login_required
def add_doctor_note():
    """ Feature 13: Doctor Notes with Version History """
    from ..models import DoctorNote
    data = request.json
    new_note = DoctorNote(
        patient_id=data.get('patient_id'),
        doctor_id=current_user.id,
        content=data.get('content'),
        version=data.get('version', 1)
    )
    db.session.add(new_note)
    db.session.commit()
    return jsonify({"status": "success"})

@api.route('/api/appointments/suggest', methods=['GET'])
@login_required
def get_appointment_suggestions():
    """ Feature 15: Appointment Suggestions """
    from ..services.advanced_logic import suggest_appointments
    from ..models import HealthScore
    h_score = HealthScore.query.get(current_user.id)
    suggestion = suggest_appointments(current_user.id, h_score.risk_level if h_score else 'low')
    return jsonify(suggestion or {})

@api.route('/api/caregiver/access', methods=['POST'])
@login_required
def manage_caregiver_access():
    """ Feature 16: Family / Caregiver Access Control """
    from ..models import CaregiverAssignment
    data = request.json
    assignment = CaregiverAssignment(
        caregiver_id=data.get('caregiver_id'),
        patient_id=current_user.id,
        access_level=data.get('access_level', 'view')
    )
    db.session.add(assignment)
    db.session.commit()
    return jsonify({"status": "success"})

@api.route('/api/research/export', methods=['GET'])
@login_required
def export_anonymized_data():
    """ Feature 18 & 32: Data Anonymization Toolkit """
    from ..services.anonymization import anonymize_vitals
    from ..models import VitalSign, PatientConsent
    
    # For doctors, allow without consent check
    if current_user.role == 'doctor':
        vitals = VitalSign.query.all()
        anonymized = anonymize_vitals(vitals)
        return jsonify(anonymized)
    
    # For patients, require consent
    consent = PatientConsent.query.get(current_user.id)
    if not consent or not consent.research_consent:
        return jsonify({"status": "error", "message": "Research consent not provided."}), 403
        
    vitals = VitalSign.query.all()
    anonymized = anonymize_vitals(vitals)
    return jsonify(anonymized)

@api.route('/api/analytics/doctor', methods=['GET'])
@login_required
def get_doctor_analytics():
    """ Doctor Analytics: View anonymized patient pool data """
    try:
        if current_user.role != 'doctor':
            return jsonify({"status": "error", "message": "Only doctors can access analytics"}), 403
        
        from ..models import VitalSign, PatientProfile
        from ..services.anonymization import anonymize_vitals
        
        # Get all patients assigned to this doctor
        patient_profiles = PatientProfile.query.filter_by(primary_doctor_id=current_user.id).all()
        patient_ids = [p.patient_id for p in patient_profiles]
        
        # If no patients assigned, return empty list
        if not patient_ids:
            return jsonify([])
        
        # Get vitals for doctor's patients
        vitals = VitalSign.query.filter(VitalSign.patient_id.in_(patient_ids)).order_by(VitalSign.timestamp.desc()).limit(500).all()
        
        # If no vitals, return empty list
        if not vitals:
            return jsonify([])
        
        # Anonymize the data
        anonymized = anonymize_vitals(vitals)
        
        # Ensure it's a list
        if isinstance(anonymized, dict) and 'data' in anonymized:
            return jsonify(anonymized['data'])
        elif isinstance(anonymized, list):
            return jsonify(anonymized)
        else:
            return jsonify([anonymized] if anonymized else [])
            
    except Exception as e:
        print(f"Analytics Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"status": "error", "message": str(e)}), 500
@api.route('/api/profile/update', methods=['PATCH'])
@login_required
@log_audit("Updated Profile")
def update_profile():
    data = request.json
    current_user.full_name = data.get('full_name', current_user.full_name)
    current_user.email = data.get('email', current_user.email)
    
    if current_user.role == 'doctor':
        from ..models import DoctorProfile
        profile = current_user.doctor_profile
        if not profile:
            profile = DoctorProfile(doctor_id=current_user.id)
            db.session.add(profile)
        profile.designation = data.get('designation', profile.designation)
        profile.specialization = data.get('specialization', profile.specialization)
        profile.hospital_name = data.get('hospital_name', profile.hospital_name)
        profile.years_experience = data.get('years_experience', profile.years_experience)
        profile.clinic_address = data.get('clinic_address', profile.clinic_address)
        profile.bio = data.get('bio', profile.bio)
    elif current_user.role == 'patient':
        from ..models import PatientProfile
        profile = current_user.patient_profile
        if not profile:
            profile = PatientProfile(patient_id=current_user.id)
            db.session.add(profile)
        if not profile.medical_history_doctor_locked:
            profile.medical_history = data.get('medical_history', profile.medical_history)
        profile.blood_group = data.get('blood_group', profile.blood_group)
        profile.allergies = data.get('allergies', profile.allergies)
        profile.chronic_conditions = data.get('chronic_conditions', profile.chronic_conditions)
        profile.address = data.get('address', profile.address)
        profile.primary_doctor_id = data.get('primary_doctor_id', profile.primary_doctor_id)
    elif current_user.role == 'caregiver':
        from ..models import CaregiverProfile
        profile = current_user.caregiver_profile
        if not profile:
            profile = CaregiverProfile(caregiver_id=current_user.id)
            db.session.add(profile)
        profile.relationship_to_patient = data.get('relationship', profile.relationship_to_patient)
        profile.caregiver_notes = data.get('notes', profile.caregiver_notes)
    
    db.session.commit()
    return jsonify({"status": "success"})

@api.route('/api/patients/<int:id>', methods=['PATCH'])
@login_required
def doctor_update_patient(id):
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Unauthorized"}), 403
    
    from ..models import User, PatientProfile
    patient = User.query.get_or_404(id)
    if patient.role != 'patient':
        return jsonify({"status": "error", "message": "Invalid user role"}), 400
        
    data = request.json
    patient.full_name = data.get('full_name', patient.full_name)
    
    profile = patient.patient_profile
    if not profile:
        profile = PatientProfile(patient_id=patient.id)
        db.session.add(profile)
    
    # Doctor editing history locks it for the patient
    if 'medical_history' in data:
        profile.medical_history = data['medical_history']
        profile.medical_history_doctor_locked = True
        profile.medical_history_doctor_locked = True
        
    profile.blood_group = data.get('blood_group', profile.blood_group)
    profile.allergies = data.get('allergies', profile.allergies)
    profile.chronic_conditions = data.get('chronic_conditions', profile.chronic_conditions)
    profile.address = data.get('address', profile.address)
    
    db.session.commit()
    return jsonify({"status": "success"})

@api.route('/api/doctors', methods=['GET'])
@login_required
def get_doctors_list():
    from ..models import User
    doctors = User.query.filter_by(role='doctor').all()
    return jsonify([{
        "id": d.id,
        "full_name": d.full_name,
        "specialization": d.doctor_profile.specialization if d.doctor_profile else "General Physician"
    } for d in doctors])

@api.route('/api/patients/search', methods=['GET'])
@login_required
def search_patients():
    from ..models import User, CaregiverAssignment
    query = request.args.get('q', '').lower()
    if not query:
        return jsonify([])

    # Search by patient username
    patients = User.query.filter(User.role == 'patient', User.username.ilike(f"%{query}%")).all()
    
    # Search by caregiver username
    caregivers = User.query.filter(User.role == 'caregiver', User.username.ilike(f"%{query}%")).all()
    for cg in caregivers:
        assignments = CaregiverAssignment.query.filter_by(caregiver_id=cg.id).all()
        for ass in assignments:
            p = User.query.get(ass.patient_id)
            if p not in patients:
                patients.append(p)

    # Auto-assign searching doctor as primary if none assigned
    from ..models import PatientProfile
    for p in patients:
        if not p.patient_profile.primary_doctor_id:
            p.patient_profile.primary_doctor_id = current_user.id
    db.session.commit()

    return jsonify([{
        "id": p.id,
        "full_name": p.full_name,
        "username": p.username,
        "risk_level": p.health_score.risk_level if p.health_score else 'unknown'
    } for p in patients])
@api.route('/api/messages', methods=['GET'])
@login_required
def get_messages():
    """ Feature 17: Secure Doctor–Patient Messaging """
    from ..models import Message, User
    recipient_id = request.args.get('recipient_id')
    if not recipient_id:
        # Get list of recent contacts
        sent = db.session.query(Message.receiver_id).filter_by(sender_id=current_user.id).distinct().all()
        received = db.session.query(Message.sender_id).filter_by(receiver_id=current_user.id).distinct().all()
        contact_ids = set([r[0] for r in sent] + [r[0] for r in received])
        
        # If doctor, also show all their patients
        if current_user.role == 'doctor':
            from ..models import PatientProfile
            patients = PatientProfile.query.filter_by(primary_doctor_id=current_user.id).all()
            for p in patients:
                contact_ids.add(p.patient_id)
        elif current_user.role == 'patient':
            if current_user.patient_profile and current_user.patient_profile.primary_doctor_id:
                contact_ids.add(current_user.patient_profile.primary_doctor_id)
            # Also show caregivers
            from ..models import CaregiverAssignment
            caregivers = CaregiverAssignment.query.filter_by(patient_id=current_user.id).all()
            for cg in caregivers:
                contact_ids.add(cg.caregiver_id)
                
        contacts = User.query.filter(User.id.in_(contact_ids)).all()
        return jsonify([{
            "id": c.id,
            "full_name": c.full_name,
            "role": c.role,
            "username": c.username
        } for c in contacts])

    # Get conversation history
    messages = Message.query.filter(
        or_(
            (Message.sender_id == current_user.id) & (Message.receiver_id == recipient_id),
            (Message.sender_id == recipient_id) & (Message.receiver_id == current_user.id)
        )
    ).order_by(Message.timestamp.asc()).all()
    
    return jsonify([{
        "id": m.id,
        "sender_id": m.sender_id,
        "content": m.content_encrypted, # In real app, decrypt here
        "timestamp": m.timestamp.isoformat(),
        "is_mine": m.sender_id == current_user.id
    } for m in messages])

@api.route('/api/messages', methods=['POST'])
@login_required
def send_message():
    from ..models import Message, User
    from ..services.notifier import send_email_alert, trigger_sms_alert
    
    data = request.json
    recipient_id = data.get('recipient_id')
    content = data.get('content')
    
    if not recipient_id or not content:
        return jsonify({"status": "error", "message": "Missing recipient or content"}), 400
        
    new_msg = Message(
        sender_id=current_user.id,
        receiver_id=recipient_id,
        content_encrypted=content # Simplified: no real encryption for this DBMS project
    )
    db.session.add(new_msg)
    db.session.commit()
    
    # Get recipient for notifications
    recipient = User.query.get(recipient_id)
    
    # Send email notification if doctor is messaging patient
    if current_user.role == 'doctor' and recipient.role == 'patient' and recipient.email:
        email_subject = f"Message from Dr. {current_user.full_name} - GEMCARE"
        email_body = f"""You have received a secure message from your healthcare provider:

Dr. {current_user.full_name}

Message:
"{content}"

Please log in to your GEMCARE account to reply. 

This is a confidential medical communication."""
        
        send_email_alert(
            recipient_email=recipient.email,
            subject=email_subject,
            body=email_body,
            patient_name=recipient.full_name
        )
        
        # Also send SMS if phone exists
        if recipient.phone:
            sms_text = f"You have a message from Dr. {current_user.full_name}. Log in to GEMCARE to view: {content[:60]}..."
            trigger_sms_alert(recipient.phone, sms_text)
    
    # Notify recipient via SocketIO (Feature 17)
    socketio.emit('new_message', {
        'sender_id': current_user.id,
        'sender_name': current_user.full_name,
        'content': content
    }, room=f"user_{recipient_id}")
    
    return jsonify({
        "status": "success", 
        "id": new_msg.id,
        "notifications_sent": {
            "email": current_user.role == 'doctor' and recipient.role == 'patient' and bool(recipient.email),
            "sms": current_user.role == 'doctor' and recipient.role == 'patient' and bool(recipient.phone)
        }
    })

@api.route('/api/patients/<int:patient_id>', methods=['PATCH'])
@login_required
def update_patient_details(patient_id):
    """ Feature 2: Patient Profile Management (Doctor override) """
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Unauthorized"}), 403
        
    from ..models import User, PatientProfile
    patient = User.query.get_or_404(patient_id)
    data = request.json
    
    patient.full_name = data.get('full_name', patient.full_name)
    if patient.patient_profile:
        patient.patient_profile.medical_history = data.get('medical_history', patient.patient_profile.medical_history)
        patient.patient_profile.blood_group = data.get('blood_group', patient.patient_profile.blood_group)
    
    db.session.commit()
    return jsonify({"status": "success"})

@api.route('/api/doctors', methods=['GET'])
@login_required
def get_doctors():
    """ Used for patient selection of primary doctor """
    from ..models import User
    doctors = User.query.filter_by(role='doctor').all()
    return jsonify([{
        "id": d.id,
        "full_name": d.full_name,
        "specialization": d.doctor_profile.specialization if d.doctor_profile else "General"
    } for d in doctors])
@api.route('/api/patients/<int:patient_id>/email-report', methods=['POST'])
@login_required
def email_patient_report(patient_id):
    """ Feature 11: Health Report PDF Generator (Doctor triggered email & SMS with report summary) """
    try:
        if current_user.role != 'doctor':
            return jsonify({"status": "error", "message": "Unauthorized"}), 403

        from ..models import User, VitalSign, Alert
        from ..services.report_generator import generate_patient_report
        from ..services.notifier import send_email_alert, trigger_sms_alert
        import os

        patient = User.query.get_or_404(patient_id)
        vitals = VitalSign.query.filter_by(patient_id=patient.id).order_by(VitalSign.timestamp.desc()).limit(50).all()
        alerts = Alert.query.filter_by(patient_id=patient.id).order_by(Alert.created_at.desc()).limit(20).all()
        
        reports_dir = os.path.join(os.getcwd(), 'backend', 'static', 'reports')
        filepath = generate_patient_report(patient, vitals, alerts, reports_dir)
        
        subject = f"Clinical Health Report: {patient.full_name}"
        body = f"Hello {patient.full_name},\n\nPlease find your latest health monitoring report attached.\n\nRegards,\nSmart Health Monitoring System"
        
        # Send email
        email_sent = send_email_alert(patient.email, subject, body, attachment_path=filepath)
        
        # Build SMS message with report summary
        sms_message = f"HEALTH REPORT: {patient.full_name}\n"
        
        if vitals:
            latest = vitals[0]
            sms_message += f"LATEST VITALS:\n"
            if latest.heart_rate:
                sms_message += f"HR: {latest.heart_rate} bpm\n"
            if latest.temperature:
                sms_message += f"Temp: {latest.temperature}F\n"
            if latest.blood_pressure_sys:
                sms_message += f"BP: {latest.blood_pressure_sys}/{latest.blood_pressure_dia} mmHg\n"
            if latest.oxygen_level:
                sms_message += f"O2: {latest.oxygen_level}%\n"
            if latest.glucose_level:
                sms_message += f"Glucose: {latest.glucose_level} mg/dL\n"
        
        if alerts:
            alert_count = len(alerts)
            critical_alerts = len([a for a in alerts if a.severity.lower() == 'critical'])
            sms_message += f"ALERTS: {critical_alerts} Critical, {alert_count - critical_alerts} Other\n"
        else:
            sms_message += "STATUS: All vitals normal\n"
        
        sms_message += "Check email for full PDF report. - HAPPY HEAL"
        
        # Send SMS
        sms_sent = False
        if patient.phone:
            sms_sent = trigger_sms_alert(patient.phone, sms_message)
        
        if email_sent:
            # Log to database (Feature 11 requirement)
            from ..models import HealthReport
            report = HealthReport(
                patient_id=patient.id,
                report_type="Consolidated Email Report",
                file_path="static/reports/" + os.path.basename(filepath)
            )
            db.session.add(report)
            db.session.commit()
            
            notification_msg = f"Report emailed to {patient.email}"
            if sms_sent:
                notification_msg += f" and SMS with report summary sent to {patient.phone}"
            elif patient.phone:
                notification_msg += " (SMS send failed, email succeeded)"
            
            return jsonify({
                "status": "success", 
                "message": notification_msg,
                "email_sent": email_sent,
                "sms_sent": sms_sent,
                "sms_preview": sms_message if patient.phone else None
            })
        else:
            return jsonify({"status": "error", "message": "Failed to send email."}), 500
    
    except Exception as e:
        print(f"Email Report Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"status": "error", "message": f"Server error: {str(e)}"}), 500
@api.route('/api/debug/generate-samples', methods=['POST'])
@login_required
def generate_samples():
    from ..models import User, PatientProfile, HealthScore, VitalReading, db
    import random
    from datetime import datetime, timedelta

    # Create 3-5 sample patients
    names = ["John Smith", "Emma Wilson", "Robert Brown", "Sarah Davis", "Michael Miller"]
    created_count = 0
    
    for i, name in enumerate(names):
        username = f"sample_patient_{i+1}"
        if User.query.filter_by(username=username).first():
            continue
            
        p = User(
            username=username,
            full_name=name,
            role='patient',
            email=f"{username}@example.com"
        )
        p.set_password("password123")
        db.session.add(p)
        db.session.flush()

        profile = PatientProfile(
            patient_id=p.id,
            dob=datetime.now() - timedelta(days=365 * random.randint(25, 65)),
            blood_group=random.choice(['A+', 'B+', 'O+', 'AB+']),
            medical_history="Sample history for testing purposes.",
            primary_doctor_id=current_user.id
        )
        db.session.add(profile)

        # Add some vital readings
        for d in range(10):
            v = VitalSign(
                patient_id=p.id,
                heart_rate=random.randint(65, 85),
                blood_pressure_sys=random.randint(110, 130),
                blood_pressure_dia=random.randint(70, 90),
                temperature=98.6,
                oxygen_level=98,
                glucose_level=95,
                timestamp=datetime.now() - timedelta(days=d)
            )
            db.session.add(v)
            
        score = HealthScore(patient_id=p.id, current_score=85, risk_level='low')
        db.session.add(score)
        created_count += 1

    db.session.commit()
    return jsonify({"message": f"Successfully created {created_count} sample patients assigned to you.", "status": "success"})


# ==================== DOCTOR EMAIL SENDING ====================

@api.route('/api/send-doctor-email', methods=['POST'])
@login_required
def send_doctor_email():
    """Doctor sends email - sends to patient AND admin with details"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Only doctors can send emails"}), 403
    
    data = request.json or {}
    patient_email = data.get('patient_email')
    subject = data.get('subject')
    message = data.get('message')
    patient_id = data.get('patient_id')
    attach_report = data.get('attach_report', False)
    
    if not patient_email or not subject or not message:
        return jsonify({"status": "error", "message": "Missing required fields"}), 400
    
    try:
        from ..services.notifier import send_email_alert
        from ..models import User, VitalSign, Alert
        from ..services.report_generator import generate_patient_report
        import traceback
        import os
        import tempfile
        
        # Get patient details
        patient = User.query.filter_by(email=patient_email).first()
        if not patient:
            patient = User.query.get(patient_id) if patient_id else None
            if not patient:
                return jsonify({"status": "error", "message": "Patient not found"}), 404
        
        # Generate PDF report if requested
        attachment_path = None
        if attach_report:
            try:
                # Get patient vitals and alerts
                vitals = VitalSign.query.filter_by(patient_id=patient.id).order_by(VitalSign.timestamp.desc()).all()
                alerts = Alert.query.filter_by(patient_id=patient.id).order_by(Alert.created_at.desc()).all()
                
                # Create temp directory for reports if it doesn't exist
                reports_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'reports')
                os.makedirs(reports_dir, exist_ok=True)
                
                # Generate PDF report - function returns the full filepath
                attachment_path = generate_patient_report(patient, vitals, alerts, reports_dir)
                print(f"✓ PDF report generated: {attachment_path}")
            except Exception as e:
                print(f"Warning: Could not generate PDF report: {e}")
                traceback.print_exc()
                attachment_path = None
        
        # Email 1: Send to PATIENT with professional formatting
        doctor_specialization = current_user.doctor_profile.specialization if current_user.doctor_profile else 'Healthcare Provider'
        
        patient_email_subject = f"Medical Consultation - {subject}"
        patient_email_body = f"""
Hello {patient.full_name},

Dr. {current_user.full_name} ({doctor_specialization}) has sent you the following medical consultation:

SUBJECT: {subject}

{message}

---

If you have any questions, please contact your healthcare provider.
Contact: {current_user.phone or 'N/A'}

Sent through: Healthcare System Portal
Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}
"""
        
        try:
            patient_email_sent = send_email_alert(
                patient.email,
                patient_email_subject,
                patient_email_body,
                patient_name=patient.full_name,
                attachment_path=attachment_path
            )
            print(f"Patient email sent: {patient_email_sent}")
        except Exception as e:
            print(f"Error sending patient email: {e}")
            traceback.print_exc()
            patient_email_sent = False
        
        # Email 2: Send to ADMIN (harisharumugam35@gmail.com) with full details
        admin_email = "harisharumugam35@gmail.com"
        admin_email_subject = f"[{current_user.full_name}] Patient Consultation - {subject}"
        admin_email_body = f"""
PATIENT CONSULTATION EMAIL - ADMIN COPY
{'='*70}

DOCTOR INFORMATION:
{'='*70}
Name: Dr. {current_user.full_name}
Specialization: {doctor_specialization}
Phone: {current_user.phone or 'N/A'}
Email: {current_user.email}

PATIENT INFORMATION:
{'='*70}
Name: {patient.full_name}
Email: {patient.email}
Patient ID: {patient_id or 'Unknown'}
Phone: {patient.phone or 'N/A'}

CONSULTATION DETAILS:
{'='*70}
Subject: {subject}
Attachment Requested: {'Yes' if attach_report else 'No'}
PDF Report Attached: {'Yes' if attachment_path and os.path.exists(attachment_path) else 'No'}
Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}

MESSAGE:
{'-'*70}
{message}
{'-'*70}

SYSTEM INFORMATION:
Sent via: Healthcare System Portal
Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}
Patient Email Status: {'SENT' if patient_email_sent else 'FAILED'}
Report File: {os.path.basename(attachment_path) if attachment_path else 'None'}

{'='*70}
"""
        
        try:
            admin_email_sent = send_email_alert(
                admin_email,
                admin_email_subject,
                admin_email_body,
                patient_name=f"Admin - {patient.full_name}",
                attachment_path=attachment_path
            )
            print(f"Admin email sent: {admin_email_sent}")
        except Exception as e:
            print(f"Error sending admin email: {e}")
            traceback.print_exc()
            admin_email_sent = False
        
        # Return status
        if patient_email_sent or admin_email_sent:
            status_msg = f"Email sent "
            if patient_email_sent and admin_email_sent:
                status_msg += "to patient and admin successfully"
            elif patient_email_sent:
                status_msg += "to patient successfully"
            else:
                status_msg += "to admin successfully"
            
            return jsonify({
                "status": "success",
                "message": status_msg,
                "patient_email_sent": patient_email_sent,
                "admin_email_sent": admin_email_sent
            }), 200
        else:
            return jsonify({
                "status": "error",
                "message": "Failed to send email to both patient and admin"
            }), 500
            
    except Exception as e:
        print(f"Email send error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "status": "error",
            "message": f"Error sending email: {str(e)}"
        }), 500


# ==================== 7-DAY ANALYSIS ENDPOINT ====================

@api.route('/api/analyze/7day-report', methods=['GET'])
@login_required
def analyze_7day_report():
    """Analyze 7-day patient data and generate comprehensive report"""
    try:
        from datetime import timedelta
        from ..models import VitalSign, Alert
        
        print(f"\n[7DAY ANALYSIS] Starting analysis for user {current_user.id}")
        
        #Get patient ID (can be self or specified by doctor)
        patient_id = request.args.get('patient_id', current_user.id)
        print(f"[7DAY ANALYSIS] Patient ID: {patient_id}")
        
        # Get vitals from last 7 days
        seven_days_ago = datetime.utcnow() - timedelta(days=7)
        print(f"[7DAY ANALYSIS] Querying vitals from: {seven_days_ago}")
        
        vitals = VitalSign.query.filter(
            VitalSign.patient_id == patient_id,
            VitalSign.timestamp >= seven_days_ago
        ).order_by(VitalSign.timestamp.desc()).all()
        
        print(f"[7DAY ANALYSIS] Found {len(vitals)} vitals records")
        
        if not vitals:
            print("[7DAY ANALYSIS] No vitals found, returning error")
            return jsonify({
                "status": "error",
                "message": "No vital signs data available for the last 7 days"
            }), 400
        
        # Calculate averages with safe division and ensure they're floats
        def safe_avg(values):
            filtered = [float(v) for v in values if v is not None]
            return float(sum(filtered) / len(filtered)) if filtered else 0.0
        
        avg_heart_rate = float(safe_avg([v.heart_rate for v in vitals]))
        avg_bp_sys = float(safe_avg([v.blood_pressure_sys for v in vitals]))
        avg_bp_dia = float(safe_avg([v.blood_pressure_dia for v in vitals]))
        avg_temp = float(safe_avg([v.temperature for v in vitals]))
        avg_oxygen = float(safe_avg([v.oxygen_level for v in vitals]))
        avg_glucose = float(safe_avg([v.glucose_level for v in vitals]))
        
        # Get alerts from last 7 days
        alerts = Alert.query.filter(
            Alert.patient_id == patient_id,
            Alert.created_at >= seven_days_ago
        ).all()
        alert_count = len(alerts) if alerts else 0
        critical_alerts = len([a for a in alerts if a.severity and a.severity.lower() == 'critical']) if alerts else 0
        
        # Determine trends
        stable_days = 0
        abnormal_days = 0
        for vital in vitals:
            is_stable = (
                (60 <= vital.heart_rate <= 100) if vital.heart_rate else True
            ) and (
                (90 <= vital.blood_pressure_sys <= 140) if vital.blood_pressure_sys else True
            ) and (
                (60 <= vital.blood_pressure_dia <= 90) if vital.blood_pressure_dia else True
            ) and (
                (97 <= vital.temperature <= 99) if vital.temperature else True
            ) and (
                (95 <= vital.oxygen_level <= 100) if vital.oxygen_level else True
            ) and (
                (70 <= vital.glucose_level <= 110) if vital.glucose_level else True
            )
            if is_stable:
                stable_days += 1
            else:
                abnormal_days += 1
        
        # Determine overall trend
        if abnormal_days > stable_days:
            overall_trend = "⬇️ Declining - Monitor closely"
        elif stable_days > abnormal_days:
            overall_trend = "⬆️ Improving - Continue current routine"
        else:
            overall_trend = "➡️ Stable - Maintain vigilance"
        
        # Determine risk level
        risk_level = "low"
        if critical_alerts > 0 or abnormal_days > 5:
            risk_level = "critical"
        elif abnormal_days > 3 or avg_heart_rate > 100 or avg_oxygen < 94:
            risk_level = "at-risk"
        elif abnormal_days > 1:
            risk_level = "medium"
        
        # Generate recommendations
        recommendations = []
        if avg_heart_rate > 90:
            recommendations.append("Heart rate is elevated. Consider stress reduction techniques and consult your doctor if it remains high.")
        if avg_bp_sys > 140:
            recommendations.append("Blood pressure is elevated. Reduce sodium intake and increase physical activity. Consult your doctor.")
        if avg_oxygen < 95:
            recommendations.append("Oxygen levels are low. Ensure adequate ventilation and rest. Consider consulting a respiratory specialist.")
        if avg_glucose > 125:
            recommendations.append("Glucose levels are high. Monitor carbohydrate intake and consult your physician.")
        if alert_count > 5:
            recommendations.append("Multiple health alerts detected. Schedule an appointment with your healthcare provider immediately.")
        if not recommendations:
            recommendations.append("Continue your current health management routine. Your vitals are stable.")
        
        # Generate positive indicators
        positive_indicators = []
        if avg_heart_rate >= 60 and avg_heart_rate <= 80:
            positive_indicators.append("Heart rate is within normal, healthy range")
        if avg_oxygen >= 95:
            positive_indicators.append("Oxygen saturation is excellent")
        if avg_temp >= 97 and avg_temp <= 99:
            positive_indicators.append("Body temperature is stable and normal")
        if stable_days >= 5:
            positive_indicators.append("Most readings are within normal ranges")
        if critical_alerts == 0:
            positive_indicators.append("No critical health alerts in the last 7 days")
        if not positive_indicators:
            positive_indicators.append("Keep monitoring your vital signs regularly")
        
        # Compile summary
        summary = f"7-Day Health Analysis: {stable_days}/7 days with stable readings. "
        if alert_count > 0:
            summary += f"{alert_count} health alerts detected ({critical_alerts} critical). "
        summary += f"Overall trend: {overall_trend}. "
        summary += f"Risk level: {risk_level.upper()}."
        
        # Prepare daily vitals history
        vitals_history = []
        for vital in vitals:
            vitals_history.append({
                "date": vital.timestamp.strftime("%m/%d/%Y") if vital.timestamp else "N/A",
                "time": vital.timestamp.strftime("%I:%M %p") if vital.timestamp else "N/A",
                "heart_rate": float(vital.heart_rate) if vital.heart_rate else None,
                "blood_pressure": f"{int(vital.blood_pressure_sys)}/{int(vital.blood_pressure_dia)}" if (vital.blood_pressure_sys and vital.blood_pressure_dia) else "N/A",
                "temperature": float(vital.temperature) if vital.temperature else None,
                "oxygen": float(vital.oxygen_level) if vital.oxygen_level else None,
                "glucose": float(vital.glucose_level) if vital.glucose_level else None
            })
        
        response_data = {
            "status": "success",
            "summary": summary,
            "vitals_history": vitals_history,
            "avg_vitals": {
                "heart_rate": float(round(avg_heart_rate, 1)),
                "blood_pressure": f"{int(round(avg_bp_sys))}/{int(round(avg_bp_dia))} mmHg",
                "temperature": float(round(avg_temp, 1)),
                "oxygen": float(round(avg_oxygen, 1)),
                "glucose": float(round(avg_glucose, 1))
            },
            "trends": {
                "overall_trend": overall_trend,
                "risk_level": risk_level,
                "stable_days": int(stable_days),
                "abnormal_days": int(abnormal_days),
                "alert_count": int(alert_count)
            },
            "recommendations": recommendations,
            "positive_indicators": positive_indicators,
            "data_points": int(len(vitals)),
            "time_period": "Last 7 days"
        }
        
        print(f"[7DAY ANALYSIS] Successfully compiled analysis with {len(vitals_history)} daily records")
        return jsonify(response_data), 200
        
    except Exception as e:
        import traceback
        error_msg = f"7-Day Analysis Error: {str(e)}"
        print(f"\n[7DAY ANALYSIS] {error_msg}")
        print(f"[7DAY ANALYSIS] Traceback:\n{traceback.format_exc()}\n")
        return jsonify({
            "status": "error",
            "message": f"Failed to generate 7-day report: {str(e)}"
        }), 500
