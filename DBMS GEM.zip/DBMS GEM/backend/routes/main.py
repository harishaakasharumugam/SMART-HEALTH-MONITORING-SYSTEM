from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from ..models import User, PatientProfile, VitalSign, Alert, HealthScore, Recommendation, DoctorProfile, CaregiverAssignment, HealthReport
from ..models_extended import Appointment, Prescription
from ..app import db

main = Blueprint('main', __name__)

@main.route('/')
def index():
    # Get all registered doctors
    doctors = db.session.query(User, DoctorProfile).join(
        DoctorProfile, User.id == DoctorProfile.doctor_id
    ).filter(User.role == 'doctor').all()
    
    return render_template('landing_new.html', doctors=doctors)

@main.route('/doctor/dashboard')
@login_required
def doctor_dashboard():
    if current_user.role != 'doctor':
        return redirect(url_for('main.dashboard'))
    
    from datetime import datetime, date
    import datetime as dt
    from ..models_extended import DoctorPatientAssignment
    
    # Get all assigned patients for this doctor from DoctorPatientAssignment
    assignments = DoctorPatientAssignment.query.filter(
        DoctorPatientAssignment.doctor_id == current_user.id,
        DoctorPatientAssignment.status == 'active'
    ).all()
    
    doctor_patient_ids = [a.patient_id for a in assignments]
    doctor_patients = User.query.filter(
        User.id.in_(doctor_patient_ids),
        User.role == 'patient'
    ).all() if doctor_patient_ids else []
    
    total_patients = len(doctor_patients)
    
    # Get critical alerts for assigned patients
    critical_alerts = Alert.query.filter(
        Alert.patient_id.in_(doctor_patient_ids),
        Alert.severity == 'critical',
        Alert.status == 'active'
    ).count() if doctor_patient_ids else 0
    
    # Count reports for assigned patients
    pending_reports = HealthReport.query.filter(
        HealthReport.patient_id.in_(doctor_patient_ids)
    ).count() if doctor_patient_ids else 0
    
    # Get today's appointments for assigned patients
    today = date.today()
    today_appointments = Appointment.query.filter(
        Appointment.patient_id.in_(doctor_patient_ids),
        Appointment.appointment_date >= today,
        Appointment.appointment_date < today + dt.timedelta(days=1)
    ).count() if doctor_patient_ids else 0
    
    # Get critical vitals count
    critical_vitals = VitalSign.query.filter(
        VitalSign.patient_id.in_(doctor_patient_ids)
    ).all() if doctor_patient_ids else []
    critical_vitals_count = sum(1 for v in critical_vitals if hasattr(v, 'is_critical') and v.is_critical)
    
    # Get upcoming appointments for assigned patients
    doctor_appointments = Appointment.query.filter(
        Appointment.patient_id.in_(doctor_patient_ids),
        Appointment.appointment_date >= today
    ).order_by(Appointment.appointment_date.asc()).limit(10).all() if doctor_patient_ids else []
    
    return render_template('doctor_dashboard_pro.html', 
                           total_patients=total_patients,
                           critical_alerts=critical_alerts,
                           pending_reports=pending_reports,
                           today_appointments=today_appointments,
                           critical_vitals_count=critical_vitals_count,
                           patients=doctor_patients,
                           doctor_appointments=doctor_appointments,
                           datetime=dt.datetime,
                           now=date.today())

@main.route('/caregiver/dashboard')
@login_required
def caregiver_dashboard():
    if current_user.role != 'caregiver':
        return redirect(url_for('main.dashboard'))
    # Get linked patient and appointments
    assignment = CaregiverAssignment.query.filter_by(caregiver_id=current_user.id).first()
    patient = User.query.get(assignment.patient_id) if assignment else None
    appointments = Appointment.query.filter_by(patient_id=patient.id).order_by(Appointment.appointment_date.desc()).limit(5).all() if patient else []
    return render_template('caregiver_dashboard_pro.html', patient=patient, appointments=appointments)

@main.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'doctor':
        return redirect(url_for('main.doctor_dashboard'))
    elif current_user.role == 'caregiver':
        return redirect(url_for('main.caregiver_dashboard'))
    
    from ..models import DigitalTwin
    
    # Get vital signs data
    last_vital = VitalSign.query.filter_by(patient_id=current_user.id).order_by(VitalSign.timestamp.desc()).first()
    vital_signs = VitalSign.query.filter_by(patient_id=current_user.id).order_by(VitalSign.timestamp.desc()).limit(10).all()
    
    # Get health score
    health_score = HealthScore.query.filter_by(patient_id=current_user.id).first()
    
    # Get other dashboard data
    recommendations = Recommendation.query.filter_by(patient_id=current_user.id).order_by(Recommendation.created_at.desc()).limit(3).all()
    appointments = Appointment.query.filter_by(patient_id=current_user.id).order_by(Appointment.appointment_date.desc()).limit(5).all()
    prescriptions = Prescription.query.filter_by(patient_id=current_user.id).order_by(Prescription.created_at.desc()).limit(5).all()
    health_reports = HealthReport.query.filter_by(patient_id=current_user.id).order_by(HealthReport.generated_at.desc()).limit(10).all()
    
    # Get assigned doctors from DoctorPatientAssignment
    from ..models_extended import DoctorPatientAssignment
    assigned_doctors = []
    doctor_assignments = DoctorPatientAssignment.query.filter(
        DoctorPatientAssignment.patient_id == current_user.id,
        DoctorPatientAssignment.status == 'active'
    ).all()
    
    for assignment in doctor_assignments:
        doctor = User.query.filter_by(id=assignment.doctor_id, role='doctor').first()
        if doctor:
            assigned_doctors.append(doctor)
    
    # Get digital twin data
    digital_twin = DigitalTwin.query.filter_by(patient_id=current_user.id).first()
    
    return render_template('patient_dashboard_pro.html',
                           last_vital=last_vital,
                           vital_signs=vital_signs,
                           health_score=health_score,
                           recommendations=recommendations,
                           appointments=appointments,
                           prescriptions=prescriptions,
                           health_reports=health_reports,
                           assigned_doctors=assigned_doctors,
                           digital_twin=digital_twin)

@main.route('/download-record/<int:record_id>')
@login_required
def download_record(record_id):
    """Download a medical record as comprehensive PDF (same as email version)"""
    from flask import send_file
    import os
    
    # Get the health report
    health_report = HealthReport.query.filter_by(id=record_id, patient_id=current_user.id).first()
    if not health_report:
        return {'error': 'Report not found'}, 404
    
    # Generate comprehensive report from patient data
    from ..services.report_generator import generate_patient_report
    
    patient = User.query.get(health_report.patient_id)
    if not patient:
        return {'error': 'Patient not found'}, 404
    
    # Get patient vitals and alerts
    vitals = VitalSign.query.filter_by(patient_id=patient.id).order_by(VitalSign.timestamp.desc()).limit(50).all()
    alerts = Alert.query.filter_by(patient_id=patient.id).order_by(Alert.created_at.desc()).limit(20).all()
    
    # Generate the comprehensive PDF (same format as email)
    reports_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'reports')
    filepath = generate_patient_report(patient, vitals, alerts, reports_dir)
    
    # Get just the filename for the download
    filename = os.path.basename(filepath)
    
    return send_file(filepath, as_attachment=True, download_name=filename)


@main.route('/download-health-report/<int:report_id>')
@login_required
def download_health_report(report_id):
    """Download a comprehensive health report PDF"""
    from flask import send_file
    import os
    
    # Get the health report
    health_report = HealthReport.query.get(report_id)
    if not health_report:
        return {'error': 'Report not found'}, 404
    
    # Check if user has permission (doctor who created it or patient who owns it)
    if current_user.role == 'patient' and health_report.patient_id != current_user.id:
        return {'error': 'Access denied'}, 403
    if current_user.role == 'doctor' and health_report.doctor_id != current_user.id:
        return {'error': 'Access denied'}, 403
    
    # If file_path exists and file exists, download the actual file
    if health_report.file_path:
        file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), health_report.file_path)
        if os.path.exists(file_path):
            filename = os.path.basename(file_path)
            return send_file(file_path, as_attachment=True, download_name=filename)
    
    # Generate comprehensive report from patient data
    from ..services.report_generator import generate_patient_report
    from datetime import datetime
    
    patient = User.query.get(health_report.patient_id)
    if not patient:
        return {'error': 'Patient not found'}, 404
    
    # Get patient vitals and alerts
    vitals = VitalSign.query.filter_by(patient_id=patient.id).order_by(VitalSign.timestamp.desc()).limit(50).all()
    alerts = Alert.query.filter_by(patient_id=patient.id).order_by(Alert.created_at.desc()).limit(20).all()
    
    # Generate the comprehensive PDF
    reports_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'reports')
    filepath = generate_patient_report(patient, vitals, alerts, reports_dir)
    
    # Get just the filename for the download
    filename = os.path.basename(filepath)
    
    return send_file(filepath, as_attachment=True, download_name=filename)
