"""
API Routes for Advanced Healthcare Features
Includes: Prescription management, Appointment scheduling, Consultation notes, Treatment plans
"""

from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from sqlalchemy import or_
from ..models import User, db, HealthReport
from ..models_extended import (
    Prescription, PrescriptionMedicine, Medicine, MedicineInteraction, 
    Appointment, ConsultationNote, TreatmentPlan, TreatmentPlanPhase,
    MedicalDocument, LabOrder, LabResult, EmailLog, DoctorPatientAssignment
)
from ..services.email_service import get_email_service
from ..services.pdf_professional import generate_professional_report
from ..services.audit_service import log_audit
from datetime import datetime, timedelta
import os
from werkzeug.utils import secure_filename

advanced_api = Blueprint('advanced_api', __name__, url_prefix='/api')


# ==================== PRESCRIPTION MANAGEMENT ====================

@advanced_api.route('/create-prescription', methods=['POST'])
@login_required
@log_audit("Created Prescription")
def create_simple_prescription():
    """Create a new prescription (Simple version for Doctor Dashboard)"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Only doctors can create prescriptions"}), 403
    
    data = request.json or {}
    patient_id = data.get('patient_id')
    prescription_type = data.get('prescription_type')
    medicine_name = data.get('medicine_name')
    dosage = data.get('dosage')
    frequency = data.get('frequency')
    duration = data.get('duration')
    notes = data.get('notes')
    start_date = data.get('start_date')
    
    if not all([patient_id, prescription_type, medicine_name, dosage, frequency, duration, notes, start_date]):
        return jsonify({"status": "error", "message": "All fields are required"}), 400
    
    try:
        # Verify patient exists and is assigned to this doctor
        patient = User.query.get(int(patient_id))
        if not patient or patient.role != 'patient':
            return jsonify({"status": "error", "message": "Patient not found"}), 404
        
        # Check doctor-patient assignment
        from ..models_extended import DoctorPatientAssignment
        assignment = DoctorPatientAssignment.query.filter_by(
            doctor_id=current_user.id,
            patient_id=int(patient_id)
        ).first()
        if not assignment:
            return jsonify({"status": "error", "message": "Patient not assigned to you"}), 403
        
        # Parse start date
        valid_from = datetime.fromisoformat(start_date)
        valid_until = valid_from + timedelta(days=int(duration))
        
        # Create prescription with all details
        prescription = Prescription(
            patient_id=int(patient_id),
            doctor_id=current_user.id,
            diagnosis=prescription_type,
            medicine_name=medicine_name,
            dosage=dosage,
            frequency=frequency,
            duration=int(duration),
            notes=notes,
            valid_from=valid_from,
            valid_until=valid_until,
            status='active'
        )
        db.session.add(prescription)
        db.session.commit()
        
        # Send notification to patient
        try:
            if patient and patient.email:
                from ..services.email_service import send_email
                email_body = f"""
Dear {patient.full_name},

You have received a new prescription from Dr. {current_user.full_name}:

Medicine: {medicine_name}
Dosage: {dosage}
Frequency: {frequency}
Type: {prescription_type}
Valid From: {valid_from.strftime('%Y-%m-%d')}
Duration: {duration} days
Notes: {notes}

Please contact your doctor if you have any questions.

Best regards,
GemCare Healthcare System
                """
                send_email(
                    to_email=patient.email,
                    subject=f"New Prescription: {medicine_name}",
                    body=email_body
                )
        except Exception as e:
            print(f"⚠️ Could not send prescription notification: {e}")
        
        return jsonify({
            "status": "success",
            "message": "Prescription created successfully",
            "prescription_id": prescription.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": f"Error creating prescription: {str(e)}"}), 500


@advanced_api.route('/prescriptions', methods=['POST'])
@login_required
@log_audit("Created Prescription")
def create_prescription():
    """Create a new prescription (Doctor only)"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Only doctors can create prescriptions"}), 403
    
    data = request.json or {}
    patient_id = data.get('patient_id')
    medicines = data.get('medicines', [])  # List of {medicine_id, dosage, frequency, duration, instructions}
    
    if not patient_id or not medicines:
        return jsonify({"status": "error", "message": "Patient ID and medicines required"}), 400
    
    try:
        # Create prescription
        prescription = Prescription(
            patient_id=patient_id,
            doctor_id=current_user.id,
            diagnosis=data.get('diagnosis', ''),
            notes=data.get('notes', ''),
            valid_from=datetime.utcnow(),
            valid_until=datetime.utcnow() + timedelta(days=data.get('valid_days', 30))
        )
        db.session.add(prescription)
        db.session.flush()  # Flush to get prescription ID
        
        # Add medicines to prescription
        for med in medicines:
            # Check drug interactions
            existing_meds = PrescriptionMedicine.query.filter_by(prescription_id=prescription.id).all()
            interactions_found = []
            
            for existing_med in existing_meds:
                interaction = MedicineInteraction.query.filter(
                    ((MedicineInteraction.medicine_1_id == med.get('medicine_id')) & 
                     (MedicineInteraction.medicine_2_id == existing_med.medicine_id)) |
                    ((MedicineInteraction.medicine_1_id == existing_med.medicine_id) & 
                     (MedicineInteraction.medicine_2_id == med.get('medicine_id')))
                ).first()
                
                if interaction and interaction.severity in ['severe', 'contraindicated']:
                    interactions_found.append(f"{interaction.description}")
            
            # Create prescription medicine
            prescription_medicine = PrescriptionMedicine(
                prescription_id=prescription.id,
                medicine_id=med.get('medicine_id'),
                dosage=med.get('dosage', ''),
                frequency=med.get('frequency', ''),
                route=med.get('route', 'oral'),
                duration_days=med.get('duration_days', 7),
                quantity=med.get('quantity', 30),
                special_instructions=med.get('instructions', ''),
                interactions_checked=True,
                interactions_found='; '.join(interactions_found) if interactions_found else None
            )
            db.session.add(prescription_medicine)
        
        db.session.commit()
        
        # Send notification email
        patient = User.query.get(patient_id)
        if patient and patient.email:
            email_service = get_email_service(db)
            medicines_list = []
            for med in medicines:
                medicine = Medicine.query.get(med.get('medicine_id'))
                medicines_list.append({
                    'name': medicine.name if medicine else 'N/A',
                    'dosage': med.get('dosage', ''),
                    'frequency': med.get('frequency', ''),
                    'duration': f"{med.get('duration_days', 7)} days"
                })
            
            email_service.send_prescription_notification(
                db, patient.email, patient.full_name,
                medicines_list,
                special_instructions=data.get('special_instructions', ''),
                doctors_advice=data.get('doctors_advice', '')
            )
        
        return jsonify({
            "status": "success",
            "message": "Prescription created successfully",
            "prescription_id": prescription.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": str(e)}), 400


@advanced_api.route('/prescriptions/<int:prescription_id>', methods=['GET'])
@login_required
def get_prescription(prescription_id):
    """Get prescription details"""
    prescription = Prescription.query.get(prescription_id)
    
    if not prescription:
        return jsonify({"status": "error", "message": "Prescription not found"}), 404
    
    # Check access permission
    if (current_user.id != prescription.patient_id and 
        current_user.id != prescription.doctor_id and 
        current_user.role != 'admin'):
        return jsonify({"status": "error", "message": "Unauthorized"}), 403
    
    medicines = []
    for pm in prescription.medicines:
        medicines.append({
            'medicine_id': pm.medicine_id,
            'medicine_name': pm.medicine.name if pm.medicine else 'N/A',
            'dosage': pm.dosage,
            'frequency': pm.frequency,
            'route': pm.route,
            'duration_days': pm.duration_days,
            'quantity': pm.quantity,
            'instructions': pm.special_instructions,
            'interactions': pm.interactions_found
        })
    
    return jsonify({
        "status": "success",
        "prescription": {
            'id': prescription.id,
            'patient_id': prescription.patient_id,
            'doctor_id': prescription.doctor_id,
            'diagnosis': prescription.diagnosis,
            'medicines': medicines,
            'status': prescription.status,
            'created_at': prescription.created_at.isoformat(),
            'valid_from': prescription.valid_from.isoformat(),
            'valid_until': prescription.valid_until.isoformat() if prescription.valid_until else None
        }
    }), 200


@advanced_api.route('/prescriptions', methods=['GET'])
@login_required
def get_prescriptions():
    """Get all prescriptions for patient or doctor"""
    if current_user.role == 'patient':
        prescriptions = Prescription.query.filter_by(patient_id=current_user.id).order_by(Prescription.created_at.desc()).all()
    elif current_user.role == 'doctor':
        prescriptions = Prescription.query.filter_by(doctor_id=current_user.id).order_by(Prescription.created_at.desc()).all()
    else:
        prescriptions = Prescription.query.all()
    
    result = []
    for p in prescriptions:
        result.append({
            'id': p.id,
            'patient': User.query.get(p.patient_id).full_name if p.patient_id else 'N/A',
            'doctor': User.query.get(p.doctor_id).full_name if p.doctor_id else 'N/A',
            'diagnosis': p.diagnosis,
            'medicine_name': p.medicine_name or 'N/A',
            'dosage': p.dosage or 'N/A',
            'frequency': p.frequency or 'N/A',
            'duration': p.duration or 0,
            'notes': p.notes or '',
            'status': p.status,
            'valid_from': p.valid_from.isoformat() if p.valid_from else None,
            'valid_until': p.valid_until.isoformat() if p.valid_until else None,
            'created_at': p.created_at.isoformat() if p.created_at else None
        })
    
    return jsonify({"status": "success", "prescriptions": result}), 200


# ==================== APPOINTMENT SCHEDULING ====================

@advanced_api.route('/appointments', methods=['POST'])
@login_required
def create_appointment():
    """Create new appointment"""
    data = request.json or {}
    doctor_id = data.get('doctor_id')
    appointment_date = datetime.fromisoformat(data.get('appointment_date', ''))
    
    if current_user.role == 'patient':
        patient_id = current_user.id
    else:
        patient_id = data.get('patient_id')
    
    if not doctor_id or not patient_id:
        return jsonify({"status": "error", "message": "Doctor and Patient required"}), 400
    
    try:
        appointment = Appointment(
            patient_id=patient_id,
            doctor_id=doctor_id,
            appointment_date=appointment_date,
            appointment_type=data.get('type', 'Consultation'),
            reason=data.get('reason', ''),
            duration_minutes=data.get('duration', 30),
            status='scheduled'
        )
        db.session.add(appointment)
        db.session.commit()
        
        # Send reminder email
        patient = User.query.get(patient_id)
        doctor = User.query.get(doctor_id)
        if patient and patient.email:
            email_service = get_email_service(db)
            email_service.send_appointment_reminder(
                db, patient.email, patient.full_name, doctor.full_name,
                appointment_date.strftime('%B %d, %Y'),
                appointment_date.strftime('%I:%M %p')
            )
        
        return jsonify({
            "status": "success",
            "message": "Appointment scheduled successfully",
            "appointment_id": appointment.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": str(e)}), 400


@advanced_api.route('/appointments/<int:appointment_id>', methods=['GET', 'PUT', 'DELETE'])
@login_required
def manage_appointment(appointment_id):
    """Get, update, or cancel appointment"""
    appointment = Appointment.query.get(appointment_id)
    
    if not appointment:
        return jsonify({"status": "error", "message": "Appointment not found"}), 404
    
    # Check access
    if (current_user.id != appointment.patient_id and 
        current_user.id != appointment.doctor_id and 
        current_user.role != 'admin'):
        return jsonify({"status": "error", "message": "Unauthorized"}), 403
    
    if request.method == 'GET':
        return jsonify({
            "status": "success",
            "appointment": {
                'id': appointment.id,
                'patient_id': appointment.patient_id,
                'doctor_id': appointment.doctor_id,
                'appointment_date': appointment.appointment_date.isoformat(),
                'type': appointment.appointment_type,
                'reason': appointment.reason,
                'status': appointment.status,
                'duration_minutes': appointment.duration_minutes,
                'notes': appointment.consultation_notes
            }
        }), 200
    
    elif request.method == 'PUT':
        data = request.json or {}
        
        if 'status' in data:
            appointment.status = data['status']
        if 'notes' in data and current_user.id == appointment.doctor_id:
            appointment.doctor_notes = data['notes']
        if 'appointment_date' in data:
            appointment.appointment_date = datetime.fromisoformat(data['appointment_date'])
        
        db.session.commit()
        return jsonify({"status": "success", "message": "Appointment updated"}), 200
    
    elif request.method == 'DELETE':
        if current_user.id not in [appointment.patient_id, appointment.doctor_id] and current_user.role != 'admin':
            return jsonify({"status": "error", "message": "Unauthorized"}), 403
        
        appointment.status = 'cancelled'
        appointment.cancelled_by = 'patient' if current_user.id == appointment.patient_id else 'doctor'
        db.session.commit()
        
        return jsonify({"status": "success", "message": "Appointment cancelled"}), 200


@advanced_api.route('/appointments/doctor/<int:doctor_id>', methods=['GET'])
@login_required
def get_doctor_appointments(doctor_id):
    """Get appointments for a doctor"""
    if current_user.role != 'doctor' and current_user.role != 'admin' and current_user.id != doctor_id:
        return jsonify({"status": "error", "message": "Unauthorized"}), 403
    
    appointments = Appointment.query.filter_by(doctor_id=doctor_id).all()
    
    result = []
    for appt in appointments:
        patient = User.query.get(appt.patient_id)
        result.append({
            'id': appt.id,
            'patient_name': patient.full_name if patient else 'N/A',
            'appointment_date': appt.appointment_date.isoformat(),
            'type': appt.appointment_type,
            'status': appt.status,
            'reason': appt.reason
        })
    
    return jsonify({"status": "success", "appointments": result}), 200


# ==================== CONSULTATION NOTES (SOAP FORMAT) ====================

@advanced_api.route('/consultation-notes', methods=['POST'])
@login_required
@log_audit("Created Consultation Note")
def create_consultation_note():
    """Create SOAP format consultation note"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Only doctors can create notes"}), 403
    
    data = request.json or {}
    patient_id = data.get('patient_id')
    
    if not patient_id:
        return jsonify({"status": "error", "message": "Patient ID required"}), 400
    
    try:
        note = ConsultationNote(
            patient_id=patient_id,
            doctor_id=current_user.id,
            appointment_id=data.get('appointment_id'),
            subjective=data.get('subjective', ''),
            objective=data.get('objective', ''),
            assessment=data.get('assessment', ''),
            plan=data.get('plan', ''),
            differential_diagnosis=data.get('differential_diagnosis', '')
        )
        db.session.add(note)
        db.session.commit()
        
        # Send notification to patient
        patient = User.query.get(patient_id)
        if patient and patient.email:
            email_service = get_email_service(db)
            email_service.send_report_notification(
                db, patient.email, patient.full_name, current_user.full_name,
                'Your Hospital',
                report_summary=data.get('assessment', 'Consultation note created'),
                key_findings=data.get('objective', ''),
                follow_up_date=data.get('follow_up_date', 'As recommended by doctor')
            )
        
        return jsonify({
            "status": "success",
            "message": "Consultation note created",
            "note_id": note.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": str(e)}), 400


@advanced_api.route('/consultation-notes/<int:note_id>', methods=['GET'])
@login_required
def get_consultation_note(note_id):
    """Get consultation note"""
    note = ConsultationNote.query.get(note_id)
    
    if not note:
        return jsonify({"status": "error", "message": "Note not found"}), 404
    
    # Check access
    if (current_user.id != note.patient_id and 
        current_user.id != note.doctor_id and 
        current_user.role != 'admin'):
        return jsonify({"status": "error", "message": "Unauthorized"}), 403
    
    return jsonify({
        "status": "success",
        "note": {
            'id': note.id,
            'patient_id': note.patient_id,
            'doctor': User.query.get(note.doctor_id).full_name,
            'subjective': note.subjective,
            'objective': note.objective,
            'assessment': note.assessment,
            'plan': note.plan,
            'differential_diagnosis': note.differential_diagnosis,
            'created_at': note.created_at.isoformat(),
            'signed': note.signed_at is not None
        }
    }), 200


# ==================== TREATMENT PLANS ====================

@advanced_api.route('/treatment-plans', methods=['POST'])
@login_required
def create_treatment_plan():
    """Create treatment plan"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Only doctors can create treatment plans"}), 403
    
    data = request.json or {}
    patient_id = data.get('patient_id')
    
    try:
        plan = TreatmentPlan(
            patient_id=patient_id,
            doctor_id=current_user.id,
            diagnosis=data.get('diagnosis', ''),
            objectives=data.get('objectives', ''),
            end_date=datetime.fromisoformat(data.get('end_date')) if data.get('end_date') else None,
            review_date=datetime.fromisoformat(data.get('review_date')) if data.get('review_date') else None,
            medical_interventions=data.get('medical_interventions', ''),
            lifestyle_modifications=data.get('lifestyle_modifications', ''),
            dietary_recommendations=data.get('dietary_recommendations', ''),
            exercise_plan=data.get('exercise_plan', ''),
            monitoring_parameters=data.get('monitoring_parameters', ''),
            monitoring_frequency=data.get('monitoring_frequency', '')
        )
        db.session.add(plan)
        db.session.commit()
        
        return jsonify({
            "status": "success",
            "message": "Treatment plan created",
            "plan_id": plan.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": str(e)}), 400


@advanced_api.route('/email-logs', methods=['GET'])
@login_required
def get_email_logs():
    """Get email notification logs"""
    if current_user.role not in ['admin', 'doctor']:
        return jsonify({"status": "error", "message": "Unauthorized"}), 403
    
    logs = EmailLog.query.filter_by(recipient_user_id=current_user.id).order_by(EmailLog.created_at.desc()).limit(50).all()
    
    result = []
    for log in logs:
        result.append({
            'id': log.id,
            'email_type': log.email_type,
            'recipient': log.recipient_email,
            'subject': log.subject,
            'status': log.status,
            'sent_at': log.sent_at.isoformat() if log.sent_at else None,
            'created_at': log.created_at.isoformat()
        })
    
    return jsonify({"status": "success", "logs": result}), 200


# ==================== MESSAGING ====================

@advanced_api.route('/send-message', methods=['POST'])
@login_required
def send_message():
    """Send a message between patient and doctor"""
    from ..models import Message
    
    data = request.json or {}
    recipient_id = data.get('recipient_id')
    message_text = data.get('message_text', '').strip()
    
    if not recipient_id or not message_text:
        return jsonify({"status": "error", "error": "Recipient and message required"}), 400
    
    # Verify recipient exists
    recipient = User.query.get(recipient_id)
    if not recipient:
        return jsonify({"status": "error", "error": "Recipient not found"}), 404
    
    try:
        message = Message(
            sender_id=current_user.id,
            receiver_id=recipient_id,
            content_encrypted=message_text,
            timestamp=datetime.utcnow()
        )
        db.session.add(message)
        db.session.commit()
        
        return jsonify({"success": True, "message_id": message.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "error": str(e)}), 500


@advanced_api.route('/send-record-email', methods=['POST'])
@login_required
def send_record_email():
    """Send a medical record via email"""
    from ..models import HealthReport
    
    data = request.json or {}
    record_id = data.get('record_id')
    message = data.get('message', '')
    
    if not record_id:
        return jsonify({"status": "error", "error": "Record ID required"}), 400
    
    # Get the health report
    health_report = HealthReport.query.filter_by(id=record_id, patient_id=current_user.id).first()
    if not health_report:
        return jsonify({"status": "error", "error": "Record not found"}), 404
    
    try:
        email_service = get_email_service()
        subject = f"Medical Record: {health_report.report_type or 'Health Report'}"
        body = f"""
        Dear {current_user.full_name},

        Your requested medical record is attached to this email.

        Record Type: {health_report.report_type or 'Health Report'}
        Date: {health_report.created_at.strftime('%Y-%m-%d') if health_report.created_at else 'N/A'}
        
        Additional Message:
        {message or 'N/A'}

        Best regards,
        GemCare Healthcare System
        """
        
        # Send email
        email_service.send_email(
            to_email=current_user.email,
            subject=subject,
            body=body
        )
        
        # Log the email
        email_log = EmailLog(
            sender_user_id=current_user.id,
            recipient_user_id=current_user.id,
            recipient_email=current_user.email,
            email_type='medical_record',
            subject=subject,
            status='sent',
            sent_at=datetime.utcnow()
        )
        db.session.add(email_log)
        db.session.commit()
        
        return jsonify({"success": True, "message": "Record sent successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "error": str(e)}), 500


# ==================== GET MESSAGES ====================

@advanced_api.route('/messages/<int:other_user_id>', methods=['GET'])
@login_required
def get_messages(other_user_id):
    """Get conversation between doctor and patient (works for both doctor->patient and patient->doctor)"""
    from ..models import Message, User as UserModel
    from ..models_extended import DoctorPatientAssignment
    
    # Get the other user
    other_user = UserModel.query.get(other_user_id)
    if not other_user:
        return jsonify({"error": "User not found"}), 404
    
    # Verify access
    if current_user.role == 'doctor':
        # Doctor can fetch messages with any assigned patient
        if other_user.role != 'patient':
            return jsonify({"error": "Doctor can only message patients"}), 403
        
        # Check if doctor is assigned to this patient via DoctorPatientAssignment
        assignment = DoctorPatientAssignment.query.filter(
            DoctorPatientAssignment.patient_id == other_user_id,
            DoctorPatientAssignment.doctor_id == current_user.id,
            DoctorPatientAssignment.status == 'active'
        ).first()
        if not assignment:
            return jsonify({"error": "Unauthorized"}), 403
    elif current_user.role == 'patient':
        # Patient can only fetch messages with their assigned doctors
        if other_user.role != 'doctor':
            return jsonify({"error": "Patient can only message doctors"}), 403
        
        assignment = DoctorPatientAssignment.query.filter(
            DoctorPatientAssignment.patient_id == current_user.id,
            DoctorPatientAssignment.doctor_id == other_user_id,
            DoctorPatientAssignment.status == 'active'
        ).first()
        if not assignment:
            return jsonify({"error": "Unauthorized"}), 403
    else:
        return jsonify({"error": "Unauthorized"}), 403
    
    # Get messages between current user and other user
    messages = Message.query.filter(
        ((Message.sender_id == current_user.id) & (Message.receiver_id == other_user_id)) |
        ((Message.sender_id == other_user_id) & (Message.receiver_id == current_user.id))
    ).order_by(Message.timestamp.asc()).all()
    
    result = []
    for msg in messages:
        result.append({
            'id': msg.id,
            'sender_id': msg.sender_id,
            'receiver_id': msg.receiver_id,
            'content': msg.content_encrypted,
            'is_read': msg.is_read,
            'timestamp': msg.timestamp.isoformat() if msg.timestamp else None
        })
    
    return jsonify({"messages": result}), 200


# ==================== APPOINTMENT BOOKING ====================

@advanced_api.route('/book-appointment', methods=['POST'])
@login_required
def book_appointment():
    """Patient books a new appointment (Patient only)"""
    if current_user.role != 'patient':
        return jsonify({"status": "error", "error": "Only patients can book appointments"}), 403
    
    data = request.json or {}
    appointment_type = data.get('appointment_type')
    appointment_date_str = data.get('appointment_date')
    appointment_time_str = data.get('appointment_time')
    reason = data.get('reason')
    notes = data.get('notes', '')
    
    if not all([appointment_type, appointment_date_str, appointment_time_str, reason]):
        return jsonify({"status": "error", "error": "Missing required fields"}), 400
    
    try:
        # Combine date and time into a datetime object
        appointment_datetime = datetime.strptime(
            f"{appointment_date_str} {appointment_time_str}",
            "%Y-%m-%d %H:%M"
        )
        
        # Get patient's primary doctor
        from ..models import PatientProfile
        patient_profile = PatientProfile.query.filter_by(patient_id=current_user.id).first()
        if not patient_profile or not patient_profile.primary_doctor_id:
            return jsonify({
                "status": "error",
                "error": "No primary doctor assigned. Please contact support."
            }), 400
        
        # Create appointment request with "Pending" status
        appointment = Appointment(
            patient_id=current_user.id,
            doctor_id=patient_profile.primary_doctor_id,
            appointment_date=appointment_datetime,
            appointment_type=appointment_type,
            status='Pending',  # Needs doctor approval
            notes=f"Patient Reason: {reason}\n{notes}"
        )
        
        db.session.add(appointment)
        db.session.commit()
        
        return jsonify({
            "status": "success",
            "success": True,
            "message": "Appointment request submitted successfully",
            "appointment_id": appointment.id
        }), 201
        
    except ValueError as e:
        return jsonify({
            "status": "error",
            "error": f"Invalid date or time format: {str(e)}"
        }), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "status": "error",
            "error": f"Failed to book appointment: {str(e)}"
        }), 500


# ==================== PATIENT SEARCH & ASSIGNMENT ====================

@advanced_api.route('/search-patients', methods=['GET', 'POST'])
@login_required
def search_patients():
    """Search for patients by ID or name (Doctor only)"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "error": "Only doctors can search patients"}), 403
    
    # Get search query
    if request.method == 'POST':
        query = request.json.get('query', '').strip()
    else:
        query = request.args.get('q', '').strip()
    
    if not query:
        return jsonify({"status": "error", "error": "Search query required"}), 400
    
    try:
        # Extract numeric part for ID search (e.g., "2b" -> 2)
        numeric_id = None
        if query:
            # Get leading digits from the query
            numeric_str = ''
            for char in query:
                if char.isdigit():
                    numeric_str += char
                else:
                    break
            if numeric_str:
                try:
                    numeric_id = int(numeric_str)
                except ValueError:
                    pass
        
        # Build search conditions
        search_conditions = [
            User.full_name.ilike(f'%{query}%'),
            User.email.ilike(f'%{query}%')
        ]
        if numeric_id:
            search_conditions.insert(0, User.id == numeric_id)
        
        # Search by patient ID, name, or email
        results = User.query.filter(
            (User.role == 'patient') &
            or_(*search_conditions)
        ).limit(20).all()
        
        # Get current assignments for this doctor
        current_assignments = db.session.query(DoctorPatientAssignment.patient_id).filter(
            DoctorPatientAssignment.doctor_id == current_user.id,
            DoctorPatientAssignment.status == 'active'
        ).all()
        
        current_patient_ids = [a[0] for a in current_assignments]
        
        patient_list = []
        for patient in results:
            is_assigned_to_me = patient.id in current_patient_ids
            
            # Check if assigned to OTHER doctors
            all_assignments = db.session.query(DoctorPatientAssignment).filter_by(
                patient_id=patient.id,
                status='active'
            ).all()
            
            assigned_doctors = []
            if all_assignments:
                for assign in all_assignments:
                    doctor = User.query.get(assign.doctor_id)
                    if doctor:
                        assigned_doctors.append({
                            'doctor_id': doctor.id,
                            'doctor_name': doctor.full_name,
                            'is_me': doctor.id == current_user.id,
                            'assigned_at': assign.assigned_at.strftime('%Y-%m-%d %H:%M') if assign.assigned_at else 'N/A'
                        })
            
            patient_list.append({
                'id': patient.id,
                'name': patient.full_name,
                'email': patient.email,
                'phone': patient.phone or 'N/A',
                'is_assigned_to_me': is_assigned_to_me,
                'assigned_doctors': assigned_doctors,
                'assignment_count': len(assigned_doctors)
            })
        
        return jsonify({
            "status": "success",
            "patients": patient_list,
            "count": len(patient_list)
        }), 200
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": f"Search failed: {str(e)}"
        }), 500


@advanced_api.route('/assign-patient', methods=['POST'])
@login_required
def assign_patient():
    """Assign a patient to the current doctor"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "error": "Only doctors can assign patients"}), 403
    
    data = request.json or {}
    patient_id = data.get('patient_id')
    is_primary = data.get('is_primary', False)
    specialization_note = data.get('specialization_note', '')
    reason = data.get('reason', '')
    
    if not patient_id:
        return jsonify({"status": "error", "error": "Patient ID required"}), 400
    
    try:
        # Verify patient exists
        patient = User.query.filter_by(id=patient_id, role='patient').first()
        if not patient:
            return jsonify({"status": "error", "error": "Patient not found"}), 404
        
        # Check if already assigned
        existing = DoctorPatientAssignment.query.filter_by(
            doctor_id=current_user.id,
            patient_id=patient_id,
            status='active'
        ).first()
        
        if existing:
            return jsonify({
                "status": "error",
                "error": "Patient already assigned to you"
            }), 409
        
        # Create assignment
        assignment = DoctorPatientAssignment(
            doctor_id=current_user.id,
            patient_id=patient_id,
            is_primary=is_primary,
            specialization_note=specialization_note,
            reason_for_assignment=reason,
            status='active'
        )
        
        db.session.add(assignment)
        db.session.commit()
        
        return jsonify({
            "status": "success",
            "message": f"Successfully assigned {patient.full_name} to your patient list",
            "assignment_id": assignment.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "status": "error",
            "error": f"Assignment failed: {str(e)}"
        }), 500


@advanced_api.route('/get-assigned-patients', methods=['GET'])
@login_required
def get_assigned_patients():
    """Get all patients assigned to the current doctor"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "error": "Only doctors can access this"}), 403
    
    try:
        assignments = DoctorPatientAssignment.query.filter_by(
            doctor_id=current_user.id,
            status='active'
        ).all()
        
        patients = []
        for assignment in assignments:
            patient = assignment.patient
            patients.append({
                'id': patient.id,
                'name': patient.full_name,
                'email': patient.email,
                'phone': patient.phone or 'N/A',
                'is_primary': assignment.is_primary,
                'specialization': assignment.specialization_note,
                'assigned_at': assignment.assigned_at.isoformat() if assignment.assigned_at else None
            })
        
        return jsonify({
            "status": "success",
            "patients": patients,
            "count": len(patients)
        }), 200
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": f"Failed to retrieve patients: {str(e)}"
        }), 500


@advanced_api.route('/get-assigned-doctors', methods=['GET'])
@login_required
def get_assigned_doctors():
    """Get all doctors assigned to the current patient"""
    if current_user.role != 'patient':
        return jsonify({"status": "error", "error": "Only patients can access this"}), 403
    
    try:
        assignments = DoctorPatientAssignment.query.filter_by(
            patient_id=current_user.id,
            status='active'
        ).all()
        
        doctors = []
        for assignment in assignments:
            doctor = assignment.doctor
            doctor_profile = doctor.doctor_profile if hasattr(doctor, 'doctor_profile') else None
            doctors.append({
                'id': doctor.id,
                'name': doctor.full_name,
                'email': doctor.email,
                'phone': doctor.phone or 'N/A',
                'is_primary': assignment.is_primary,
                'specialization': doctor_profile.specialization if doctor_profile else 'Medical Professional',
                'assigned_at': assignment.assigned_at.isoformat() if assignment.assigned_at else None
            })
        
        return jsonify({
            "status": "success",
            "doctors": doctors,
            "count": len(doctors)
        }), 200
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": f"Failed to retrieve doctors: {str(e)}"
        }), 500


# ==================== HEALTH REPORTS / MEDICAL RECORDS ====================

@advanced_api.route('/create-health-report', methods=['POST'])
@login_required
@log_audit("Created Health Report")
def create_health_report():
    """Create a new health report / medical record"""
    if current_user.role != 'doctor':
        return jsonify({"status": "error", "message": "Only doctors can create health reports"}), 403
    
    try:
        patient_id = request.form.get('patient_id')
        report_type = request.form.get('report_type')
        description = request.form.get('description')
        
        if not patient_id:
            return jsonify({"status": "error", "message": "Patient ID is required"}), 400
        if not report_type:
            return jsonify({"status": "error", "message": "Report type is required"}), 400
        if not description:
            return jsonify({"status": "error", "message": "Description is required"}), 400
        
        # Verify patient exists and is assigned to this doctor
        patient = User.query.get(int(patient_id))
        if not patient or patient.role != 'patient':
            return jsonify({"status": "error", "message": "Patient not found"}), 404
        
        # Check doctor-patient assignment
        assignment = DoctorPatientAssignment.query.filter_by(
            doctor_id=current_user.id,
            patient_id=int(patient_id)
        ).first()
        if not assignment:
            return jsonify({"status": "error", "message": "Patient not assigned to you"}), 403
        
        file_path = None
        
        # Handle file upload if present
        if 'file' in request.files:
            file = request.files['file']
            if file and file.filename:
                # Validate file type
                allowed_extensions = {'pdf', 'jpg', 'jpeg', 'png'}
                file_ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
                
                if file_ext not in allowed_extensions:
                    return jsonify({"status": "error", "message": "File type not allowed. Use PDF, JPG, or PNG"}), 400
                
                # Validate file size (10MB max)
                file.seek(0, os.SEEK_END)
                file_size = file.tell()
                file.seek(0)
                
                if file_size > 10 * 1024 * 1024:
                    return jsonify({"status": "error", "message": "File size exceeds 10MB limit"}), 400
                
                # Create reports directory if it doesn't exist
                reports_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'reports')
                os.makedirs(reports_dir, exist_ok=True)
                
                # Save file with secure name
                filename = secure_filename(f"{patient_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
                file_path = os.path.join('static/reports', filename)
                full_path = os.path.join(reports_dir, filename)
                
                file.save(full_path)
        
        # Create health report record
        health_report = HealthReport(
            patient_id=int(patient_id),
            doctor_id=current_user.id,
            report_type=report_type,
            description=description,
            file_path=file_path,
            generated_at=datetime.utcnow()
        )
        
        db.session.add(health_report)
        db.session.commit()
        
        # Send notification email to patient
        try:
            if patient and patient.email:
                from ..services.email_service import send_email
                email_body = f"""
Dear {patient.full_name},

A new medical record has been created for you by Dr. {current_user.full_name}:

Record Type: {report_type}
Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}
Description: {description}

You can view and download this record in your patient dashboard under "Medical Records".

Best regards,
GemCare Healthcare System
                """
                send_email(
                    to_email=patient.email,
                    subject=f"New Medical Record: {report_type}",
                    body=email_body
                )
        except Exception as e:
            print(f"⚠️ Could not send health report notification: {e}")
        
        return jsonify({
            "status": "success",
            "message": "Medical record created successfully",
            "report_id": health_report.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": f"Error creating health report: {str(e)}"}), 500


@advanced_api.route('/patient-health-reports/<int:patient_id>', methods=['GET'])
@login_required
def get_patient_health_reports(patient_id):
    """Get all health reports for a patient"""
    try:
        # Verify requesting user is a doctor
        if current_user.role != 'doctor':
            return jsonify({"status": "error", "message": "Only doctors can access this"}), 403
        
        # Verify patient exists
        patient = User.query.get(patient_id)
        if not patient:
            return jsonify({"status": "error", "message": "Patient not found"}), 404
        
        # Check if doctor has access to this patient
        assignment = DoctorPatientAssignment.query.filter_by(
            doctor_id=current_user.id,
            patient_id=patient_id
        ).first()
        if not assignment:
            return jsonify({"status": "error", "message": "You don't have access to this patient's records"}), 403
        
        # Get all health reports for patient
        reports = HealthReport.query.filter_by(patient_id=patient_id).order_by(
            HealthReport.generated_at.desc()
        ).all()
        
        reports_data = []
        for report in reports:
            reports_data.append({
                'id': report.id,
                'report_type': report.report_type,
                'description': report.description,
                'file_path': report.file_path,
                'generated_at': report.generated_at.isoformat() if report.generated_at else None,
                'created_at': report.created_at.isoformat() if report.created_at else None,
                'doctor_name': User.query.get(report.doctor_id).full_name if report.doctor_id else 'Unknown'
            })
        
        return jsonify({
            "status": "success",
            "reports": reports_data,
            "count": len(reports_data)
        }), 200
        
    except Exception as e:
        return jsonify({"status": "error", "message": f"Error retrieving reports: {str(e)}"}), 500

