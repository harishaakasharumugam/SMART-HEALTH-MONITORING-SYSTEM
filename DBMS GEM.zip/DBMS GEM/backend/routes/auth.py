from flask import Blueprint, render_template, redirect, url_for, request, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required
from ..models import User
from ..app import db

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            # Role-based redirection
            if user.role == 'doctor':
                return redirect(url_for('main.doctor_dashboard'))
            elif user.role == 'caregiver':
                return redirect(url_for('main.caregiver_dashboard'))
            return redirect(url_for('main.dashboard'))
        flash('Please check your login details and try again.')
    return render_template('login_new.html')

@auth.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form.get('email')
        full_name = request.form.get('full_name')
        username = request.form.get('username')
        phone = request.form.get('phone')  # Added: Capture phone number
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = request.form.get('role')
        patient_identifier = request.form.get('patient_identifier') # For caregivers
        
        # Doctor-specific fields
        specialization = request.form.get('specialization') if role == 'doctor' else None
        hospital_name = request.form.get('hospital_name') if role == 'doctor' else None
        years_experience = request.form.get('years_experience') if role == 'doctor' else None

        # Check if passwords match
        if password != confirm_password:
            flash('Passwords do not match.')
            return redirect(url_for('auth.signup'))

        # For doctors, specialization is required
        if role == 'doctor' and not specialization:
            flash('Specialization is required for doctors.')
            return redirect(url_for('auth.signup'))

        user_exists = User.query.filter((User.email == email) | (User.username == username)).first()
        if user_exists:
            flash('Email or Username already exists.')
            return redirect(url_for('auth.signup'))

        new_user = User(
            email=email,
            full_name=full_name,
            username=username,
            phone=phone,  # Added: Save phone to database
            password_hash=generate_password_hash(password, method='pbkdf2:sha256'),
            role=role
        )

        db.session.add(new_user)
        db.session.flush() # Get ID for profile creation

        if role == 'patient':
            from ..models import PatientProfile
            db.session.add(PatientProfile(patient_id=new_user.id))
        elif role == 'doctor':
            from ..models import DoctorProfile
            db.session.add(DoctorProfile(
                doctor_id=new_user.id,
                specialization=specialization,
                hospital_name=hospital_name,
                years_experience=int(years_experience) if years_experience else None
            ))
        elif role == 'caregiver':
            from ..models import CaregiverProfile, CaregiverAssignment
            db.session.add(CaregiverProfile(caregiver_id=new_user.id))
            if patient_identifier:
                patient = User.query.filter((User.username == patient_identifier) | (User.email == patient_identifier)).first()
                if patient and patient.role == 'patient':
                    db.session.add(CaregiverAssignment(caregiver_id=new_user.id, patient_id=patient.id))
        
        db.session.commit()
        login_user(new_user)
        
        if role == 'doctor':
            return redirect(url_for('main.doctor_dashboard'))
        elif role == 'caregiver':
            return redirect(url_for('main.caregiver_dashboard'))
        return redirect(url_for('main.dashboard'))

    return render_template('signup_new.html')

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))
