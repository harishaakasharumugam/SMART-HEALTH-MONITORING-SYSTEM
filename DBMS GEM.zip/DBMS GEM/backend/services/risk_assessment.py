from ..models import HealthScore, Recommendation, VitalSign, Alert, db
from datetime import datetime, timedelta

def calculate_health_score(patient_id):
    """
    Core 10: Health Risk Scoring System
    Calculates a credit-score-like system (0-100).
    """
    score = 100
    
    # Check alert frequency in last 7 days
    week_ago = datetime.utcnow() - timedelta(days=7)
    alerts_count = Alert.query.filter(
        Alert.patient_id == patient_id,
        Alert.created_at >= week_ago
    ).count()
    
    # Deduct points for alerts
    score -= (alerts_count * 5)
    
    # Check vital trends (e.g., persistent high BP)
    recent_vitals = VitalSign.query.filter_by(patient_id=patient_id).order_by(VitalSign.timestamp.desc()).limit(10).all()
    if recent_vitals:
        # Simplified trend deduction
        avg_hr = sum(v.heart_rate for v in recent_vitals) / len(recent_vitals)
        if avg_hr > 100 or avg_hr < 50:
            score -= 10
            
    score = max(0, score)
    
    # Update or Create HealthScore
    h_score = HealthScore.query.get(patient_id)
    if not h_score:
        h_score = HealthScore(patient_id=patient_id)
        db.session.add(h_score)
    
    h_score.current_score = score
    h_score.risk_level = 'high' if score < 60 else 'moderate' if score < 85 else 'low'
    h_score.last_updated = datetime.utcnow()
    
    db.session.commit()
    return h_score

def generate_recommendations(patient_id, h_score):
    """
    Core 9: Personalized Health Recommendation Engine
    """
    recommendations = []
    
    if h_score.risk_level == 'high':
        recommendations.append("URGENT: Schedule a follow-up with your cardiologist.")
        recommendations.append("Reduce sodium intake and monitor BP every 4 hours.")
    elif h_score.risk_level == 'moderate':
        recommendations.append("Consider light cardiovascular exercises for 20 mins daily.")
        recommendations.append("Ensure 7-8 hours of sleep to stabilize heart rate.")
    else:
        recommendations.append("Continue current healthy lifestyle. Good progress!")
    
    # Clear old recommendations and add new ones
    Recommendation.query.filter_by(patient_id=patient_id).delete()
    
    for rec in recommendations:
        new_rec = Recommendation(
            patient_id=patient_id,
            suggestion=rec,
            category='general'
        )
        db.session.add(new_rec)
    
    db.session.commit()
    return recommendations
