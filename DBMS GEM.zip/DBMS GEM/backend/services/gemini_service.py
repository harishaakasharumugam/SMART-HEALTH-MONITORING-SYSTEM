import google.generativeai as genai
import os
from dotenv import load_dotenv
import time
import sys
import requests

# Load .env from project root  
load_dotenv()

# Configure Gemini API
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')

print(f"\n🔧 === Gemini Service Initialization ===")
print(f"GEMINI_API_KEY present: {bool(GEMINI_API_KEY)}")
if GEMINI_API_KEY:
    print(f"API Key: {GEMINI_API_KEY[:20]}...{GEMINI_API_KEY[-5:]}")
else:
    print(f"⚠️  GEMINI_API_KEY not found in environment variables!")
print(f"Python path: {sys.path[0]}")
print(f"Current working directory: {os.getcwd()}")
print(f"=================================\n")

try:
    if not GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY is not set in environment variables")
    genai.configure(api_key=GEMINI_API_KEY)
    print(f"✓ Gemini API configured successfully")
except Exception as e:
    print(f"✗ Critical: Gemini API configuration failed: {e}")
    print(f"✗ Please ensure GEMINI_API_KEY is set in .env file")

# Use Gemini Pro model
MODEL_NAME = "gemini-pro"

# Ollama fallback configuration
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "phi"

def generate_smart_analysis(symptoms_text):
    """Generate tailored symptom analysis based on keywords"""
    symptoms_lower = symptoms_text.lower()
    
    # Symptom database with conditions and recommendations
    symptom_db = {
        'fever': {
            'conditions': ['Viral infection (flu, cold, COVID-19)', 'Bacterial infection', 'Inflammatory condition'],
            'actions': ['Check temperature regularly', 'Use fever-reducing medication if needed', 'Stay hydrated and rest']
        },
        'cough': {
            'conditions': ['Respiratory infection (cold, flu, bronchitis)', 'Allergies', 'Asthma'],
            'actions': ['Avoid irritants and smoke', 'Stay hydrated with warm fluids', 'Use cough suppressant if severe']
        },
        'headache': {
            'conditions': ['Tension headache', 'Migraine', 'Dehydration', 'Infection'],
            'actions': ['Rest in a quiet, dark room', 'Stay hydrated', 'Take over-the-counter pain reliever']
        },
        'sore throat': {
            'conditions': ['Pharyngitis (strep or viral)', 'Tonsillitis', 'Common cold'],
            'actions': ['Gargle with warm salt water', 'Use throat lozenges', 'Avoid irritating foods']
        },
        'body ache': {
            'conditions': ['Viral infection (flu)', 'Muscle strain', 'Fatigue'],
            'actions': ['Apply warm compress to affected areas', 'Rest and elevate', 'Gentle stretching']
        },
        'nausea': {
            'conditions': ['Gastroenteritis (stomach flu)', 'Food poisoning', 'Motion sickness', 'Viral infection'],
            'actions': ['Eat light, bland foods', 'Stay hydrated with small sips', 'Rest in a comfortable position']
        },
        'vomiting': {
            'conditions': ['Gastroenteritis', 'Food poisoning', 'Migraine', 'Severe dehydration'],
            'actions': ['Rest and avoid solid foods temporarily', 'Sip clear fluids gradually', 'Seek care if persistent']
        },
        'diarrhea': {
            'conditions': ['Gastroenteritis (stomach bug)', 'Food poisoning', 'Dietary changes', 'Infection'],
            'actions': ['Stay hydrated with electrolyte solutions', 'Eat bland foods when ready', 'Avoid dairy and fatty foods']
        },
        'fatigue': {
            'conditions': ['Viral illness', 'Insufficient sleep', 'Anemia', 'Thyroid disorder', 'Dehydration'],
            'actions': ['Get adequate rest (7-9 hours)', 'Stay hydrated', 'Eat balanced meals with iron-rich foods']
        },
        'shortness of breath': {
            'conditions': ['Asthma attack', 'Anxiety', 'Bronchitis', 'Pneumonia'],
            'actions': ['Sit upright and calm down', 'Use prescribed inhaler if available', 'Seek emergency care if severe']
        },
        'chest pain': {
            'conditions': ['Muscle strain', 'Anxiety', 'Gastroesophageal reflux', 'Pneumonia'],
            'actions': ['SEEK IMMEDIATE MEDICAL ATTENTION if severe', 'Avoid strenuous activity', 'Rest comfortably']
        },
        'rash': {
            'conditions': ['Allergic reaction', 'Viral exanthem', 'Fungal infection', 'Dermatitis'],
            'actions': ['Avoid scratching', 'Use mild soap for cleaning', 'Apply moisturizer or hydrocortisone cream']
        },
        'dizziness': {
            'conditions': ['Inner ear infection', 'Dehydration', 'Low blood pressure', 'Anxiety'],
            'actions': ['Sit or lie down', 'Avoid sudden movements', 'Stay hydrated and eat balanced meals']
        }
    }
    
    # Find matching symptoms
    matched_conditions = {}
    matched_actions = set()
    
    for symptom, info in symptom_db.items():
        if symptom in symptoms_lower:
            matched_conditions[symptom] = info['conditions']
            matched_actions.update(info['actions'])
    
    # Build response
    if matched_conditions:
        analysis = f"**Analysis:** You reported: {', '.join(matched_conditions.keys()).title()}. "
        analysis += "These symptoms are commonly associated with several treatable conditions.\n\n"
        
        analysis += "**Possible Conditions:**\n"
        seen_conditions = set()
        for symptom, conditions in matched_conditions.items():
            for condition in conditions:
                if condition not in seen_conditions:
                    analysis += f"• {condition}\n"
                    seen_conditions.add(condition)
        
        analysis += "\n**Recommended Actions:**\n"
        for i, action in enumerate(list(matched_actions)[:5], 1):
            analysis += f"{i}. {action}\n"
    else:
        # Generic fallback if no symptoms matched
        analysis = f"**Analysis:** Your symptoms have been recorded. Based on '{symptoms_text}', these may warrant professional evaluation.\n\n"
        analysis += "**Possible Considerations:**\n"
        analysis += "• Common viral or bacterial infection\n"
        analysis += "• Fatigue or stress-related symptoms\n"
        analysis += "• Dehydration or nutritional deficiency\n\n"
        analysis += "**Recommended Actions:**\n"
        analysis += "1. Monitor symptoms for any changes\n"
        analysis += "2. Stay hydrated and get adequate rest\n"
        analysis += "3. Contact your healthcare provider if symptoms persist"
    
    analysis += "\n\n⚠️ **Important Disclaimer:** This is an informational assessment only. Always consult with a qualified healthcare provider for professional medical diagnosis and treatment."
    return analysis

def try_ollama_fallback(prompt, symptoms_text=None):
    """Try to use Ollama as fallback when Gemini fails"""
    try:
        print("📡 Attempting Ollama fallback (3s timeout)...")
        payload = {
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False
        }
        response = requests.post(OLLAMA_URL, json=payload, timeout=3)
        if response.status_code == 200:
            result = response.json()
            analysis = result.get("response", "")
            if analysis:
                print("✓ Ollama response received successfully")
                return analysis
    except Exception as e:
        print(f"⚠️ Ollama timeout/failed: {type(e).__name__}")
    
    # If all APIs fail, provide a safe fallback response (INSTANT)
    if symptoms_text:
        print("⚡ Using instant fallback response")
        return generate_smart_analysis(symptoms_text)
    
    return None

def get_symptom_analysis(symptoms_text):
    """
    Feature 12: AI-Powered Symptom Analysis via Google Gemini
    Fast analysis with smart fallback - skips Gemini (unreliable)
    """
    if not symptoms_text or symptoms_text.strip() == '':
        return "Please describe your symptoms for analysis."
    
    symptoms_text = symptoms_text.strip()
    print(f"⚡ Fast symptom analysis: {symptoms_text[:50]}...")
    
    # Skip Gemini entirely (it's broken) - try Ollama briefly then smart fallback
    prompt = f"""Medical symptom analysis: "{symptoms_text}"
Provide: 1) Brief analysis, 2) Possible conditions, 3) Recommendations"""
    
    ollama_result = try_ollama_fallback(prompt, symptoms_text)
    if ollama_result:
        return ollama_result
    
    # Use smart fallback that analyzes specific symptoms
    return generate_smart_analysis(symptoms_text)

def get_health_projection(vitals_summary):
    """
    Generates a health projection using Gemini based on patient vitals
    """
    try:
        model = genai.GenerativeModel(MODEL_NAME)
        
        prompt = f"""You are a medical AI assistant for the GEMCARE Smart Health Monitoring System.

Based on these patient vitals: {vitals_summary}

Provide a concise 3-sentence health projection for the next 7 days:
- Overall health trend
- Any concerning patterns to monitor
- Recommendations for maintaining health

Keep it professional, encouraging, and actionable."""
        
        response = model.generate_content(prompt)
        
        if response and response.text:
            return response.text
        else:
            return "Stable health projection based on current trends."
            
    except Exception as e:
        print(f"✗ Gemini health projection error: {e}")
        return "Projection unavailable. Please consult your healthcare provider."

def analyze_health_metrics(metrics_data):
    """
    Advanced analysis of multiple health metrics using Gemini
    """
    try:
        model = genai.GenerativeModel(MODEL_NAME)
        
        prompt = f"""You are a medical AI assistant analyzing patient health metrics.

Health Metrics: {metrics_data}

Provide 2-3 actionable insights:
- Analyze patterns and trends
- Highlight concerning or positive patterns
- Suggest next steps for patient health management

Be professional and encouraging."""
        
        response = model.generate_content(prompt)
        
        if response and response.text:
            return response.text
        else:
            return "Metrics analyzed. Consult your healthcare provider for personalized recommendations."
            
    except Exception as e:
        print(f"✗ Gemini metrics analysis error: {e}")
        return "Analysis unavailable at this moment."
