import requests
import json

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL_NAME = "phi"  # Smallest model, optimized for low-memory systems

def get_ollama_projection(vitals_summary):
    """
    Communicates with local Ollama to generate a health projection.
    """
    prompt = f"""
    As a medical AI assistant for the Smart Health Monitoring System (GEMCARE), 
    analyze these patient vitals and provide a concise 3-sentence health projection for the next 7 days.
    Vitals Summary: {vitals_summary}
    Keep it professional and encouraging. 
    Format: Bullet points or short paragraph.
    """
    
    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "stream": False
    }
    
    try:
        response = requests.post(OLLAMA_URL, json=payload, timeout=10)
        if response.status_code == 200:
            result = response.json()
            return result.get("response", "Ollama simulation generated stable results.")
    except Exception as e:
        print(f"Ollama connection failed: {e}")
        return None
    
    return "Stable health projection based on current trends."

def get_symptom_analysis(symptoms_text):
    """
    Feature 12: AI-Powered Symptom Analysis via Ollama
    """
    prompt = f"""
    As a medical AI for the Smart Health Monitoring System (GEMCARE), 
    analyze the following symptoms described by the patient: "{symptoms_text}"
    Provide a professional, reassuring, and concise analysis (max 3 sentences).
    Always advise consulting a physician if symptoms persist.
    """
    
    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "stream": False
    }
    
    try:
        print(f"🔄 Connecting to Ollama at {OLLAMA_URL} with model {MODEL_NAME}...")
        response = requests.post(OLLAMA_URL, json=payload, timeout=30)
        print(f"📊 Ollama response status: {response.status_code}")
        print(f"📝 Ollama response body: {response.text[:500]}")
        
        if response.status_code == 200:
            result = response.json()
            analysis = result.get("response", "")
            if analysis:
                print(f"✓ Ollama analysis generated successfully")
                return analysis
            else:
                print(f"⚠️  Empty response from Ollama")
                return "Your symptoms have been logged. Please consult your doctor for a detailed evaluation."
        else:
            print(f"✗ Ollama error - Status {response.status_code}: {response.text}")
            return f"Analysis service error (status {response.status_code}): {response.text[:100]}"
            
    except requests.exceptions.Timeout:
        print(f"✗ Ollama timeout - service taking too long")
        return "Analysis service is processing (please try again)"
    except requests.exceptions.ConnectionError:
        print(f"✗ Ollama connection failed - is Ollama running on {OLLAMA_URL}?")
        return "Analysis unavailable - service not running"
    except Exception as e:
        print(f"✗ Ollama symptom analysis error: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return f"Analysis error: {str(e)[:100]}"
    
    return "Analysis unavailable. Your symptoms have been recorded for your physician's review."
