"""
Advanced Professional PDF Report Generator
Creates comprehensive, professional hospital-grade medical reports using ReportLab
Supports: Patient information, vital signs, lab results, diagnostic findings, treatment plans
"""

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from datetime import datetime
import os
from io import BytesIO
import json

class ProfessionalMedicalPDF:
    """Create professional medical reports using ReportLab"""
    
    def __init__(self, filename, hospital_name="GEMCARE Medical Center", 
                 hospital_logo_path=None, hospital_address=None, hospital_phone=None,
                 hospital_email=None, hospital_registration=None):
        """
        Initialize PDF document
        
        Args:
            filename: Output PDF filename
            hospital_name: Name of hospital
            hospital_logo_path: Path to hospital logo image
            hospital_address: Hospital address
            hospital_phone: Hospital phone
            hospital_email: Hospital email
            hospital_registration: Hospital registration/accreditation number
        """
        self.filename = filename
        self.hospital_name = hospital_name
        self.hospital_logo_path = hospital_logo_path
        self.hospital_address = hospital_address
        self.hospital_phone = hospital_phone
        self.hospital_email = hospital_email
        self.hospital_registration = hospital_registration
        
        self.doc = SimpleDocTemplate(
            filename,
            pagesize=letter,
            rightMargin=0.5*inch,
            leftMargin=0.5*inch,
            topMargin=0.5*inch,
            bottomMargin=0.5*inch
        )
        self.story = []
        self.styles = getSampleStyleSheet()
        self._add_custom_styles()
    
    def _add_custom_styles(self):
        """Add custom paragraph styles"""
        
        # Hospital header style
        self.styles.add(ParagraphStyle(
            name='HospitalName',
            parent=self.styles['Heading1'],
            fontSize=18,
            textColor=colors.HexColor('#1976D2'),
            spaceAfter=6,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))
        
        # Section title style
        self.styles.add(ParagraphStyle(
            name='SectionTitle',
            parent=self.styles['Heading2'],
            fontSize=12,
            textColor=colors.white,
            backColor=colors.HexColor('#1976D2'),
            spaceAfter=12,
            spaceBefore=12,
            leftIndent=6,
            rightIndent=6,
            fontName='Helvetica-Bold'
        ))
        
        # Subsection style
        self.styles.add(ParagraphStyle(
            name='SubsectionTitle',
            parent=self.styles['Heading3'],
            fontSize=11,
            textColor=colors.HexColor('#1976D2'),
            spaceAfter=6,
            spaceBefore=6,
            fontName='Helvetica-Bold'
        ))
        
        # Normal text
        self.styles.add(ParagraphStyle(
            name='BodyText',
            parent=self.styles['BodyText'],
            fontSize=10,
            spaceAfter=6,
            alignment=TA_LEFT
        ))
        
        # Important text
        self.styles.add(ParagraphStyle(
            name='Important',
            parent=self.styles['BodyText'],
            fontSize=10,
            textColor=colors.HexColor('#D32F2F'),
            fontName='Helvetica-Bold',
            spaceAfter=6
        ))
        
        # Footer style
        self.styles.add(ParagraphStyle(
            name='Footer',
            parent=self.styles['BodyText'],
            fontSize=8,
            textColor=colors.grey,
            alignment=TA_CENTER,
            spaceAfter=3
        ))
    
    def add_hospital_header(self):
        """Add professional hospital header"""
        
        # Hospital name and info
        header_data = []
        
        # Row 1: Hospital name and logo
        if self.hospital_logo_path and os.path.exists(self.hospital_logo_path):
            try:
                logo = Image(self.hospital_logo_path, width=0.8*inch, height=0.8*inch)
                header_data.append([
                    logo,
                    Paragraph(self.hospital_name, self.styles['HospitalName']),
                    ""
                ])
            except:
                header_data.append([
                    "",
                    Paragraph(self.hospital_name, self.styles['HospitalName']),
                    ""
                ])
        else:
            header_data.append([
                "",
                Paragraph(self.hospital_name, self.styles['HospitalName']),
                ""
            ])
        
        # Row 2: Hospital details
        hospital_details = self.hospital_address or "Medical Center"
        if self.hospital_registration:
            hospital_details += f"<br/>Registration: {self.hospital_registration}"
        if self.hospital_phone:
            hospital_details += f"<br/>Phone: {self.hospital_phone}"
        if self.hospital_email:
            hospital_details += f"<br/>Email: {self.hospital_email}"
        
        header_table = Table(header_data, colWidths=[1*inch, 3*inch, 1.5*inch])
        header_table.setStyle(TableStyle([
            ('ALIGN', (1, 0), (1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ]))
        
        self.story.append(header_table)
        
        # Hospital contact info
        contact_paragraph = Paragraph(hospital_details, self.styles['Footer'])
        self.story.append(contact_paragraph)
        
        # Divider line
        self.story.append(Spacer(1, 0.1*inch))
        divider = Table([['_' * 90]], colWidths=[7*inch])
        divider.setStyle(TableStyle([('TEXTCOLOR', (0, 0), (0, 0), colors.grey)]))
        self.story.append(divider)
        
        self.story.append(Spacer(1, 0.15*inch))
    
    def add_patient_information(self, patient_data):
        """
        Add patient demographic information
        
        Args:
            patient_data (dict): {
                'patient_id': str,
                'name': str,
                'dob': datetime,
                'age': int,
                'gender': str,
                'blood_group': str,
                'contact': str,
                'address': str,
                'emergency_contact': str,
                'emergency_phone': str,
                'insurance_provider': str,
                'policy_number': str
            }
        """
        self.story.append(Paragraph("PATIENT INFORMATION", self.styles['SectionTitle']))
        
        # Calculate age
        age = patient_data.get('age', 'N/A')
        dob = patient_data.get('dob')
        if dob and not age:
            age = (datetime.now() - dob).days // 365
        
        patient_table_data = [
            ['Patient ID:', patient_data.get('patient_id', 'N/A'), 'Age:', f"{age} years"],
            ['Name:', patient_data.get('name', 'N/A'), 'Gender:', patient_data.get('gender', 'N/A')],
            ['DOB:', str(dob.strftime('%B %d, %Y')) if dob else 'N/A', 'Blood Group:', patient_data.get('blood_group', 'N/A')],
            ['Contact:', patient_data.get('contact', 'N/A'), 'Email:', patient_data.get('email', 'N/A')],
            ['Address:', patient_data.get('address', 'N/A'), '', ''],
        ]
        
        if patient_data.get('insurance_provider'):
            patient_table_data.append(['Insurance:', patient_data.get('insurance_provider'), 'Policy #:', patient_data.get('policy_number', 'N/A')])
        
        if patient_data.get('emergency_contact'):
            patient_table_data.append(['Emergency Contact:', patient_data.get('emergency_contact'), 'Phone:', patient_data.get('emergency_phone', 'N/A')])
        
        pt = Table(patient_table_data, colWidths=[1.8*inch, 2*inch, 1.2*inch, 1.8*inch])
        pt.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#E3F2FD')),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey),
        ]))
        
        self.story.append(pt)
        self.story.append(Spacer(1, 0.15*inch))
    
    def add_doctor_information(self, doctor_data):
        """
        Add doctor information section
        
        Args:
            doctor_data (dict): {
                'name': str,
                'license_number': str,
                'specialization': str,
                'registration_number': str,
                'experience_years': int,
                'signature_path': str
            }
        """
        self.story.append(Paragraph("DOCTOR INFORMATION", self.styles['SectionTitle']))
        
        doctor_table_data = [
            ['Doctor Name:', doctor_data.get('name', 'N/A'), 'License #:', doctor_data.get('license_number', 'N/A')],
            ['Specialization:', doctor_data.get('specialization', 'N/A'), 'Exp. Years:', str(doctor_data.get('experience_years', 'N/A'))],
            ['Registration #:', doctor_data.get('registration_number', 'N/A'), 'Contact:', doctor_data.get('contact', 'N/A')],
        ]
        
        dt = Table(doctor_table_data, colWidths=[1.8*inch, 2*inch, 1.2*inch, 1.8*inch])
        dt.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#F3E5F5')),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey),
        ]))
        
        self.story.append(dt)
        self.story.append(Spacer(1, 0.15*inch))
    
    def add_vital_signs(self, vital_signs_data):
        """
        Add vital signs section
        
        Args:
            vital_signs_data (dict): {
                'heart_rate': float,
                'blood_pressure': str,
                'temperature': float,
                'oxygen_level': float,
                'glucose_level': float,
                'measurement_date': datetime,
                'abnormal_indicators': dict
            }
        """
        self.story.append(Paragraph("VITAL SIGNS & MEASUREMENTS", self.styles['SectionTitle']))
        
        # Create vital signs table
        vitals_table_data = [
            ['Vital Sign', 'Reading', 'Unit', 'Status', 'Reference Range'],
        ]
        
        # Helper function to determine status
        def get_status(value, min_val, max_val, abnormal=False):
            if abnormal:
                return f"⚠️ ABNORMAL"
            elif min_val and max_val and (value < min_val or value > max_val):
                return "⚠️ ABNORMAL"
            else:
                return "✓ NORMAL"
        
        # Add vital signs
        hr = vital_signs_data.get('heart_rate')
        if hr:
            vitals_table_data.append(['Heart Rate', str(hr), 'bpm', get_status(hr, 60, 100), '60-100'])
        
        bp = vital_signs_data.get('blood_pressure')
        if bp:
            vitals_table_data.append(['Blood Pressure', bp, 'mmHg', get_status(1, 0, 200), '< 120/80'])
        
        temp = vital_signs_data.get('temperature')
        if temp:
            vitals_table_data.append(['Temperature', str(temp), '°F', get_status(temp, 97, 99), '97-99'])
        
        o2 = vital_signs_data.get('oxygen_level')
        if o2:
            vitals_table_data.append(['Oxygen Level', str(o2), '%', get_status(o2, 95, 100), '> 95%'])
        
        glucose = vital_signs_data.get('glucose_level')
        if glucose:
            vitals_table_data.append(['Glucose Level', str(glucose), 'mg/dL', get_status(glucose, 70, 100), '70-100'])
        
        vt = Table(vitals_table_data, colWidths=[1.5*inch, 1.2*inch, 1*inch, 1.3*inch, 1.3*inch])
        vt.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1976D2')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#E3F2FD')]),
        ]))
        
        self.story.append(vt)
        
        # Add measurement date
        measure_date = vital_signs_data.get('measurement_date')
        if measure_date:
            date_str = measure_date.strftime('%B %d, %Y at %I:%M %p') if isinstance(measure_date, datetime) else str(measure_date)
            self.story.append(Paragraph(f"<i>Measured on: {date_str}</i>", self.styles['Footer']))
        
        self.story.append(Spacer(1, 0.15*inch))
    
    def add_clinical_findings(self, findings_data):
        """
        Add clinical findings and assessment section
        
        Args:
            findings_data (dict): {
                'chief_complaint': str,
                'history_of_illness': str,
                'physical_examination': str,
                'diagnosis': str,
                'differential_diagnosis': str,
                'assessment': str,
                'clinical_notes': str
            }
        """
        self.story.append(Paragraph("CLINICAL FINDINGS & ASSESSMENT", self.styles['SectionTitle']))
        
        if findings_data.get('chief_complaint'):
            self.story.append(Paragraph("<b>Chief Complaint:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(findings_data['chief_complaint'], self.styles['BodyText']))
        
        if findings_data.get('history_of_illness'):
            self.story.append(Paragraph("<b>History of Present Illness:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(findings_data['history_of_illness'], self.styles['BodyText']))
        
        if findings_data.get('physical_examination'):
            self.story.append(Paragraph("<b>Physical Examination:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(findings_data['physical_examination'], self.styles['BodyText']))
        
        if findings_data.get('diagnosis'):
            self.story.append(Paragraph("<b>Diagnosis:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(findings_data['diagnosis'], self.styles['Important']))
        
        if findings_data.get('differential_diagnosis'):
            self.story.append(Paragraph("<b>Differential Diagnosis:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(findings_data['differential_diagnosis'], self.styles['BodyText']))
        
        if findings_data.get('assessment'):
            self.story.append(Paragraph("<b>Assessment:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(findings_data['assessment'], self.styles['BodyText']))
        
        if findings_data.get('clinical_notes'):
            self.story.append(Paragraph("<b>Clinical Notes:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(findings_data['clinical_notes'], self.styles['BodyText']))
        
        self.story.append(Spacer(1, 0.15*inch))
    
    def add_medications_prescribed(self, medications_list):
        """
        Add medications section
        
        Args:
            medications_list (list): [
                {
                    'name': str,
                    'dosage': str,
                    'frequency': str,
                    'duration': str,
                    'instructions': str
                }
            ]
        """
        if not medications_list:
            return
        
        self.story.append(Paragraph("MEDICATIONS PRESCRIBED", self.styles['SectionTitle']))
        
        med_table_data = [
            ['Medicine Name', 'Dosage', 'Frequency', 'Duration', 'Special Instructions'],
        ]
        
        for med in medications_list:
            med_table_data.append([
                med.get('name', ''),
                med.get('dosage', ''),
                med.get('frequency', ''),
                med.get('duration', ''),
                med.get('instructions', ''),
            ])
        
        mt = Table(med_table_data, colWidths=[1.5*inch, 0.9*inch, 1.2*inch, 0.9*inch, 1.8*inch])
        mt.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1976D2')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F5F5F5')]),
        ]))
        
        self.story.append(mt)
        self.story.append(Spacer(1, 0.15*inch))
    
    def add_recommendations(self, recommendations_data):
        """
        Add recommendations section
        
        Args:
            recommendations_data (dict): {
                'treatment_plan': str,
                'lifestyle_modifications': str,
                'dietary_recommendations': str,
                'exercise_plan': str,
                'follow_up_instructions': str,
                'return_visit_date': str,
                'when_to_seek_emergency_care': str
            }
        """
        self.story.append(Paragraph("RECOMMENDATIONS & DISCHARGE INSTRUCTIONS", self.styles['SectionTitle']))
        
        if recommendations_data.get('treatment_plan'):
            self.story.append(Paragraph("<b>Treatment Plan:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(recommendations_data['treatment_plan'], self.styles['BodyText']))
        
        if recommendations_data.get('lifestyle_modifications'):
            self.story.append(Paragraph("<b>Lifestyle Modifications:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(recommendations_data['lifestyle_modifications'], self.styles['BodyText']))
        
        if recommendations_data.get('dietary_recommendations'):
            self.story.append(Paragraph("<b>Dietary Recommendations:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(recommendations_data['dietary_recommendations'], self.styles['BodyText']))
        
        if recommendations_data.get('exercise_plan'):
            self.story.append(Paragraph("<b>Exercise Plan:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(recommendations_data['exercise_plan'], self.styles['BodyText']))
        
        if recommendations_data.get('follow_up_instructions'):
            self.story.append(Paragraph("<b>Follow-up Instructions:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(recommendations_data['follow_up_instructions'], self.styles['BodyText']))
        
        if recommendations_data.get('return_visit_date'):
            self.story.append(Paragraph("<b>Return Visit Date:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(recommendations_data['return_visit_date'], self.styles['Important']))
        
        if recommendations_data.get('when_to_seek_emergency_care'):
            self.story.append(Paragraph("<b>⚠️ When to Seek Emergency Care:</b>", self.styles['SubsectionTitle']))
            self.story.append(Paragraph(recommendations_data['when_to_seek_emergency_care'], self.styles['Important']))
        
        self.story.append(Spacer(1, 0.15*inch))
    
    def add_doctor_signature(self, doctor_name="", signature_path=None):
        """
        Add doctor signature section
        
        Args:
            doctor_name (str): Doctor's name
            signature_path (str): Path to signature image
        """
        self.story.append(Spacer(1, 0.3*inch))
        
        signature_data = [['', '', '']]
        
        if signature_path and os.path.exists(signature_path):
            try:
                sig_image = Image(signature_path, width=1.5*inch, height=0.7*inch)
                signature_data[0][0] = sig_image
            except:
                pass
        
        signature_table = Table(signature_data, colWidths=[2*inch, 2*inch, 1*inch])
        self.story.append(signature_table)
        
        sig_details = [['_' * 25, '', '_' * 25]]
        sig_table = Table(sig_details, colWidths=[2.2*inch, 1.6*inch, 2.2*inch])
        self.story.append(sig_table)
        
        details_table_sig = Table([
            ['Doctor Signature', '', 'Date'],
            [doctor_name, '', datetime.now().strftime('%B %d, %Y')],
        ], colWidths=[2.2*inch, 1.6*inch, 2.2*inch])
        details_table_sig.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ]))
        self.story.append(details_table_sig)
    
    def add_footer_disclaimer(self):
        """Add footer with legal disclaimer"""
        self.story.append(Spacer(1, 0.2*inch))
        
        footer_text = """
        <b>CONFIDENTIALITY NOTICE:</b> This document contains protected health information and is intended only 
        for the named recipient. If you are not the intended recipient, you are hereby notified that any dissemination, 
        distribution, or copying of this communication is strictly prohibited.<br/><br/>
        
        <b>IMPORTANT:</b> This medical report is based on clinical examination and diagnostic tests performed on the stated date. 
        The diagnosis and recommendations are based on the information available at the time of examination and should be reviewed 
        and confirmed by the treating physician. Patient should follow the prescribed treatment and return for follow-up as recommended.
        """
        
        self.story.append(Paragraph(footer_text, self.styles['Footer']))
    
    def build(self):
        """Build the PDF document"""
        self.doc.build(self.story)
        return self.filename
    
    def get_bytes(self):
        """Get PDF as bytes instead of file"""
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        doc.build(self.story)
        buffer.seek(0)
        return buffer.getvalue()


# Convenience function to generate complete report
def generate_professional_report(filename, hospital_info, patient_info, doctor_info, 
                                 vital_signs, clinical_findings, medications=None, 
                                 recommendations=None):
    """
    Generate a complete professional medical report
    
    Usage:
        generate_professional_report(
            '/path/to/report.pdf',
            hospital_info={...},
            patient_info={...},
            doctor_info={...},
            vital_signs={...},
            clinical_findings={...},
            medications=[...],
            recommendations={...}
        )
    """
    pdf = ProfessionalMedicalPDF(
        filename,
        hospital_name=hospital_info.get('name', 'Medical Center'),
        hospital_logo_path=hospital_info.get('logo_path'),
        hospital_address=hospital_info.get('address'),
        hospital_phone=hospital_info.get('phone'),
        hospital_email=hospital_info.get('email'),
        hospital_registration=hospital_info.get('registration')
    )
    
    # Add all sections
    pdf.add_hospital_header()
    pdf.add_patient_information(patient_info)
    pdf.add_doctor_information(doctor_info)
    pdf.add_vital_signs(vital_signs)
    pdf.add_clinical_findings(clinical_findings)
    
    if medications:
        pdf.add_medications_prescribed(medications)
    
    if recommendations:
        pdf.add_recommendations(recommendations)
    
    pdf.add_doctor_signature(doctor_info.get('name', ''))
    pdf.add_footer_disclaimer()
    
    pdf.build()
    return filename
