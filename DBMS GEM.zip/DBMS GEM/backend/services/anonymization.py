from ..models import User, db
import hashlib

def anonymize_patient_data(patient_id):
    """
    Core 18: Data Anonymization for Research
    Removes personal identifiers from patient data.
    """
    from ..models import VitalSign, PatientConsent
    
    consent = PatientConsent.query.get(patient_id)
    if not (consent and consent.research_consent):
        return None # No consent, no data
        
    vitals = VitalSign.query.filter_by(patient_id=patient_id).all()
    
    # Generate a pseudo-ID using hash of the actual ID
    pseudo_id = hashlib.sha256(str(patient_id).encode()).hexdigest()[:12]
    
    anonymized_records = []
    for v in vitals:
        anonymized_records.append({
            "research_id": pseudo_id,
            "heart_rate": float(v.heart_rate) if v.heart_rate else None,
            "bp_sys": v.blood_pressure_sys,
            "bp_dia": v.blood_pressure_dia,
            "temp": float(v.temperature) if v.temperature else None,
            "timestamp": v.timestamp.strftime("%Y-%m") # Only month/year for privacy
        })
        
    return anonymized_records
def anonymize_vitals(vitals_list):
    """
    Anonymize a list of vital signs for analytics/research.
    Removes patient identifiable information while preserving metrics.
    """
    anonymized_records = []
    
    for vital in vitals_list:
        try:
            record = {
                "heart_rate": float(vital.heart_rate) if vital.heart_rate else None,
                "blood_pressure_sys": int(vital.blood_pressure_sys) if vital.blood_pressure_sys else None,
                "blood_pressure_dia": int(vital.blood_pressure_dia) if vital.blood_pressure_dia else None,
                "temperature": float(vital.temperature) if vital.temperature else None,
                "oxygen_level": float(vital.oxygen_level) if vital.oxygen_level else None,
                "glucose_level": float(vital.glucose_level) if vital.glucose_level else None,
                "timestamp": vital.timestamp.isoformat() if vital.timestamp else None
            }
            anonymized_records.append(record)
        except Exception as e:
            print(f"Error anonymizing vital: {e}")
            continue
    
    return anonymized_records