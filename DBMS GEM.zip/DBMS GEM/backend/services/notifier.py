import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

# Feature 7: Email Notification System
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', "email.alert_tutorial@gmail.com")
SENDER_PASSWORD = os.environ.get('SENDER_PASSWORD', "hkjbkylfubdistde")
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

# Feature 8: SMS Notification System (Twilio)
TWILIO_ACCOUNT_SID = os.environ.get('TWILIO_ACCOUNT_SID', '')
TWILIO_AUTH_TOKEN = os.environ.get('TWILIO_AUTH_TOKEN', '')
TWILIO_PHONE_NUMBER = os.environ.get('TWILIO_PHONE_NUMBER', '')

try:
    from twilio.rest import Client
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False

def send_email_alert(recipient_email, subject, body, attachment_path=None, patient_name=None):
    """
    Feature 7: Email Notification System
    Sends an automated email notification with professional HTML formatting and PDF attachment.
    """
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = SENDER_EMAIL
        msg['To'] = recipient_email

        # Create HTML email body
        html_body = f"""
        <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                    .container {{ max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }}
                    .header {{ background-color: #1976D2; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }}
                    .header h1 {{ margin: 0; font-size: 24px; }}
                    .content {{ padding: 20px; background-color: #f9f9f9; }}
                    .patient-info {{ background-color: white; padding: 15px; border-left: 4px solid #1976D2; margin: 15px 0; }}
                    .alert-box {{ background-color: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 15px 0; border-radius: 4px; }}
                    .footer {{ background-color: #f0f0f0; padding: 15px; text-align: center; font-size: 12px; color: #666; border-radius: 0 0 8px 8px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🏥 GEMCARE</h1>
                        <p>Smart Health Monitoring System</p>
                    </div>
                    <div class="content">
                        <h2>Hello {patient_name or 'Patient'},</h2>
                        <p>{body}</p>
                        
                        <div class="patient-info">
                            <strong>📋 Report Details:</strong><br>
                            Generated: {datetime.now().strftime('%B %d, %Y at %I:%M %p')}<br>
                            System: GEMCARE Health Monitoring
                        </div>
                        
                        <p><strong>Next Steps:</strong></p>
                        <ul>
                            <li>Review your health report attached to this email</li>
                            <li>Follow the recommendations provided in the report</li>
                            <li>Schedule an appointment with your doctor if needed</li>
                            <li>Continue monitoring your vital signs regularly</li>
                        </ul>
                        
                        <div class="alert-box">
                            <strong>⚠️ Important Note:</strong> This report is for informational purposes only. 
                            Please consult your healthcare provider for professional medical advice and diagnosis.
                        </div>
                    </div>
                    <div class="footer">
                        <p>&copy; {datetime.now().year} GEMCARE Smart Health Monitoring System<br>
                        Contact us: support@happyheal.com | Emergency: Call your local emergency services</p>
                    </div>
                </div>
            </body>
        </html>
        """

        # Attach HTML
        part = MIMEText(html_body, 'html')
        msg.attach(part)

        # Attach PDF if provided
        if attachment_path and os.path.exists(attachment_path):
            try:
                attachment = open(attachment_path, 'rb')
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f'attachment; filename={os.path.basename(attachment_path)}')
                msg.attach(part)
                attachment.close()
            except Exception as e:
                print(f"Error attaching file: {e}")

        # Send email
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.send_message(msg)
        server.quit()
        
        print(f"✓ Email sent successfully to {recipient_email}")
        return True
    except Exception as e:
        import traceback
        print(f"✗ SMTP Error: {e}")
        print(traceback.format_exc())
        return False

def trigger_sms_alert(phone_number, message):
    """
    Feature 8: SMS Emergency Notification via Twilio
    """
    if not phone_number:
        print("✗ No phone number provided for SMS")
        return False
    
    # Try Twilio first (if configured)
    if TWILIO_AVAILABLE and TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_PHONE_NUMBER:
        try:
            client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
            call = client.messages.create(
                body=message,
                from_=TWILIO_PHONE_NUMBER,
                to=phone_number
            )
            print(f"✓ SMS sent successfully to {phone_number} (SID: {call.sid})")
            return True
        except Exception as e:
            print(f"✗ Twilio SMS Error: {e}")
            return False
    else:
        # Fallback: Log SMS locally
        print(f"[SMS LOG] To: {phone_number} | Message: {message} | Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        return True

def send_report_notification(patient, file_path):
    """
    Comprehensive notification: sends report via email and SMS to patient with vital signs summary
    """
    email_sent = False
    sms_sent = False
    
    # Email notification
    if patient.email:
        email_body = f"""Your comprehensive health report has been generated successfully. 
Please find the attached PDF report containing detailed analysis of your vital signs, health metrics, and personalized recommendations.

This report includes:
- Complete vital signs history
- Health alerts and abnormalities
- Personalized health recommendations
- Professional medical analysis

Keep this report for your medical records and share it with your healthcare provider."""
        
        email_sent = send_email_alert(
            recipient_email=patient.email,
            subject="Your Health Report from GEMCARE - Important",
            body=email_body,
            attachment_path=file_path,
            patient_name=patient.full_name
        )
    
    # SMS notification with vital signs summary
    if patient.phone:
        sms_message = "HEALTH REPORT GENERATED\n"
        sms_message += f"Patient: {patient.full_name}\n"
        sms_message += f"Status: Report generated and sent to email\n"
        sms_message += "Please check your email for the full PDF report.\n"
        sms_message += "- GEMCARE"
        
        sms_sent = trigger_sms_alert(patient.phone, sms_message)
    
    return {
        "email_sent": email_sent,
        "sms_sent": sms_sent,
        "timestamp": datetime.now().isoformat()
    }
