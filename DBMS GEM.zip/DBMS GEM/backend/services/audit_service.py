from ..models import AuditLog, db
from flask import request
from flask_login import current_user
from functools import wraps

def log_audit(action):
    """
    Core 19: Audit Log & Activity Tracking
    Decorator for logging user actions.
    """
    def decorator(f):
       @wraps(f)
       def decorated_function(*args, **kwargs):
           # Execute the function
           response = f(*args, **kwargs)
           
           # Log the action
           user_id = current_user.id if current_user.is_authenticated else None
           new_log = AuditLog(
               user_id=user_id,
               action=action,
               details=f"IP: {request.remote_addr} | Route: {request.path}",
               ip_address=request.remote_addr
           )
           db.session.add(new_log)
           db.session.commit()
           
           return response
       return decorated_function
    return decorator
