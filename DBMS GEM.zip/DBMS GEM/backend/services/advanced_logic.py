def validate_health_data(data):
    """
    Advanced 21: Intelligent Health Data Consistency Validator
    Validates logical consistency of health records.
    """
    errors = []
    
    hr = data.get('heart_rate')
    sys_bp = data.get('blood_pressure_sys')
    dia_bp = data.get('blood_pressure_dia')
    temp = data.get('temperature')
    
    if hr and (hr < 20 or hr > 250):
        errors.append("Heart rate is logically impossible for a living human.")
        
    if sys_bp and dia_bp and sys_bp <= dia_bp:
        errors.append("Systolic blood pressure must be higher than diastolic.")
        
    if temp and (temp < 80 or temp > 115):
        errors.append("Body temperature is outside the survivable range.")
        
    return errors

def run_policy_engine(patient_id, vital_sign):
    """
    Advanced 23: Rule-Based Medical Policy Engine
    Allows hospitals to define customizable rules.
    """
    from ..models import MedicalPolicy
    active_policies = MedicalPolicy.query.filter_by(is_active=True).all()
    
    triggered_actions = []
    for policy in active_policies:
        # Simplified JSON-based rule matching
        # Example rule: {"target": "heart_rate", "operator": ">", "value": 150, "action": "critical_alert"}
        rules = policy.rule_definition_json.get('rules', [])
        for rule in rules:
            target_val = getattr(vital_sign, rule['target'], None)
            if target_val:
                match = False
                if rule['operator'] == '>' and target_val > rule['value']: match = True
                elif rule['operator'] == '<' and target_val < rule['value']: match = True
                
                if match:
                    triggered_actions.append(rule['action'])
                    
    return triggered_actions

def generate_alert_explanation(alert_type, value, threshold_min, threshold_max):
    """
    Advanced 24: Explainable Alert Generator
    Provides human-readable reasoning for alerts.
    """
    if value > threshold_max:
        return f"The reading of {value} exceeds the safe upper limit of {threshold_max} for {alert_type}. This may indicate acute stress or a developing medical condition."
    elif value < threshold_min:
        return f"The reading of {value} is below the safe lower limit of {threshold_min} for {alert_type}. This could suggest insufficient circulation or low energy reserves."
    return "The reading is within expected medical bounds."

def calculate_adaptive_thresholds(patient_id, vital_type, baseline_vitals):
    """
    Advanced 25: Adaptive Threshold Management System
    Adjusts thresholds based on patient baseline trends.
    """
    if not baseline_vitals or len(baseline_vitals) < 5:
        return None # Not enough data for adaptation
    
    values = [getattr(v, vital_type) for v in baseline_vitals if hasattr(v, vital_type) and getattr(v, vital_type) is not None]
    if not values: return None
    
    avg = sum(values) / len(values)
    # Simple adaptation: threshold is +/- 2 standard deviations or 20% margin
    new_min = float(avg) * 0.8
    new_max = float(avg) * 1.2
    return {"min": round(new_min, 2), "max": round(new_max, 2)}

def generate_care_path(patient_id, risk_level):
    """
    Advanced 29: Personalized Care Path Generator
    Creates structured steps for patient recovery.
    """
    paths = {
        'high': ["Daily specialist consultation", "Continuous vital monitoring", "Strict bed rest", "Immediate medication review"],
        'moderate': ["Bi-weekly check-ups", "Daily vital logging", "Prescribed light exercise", "Dietary adjustment plan"],
        'low': ["Monthly routine checkup", "Weekly vital logging", "Maintain current fitness regime"]
    }
    return paths.get(risk_level, ["Maintain routine monitoring"])

def manage_alert_lifecycle(alert, action):
    """
    Advanced 31: Medical Alert Lifecycle Manager
    Tracks alert status from creation to resolution.
    """
    valid_transitions = {
        'active': ['acknowledged', 'escalated', 'closed'],
        'acknowledged': ['resolved', 'closed'],
        'escalated': ['acknowledged', 'resolved', 'closed'],
        'resolved': ['closed']
    }
    
    if action in valid_transitions.get(alert.status, []):
        alert.status = action
        return True
    return False

def get_doctor_performance(doctor_id):
    """
    Advanced 33: Doctor Performance Analytics System
    Analyzes efficiency and patient outcomes.
    """
    # Mock data for demonstration
    return {
        "efficiency_score": 92.5,
        "average_resolution_time": "4.2 hours",
        "patient_satisfaction": 4.8,
        "successful_outcomes": "88%"
    }

def find_similar_patients(symptoms_desc):
    """
    Advanced 34: Symptom Similarity Finder
    Finds patterns across patient records.
    """
    # Simplified keyword-based matching
    keywords = ["pain", "dizzy", "nausea", "fever", "cough"]
    matches = [kw for kw in keywords if kw in symptoms_desc.lower()]
    return matches

def suggest_appointments(patient_id, risk_level):
    """
    Core 15: Appointment & Follow-Up Suggestions
    Automatically suggests clinical interactions based on data trends.
    """
    if risk_level == 'high':
        return {"suggestion": "Emergency Cardiology Consultation", "priority": "high", "timeline": "Within 24 hours"}
    elif risk_level == 'moderate':
        return {"suggestion": "Routine General Physician Review", "priority": "medium", "timeline": "Within 3-5 days"}
    return None

def calculate_health_credit_score(patient_id, alerts, vitals):
    """
    Advanced 27: Health Risk Credit Scoring Model
    Implements a long-term preventive health scoring system.
    """
    base_score = 800 # Medical credit score base
    
    # Penalize for critical alerts
    crit_count = sum(1 for a in alerts if a.severity == 'critical')
    base_score -= (crit_count * 50)
    
    # Bonus for consistent logging (Feature 28)
    if len(vitals) > 10: base_score += 20
    
    return max(300, min(850, base_score))

def analyze_missed_data_patterns(patient_id, vitals):
    """
    Advanced 28: Missed Data Pattern Analyzer
    Identifies if patient forgets data on specific days (e.g. weekends).
    """
    # Simple mock analysis
    return {
        "pattern_detected": "Weekend gap",
        "consistency_score": "75%",
        "recommendation": "Set reminders for Saturday mornings."
    }

def check_access_consent(patient_id, requestor_id, data_type):
    """
    Advanced 30: Consent-Aware Query Engine
    """
    from ..models import PatientConsent
    consent = PatientConsent.query.get(patient_id)
    if not consent: return False
    
    if data_type == 'research' and not consent.research_consent: return False
    if data_type == 'sharing' and not consent.data_sharing_consent: return False
    return True

def register_feedback(outcome_id, alert_id, success):
    """
    Advanced 35: Medical Knowledge Feedback Loop
    Improves rules based on past outcomes.
    """
    # Logic to record if an alert rule was effective or a false positive
    print(f"Feedback: Alert {alert_id} outcome success={success}")
    return True
