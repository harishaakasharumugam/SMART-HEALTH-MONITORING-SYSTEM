from ..models import Alert, Threshold, db, User
from datetime import datetime
from .advanced_logic import generate_alert_explanation
from .notifier import send_email_alert, trigger_sms_alert

def ensure_default_thresholds(patient_id):
    """ Feature 25: Adaptive Threshold Management (Default Initializer) """
    existing = Threshold.query.filter_by(patient_id=patient_id).first()
    if not existing:
        defaults = [
            ('heart_rate', 60, 100),
            ('temperature', 36.1, 37.2),
            ('oxygen_level', 95, 100),
            ('glucose_level', 70, 140)
        ]
        for v_type, min_v, max_v in defaults:
            db.session.add(Threshold(
                patient_id=patient_id,
                vital_type=v_type,
                min_value=min_v,
                max_value=max_v
            ))
        db.session.commit()

def check_vitals(patient_id, vital_sign):
    """
    Checks patient vitals against thresholds and generates alerts.
    """
    # Ensure patient has thresholds so alerts can trigger (Real-time Email requirement)
    ensure_default_thresholds(patient_id)
    
    thresholds = Threshold.query.filter_by(patient_id=patient_id).all()
    # Advanced 25: If no thresholds, use defaults
    if not thresholds:
        # Fallback to logical consistency validator (Advanced 21)
        pass 

    vitals_map = {
        'heart_rate': vital_sign.heart_rate,
        'temperature': vital_sign.temperature,
        'oxygen_level': vital_sign.oxygen_level,
        'glucose_level': vital_sign.glucose_level
    }

    generated_alerts = []
    patient_user = User.query.get(patient_id)
    
    for t in thresholds:
        val = vitals_map.get(t.vital_type)
        if val is not None:
            # Convert decimal to float for comparison if needed
            current_val = float(val)
            min_val = float(t.min_value)
            max_val = float(t.max_value)
            
            if current_val < min_val or current_val > max_val:
                # Core 4 & 5: Alert Generation
                severity = 'critical' if (current_val < min_val * 0.8 or current_val > max_val * 1.2) else 'warning'
                
                # Advanced 24: Explainable Alert
                explanation = generate_alert_explanation(t.vital_type, current_val, min_val, max_val)
                
                new_alert = Alert(
                    patient_id=patient_id,
                    vital_id=vital_sign.id,
                    alert_type=t.vital_type,
                    severity=severity,
                    description=f"Abnormal {t.vital_type} detected: {current_val}",
                    explanation=explanation
                )
                db.session.add(new_alert)
                generated_alerts.append(new_alert)
                
                # Core 7 & 8: Notifications
                if severity == 'critical':
                    subject = f"URGENT: Critical Health Alert for {patient_user.full_name}"
                    body = f"Alert: {explanation}\nTime: {datetime.utcnow()}\nPlease check the dashboard immediately."
                    send_email_alert(patient_user.email, subject, body)
                    trigger_sms_alert(patient_user.phone, body)
    
    db.session.commit()
    return generated_alerts
