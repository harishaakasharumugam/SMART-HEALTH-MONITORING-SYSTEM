"""
Email Service Module
Handles all email notifications for:
- Report updates
- Alert notifications
- Appointment reminders
- Lab result notifications
- Prescription notifications
"""

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
import threading
from functools import wraps
import logging

logger = logging.getLogger(__name__)

class EmailService:
    """Handles email operations for healthcare system"""
    
    def __init__(self, hospital_settings=None):
        """
        Initialize email service with hospital SMTP settings
        
        Args:
            hospital_settings: HospitalSettings object with SMTP configuration
        """
        self.hospital_settings = hospital_settings
        self.smtp_server = hospital_settings.smtp_server if hospital_settings else os.getenv('SMTP_SERVER')
        self.smtp_port = int(hospital_settings.smtp_port) if hospital_settings else int(os.getenv('SMTP_PORT', 587))
        self.smtp_username = hospital_settings.smtp_username if hospital_settings else os.getenv('SMTP_USERNAME')
        self.smtp_password = hospital_settings.smtp_password if hospital_settings else os.getenv('SMTP_PASSWORD')
        self.from_email = hospital_settings.smtp_from_email if hospital_settings else os.getenv('SMTP_FROM_EMAIL')
        self.from_name = hospital_settings.smtp_from_name if hospital_settings else os.getenv('SMTP_FROM_NAME', 'Healthcare System')
        
    def send_async(func):
        """Decorator to send emails asynchronously"""
        @wraps(func)
        def wrapper(*args, **kwargs):
            thread = threading.Thread(target=func, args=args, kwargs=kwargs)
            thread.daemon = True
            thread.start()
        return wrapper
    
    def _send_email_smtp(self, recipient_email, subject, html_body, text_body=None, attachments=None):
        """
        Core method to send email via SMTP
        
        Args:
            recipient_email (str): Recipient email address
            subject (str): Email subject
            html_body (str): Email body in HTML format
            text_body (str): Plain text fallback
            attachments (list): List of file paths to attach
            
        Returns:
            dict: {'success': bool, 'message': str, 'error': str}
        """
        try:
            # Create email message
            message = MIMEMultipart('alternative')
            message['From'] = f"{self.from_name} <{self.from_email}>"
            message['To'] = recipient_email
            message['Subject'] = subject
            message['Date'] = datetime.now().strftime('%a, %d %b %Y %H:%M:%S +0000')
            
            # Attach text and HTML versions
            if text_body:
                message.attach(MIMEText(text_body, 'plain'))
            message.attach(MIMEText(html_body, 'html'))
            
            # Attach files
            if attachments:
                for file_path in attachments:
                    try:
                        with open(file_path, 'rb') as attachment:
                            part = MIMEBase('application', 'octet-stream')
                            part.set_payload(attachment.read())
                            encoders.encode_base64(part)
                            part.add_header('Content-Disposition', f'attachment; filename= {os.path.basename(file_path)}')
                            message.attach(part)
                    except Exception as e:
                        logger.warning(f"Could not attach file {file_path}: {str(e)}")
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_username, self.smtp_password)
                server.sendmail(self.from_email, recipient_email, message.as_string())
            
            logger.info(f"Email sent successfully to {recipient_email}")
            return {'success': True, 'message': 'Email sent successfully'}
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error sending email to {recipient_email}: {error_msg}")
            return {'success': False, 'error': error_msg}
    
    def log_email(self, db, recipient_email, subject, body, email_type, related_object_type=None, related_object_id=None, attachment_count=0):
        """
        Log email in database for audit trail
        
        Args:
            db: SQLAlchemy database instance
            recipient_email (str): Recipient email
            subject (str): Email subject
            body (str): Email body
            email_type (str): Type of email ('report_notification', 'alert', etc.)
            related_object_type (str): Type of related object
            related_object_id (int): ID of related object
            attachment_count (int): Number of attachments
        """
        from .models_extended import EmailLog
        from .models import User
        
        try:
            # Find user by email
            user = User.query.filter_by(email=recipient_email).first()
            
            email_log = EmailLog(
                recipient_email=recipient_email,
                recipient_user_id=user.id if user else None,
                subject=subject,
                body=body[:1000],  # Store first 1000 chars
                email_type=email_type,
                related_object_type=related_object_type,
                related_object_id=related_object_id,
                attachment_count=attachment_count,
                status='sent',
                sent_at=datetime.utcnow()
            )
            db.session.add(email_log)
            db.session.commit()
        except Exception as e:
            logger.error(f"Error logging email: {str(e)}")
    
    # ==================== SPECIFIC EMAIL TEMPLATES ====================
    
    def send_report_notification(self, db, patient_id, doctor_name, hospital_name, 
                                 report_summary, key_findings, follow_up_date, pdf_attachment):
        """
        Send email when doctor updates/creates a patient report
        
        Args:
            db: Database instance
            patient_id (int): Patient's ID (email fetched from database)
            doctor_name (str): Doctor's name
            hospital_name (str): Hospital name
            report_summary (str): Brief summary of report
            key_findings (str): Key findings from report
            follow_up_date (str): Recommended follow-up date
            pdf_attachment (str): Path to PDF report file
        """
        from backend.models import User
        
        # Fetch patient from database
        patient = User.query.filter_by(id=patient_id).first()
        if not patient or not patient.email:
            logger.error(f"Patient {patient_id} not found or has no email")
            return {'success': False, 'error': 'Patient email not found'}
        
        patient_email = patient.email
        patient_name = patient.full_name or "Patient"
        
        subject = f"Your Medical Report from {hospital_name}"
        
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .container {{ max-width: 600px; margin: 0 auto; }}
                .header {{ background-color: #1976D2; color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; background-color: #f5f5f5; }}
                .section {{ background-color: white; padding: 15px; margin: 10px 0; border-left: 4px solid #1976D2; }}
                .section-title {{ font-weight: bold; color: #1976D2; margin-bottom: 10px; }}
                .footer {{ text-align: center; font-size: 12px; color: #666; padding: 20px; }}
                .button {{ display: inline-block; background-color: #1976D2; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>{hospital_name}</h1>
                    <p>Your Medical Report Notification</p>
                </div>
                
                <div class="content">
                    <div class="section">
                        <p>Dear {patient_name},</p>
                        <p>Your medical report has been prepared by Dr. {doctor_name} at {hospital_name}.</p>
                    </div>
                    
                    <div class="section">
                        <div class="section-title">Report Summary</div>
                        <p>{report_summary}</p>
                    </div>
                    
                    <div class="section">
                        <div class="section-title">Key Findings</div>
                        <p>{key_findings}</p>
                    </div>
                    
                    <div class="section">
                        <div class="section-title">Follow-up Recommendation</div>
                        <p><strong>Recommended Follow-up Date:</strong> {follow_up_date}</p>
                    </div>
                    
                    <div class="section">
                        <p>Please review the attached PDF report for complete details.</p>
                        <p>If you have any questions, please contact {hospital_name} immediately.</p>
                    </div>
                    
                    <div style="text-align: center; margin: 20px 0;">
                        <a href="#" class="button">View Full Report</a>
                    </div>
                </div>
                
                <div class="footer">
                    <p>This is a confidential message from {hospital_name}. Please do not share with unauthorized persons.</p>
                    <p>&copy; {datetime.now().year} {hospital_name}. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        text_body = f"""
Dear {patient_name},

Your medical report has been prepared by Dr. {doctor_name}.

REPORT SUMMARY:
{report_summary}

KEY FINDINGS:
{key_findings}

FOLLOW-UP RECOMMENDATION:
Recommended Follow-up Date: {follow_up_date}

Please review the attached PDF report for complete details.
If you have any questions, please contact {hospital_name}.

This is a confidential message from {hospital_name}.
© {datetime.now().year} {hospital_name}. All rights reserved.
        """
        
        attachments = [pdf_attachment] if pdf_attachment else []
        
        result = self._send_email_smtp(patient_email, subject, html_body, text_body, attachments)
        
        if result['success']:
            self.log_email(db, patient_email, subject, html_body, 'report_notification', 
                          related_object_type='consultation_note', attachment_count=len(attachments))
        
        return result
    
    def send_alert_notification(self, db, patient_id, alert_type, severity,
                               description, vital_readings, immediate_action_required):
        """
        Send alert notification when abnormal vitals detected
        
        Args:
            db: Database instance
            patient_id (int): Patient's ID (email fetched from database)
            alert_type (str): Type of alert
            severity (str): Alert severity ('warning' or 'critical')
            description (str): Alert description
            vital_readings (str): HTML formatted vital readings
            immediate_action_required (bool): Whether immediate action needed
        """
        from backend.models import User
        
        # Fetch patient from database
        patient = User.query.filter_by(id=patient_id).first()
        if not patient or not patient.email:
            logger.error(f"Patient {patient_id} not found or has no email")
            return {'success': False, 'error': 'Patient email not found'}
        
        recipient_email = patient.email
        patient_name = patient.full_name or "Patient"
        
        subject = f"⚠️ ALERT: {alert_type} - Medical Alert for {patient_name}"
        
        alert_color = '#D32F2F' if severity == 'critical' else '#F57C00'  # Red for critical, Orange for warning
        
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .container {{ max-width: 600px; margin: 0 auto; }}
                .alert-header {{ background-color: {alert_color}; color: white; padding: 20px; text-align: center; }}
                .alert-title {{ font-size: 24px; font-weight: bold; margin: 0; }}
                .alert-severity {{ font-size: 14px; margin-top: 5px; }}
                .content {{ padding: 20px; background-color: #f5f5f5; }}
                .section {{ background-color: white; padding: 15px; margin: 10px 0; border-left: 4px solid {alert_color}; }}
                .section-title {{ font-weight: bold; color: {alert_color}; margin-bottom: 10px; }}
                .vital {{ display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }}
                .vital-name {{ font-weight: bold; }}
                .vital-value {{ color: {alert_color}; }}
                .action-required {{ background-color: {alert_color}; color: white; padding: 15px; text-align: center; font-weight: bold; border-radius: 5px; margin: 15px 0; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="alert-header">
                    <p class="alert-title">⚠️ MEDICAL ALERT</p>
                    <p class="alert-severity">Severity: {severity.upper()}</p>
                </div>
                
                <div class="content">
                    <div class="section">
                        <div class="section-title">Alert Type: {alert_type}</div>
                        <p>Patient: <strong>{patient_name}</strong></p>
                        <p>Description: {description}</p>
                    </div>
                    
                    <div class="section">
                        <div class="section-title">Current Vital Readings</div>
                        {vital_readings}
                    </div>
                    
                    {"<div class='action-required'>IMMEDIATE ACTION REQUIRED - Please contact healthcare provider immediately</div>" if immediate_action_required else ""}
                    
                    <div class="section">
                        <p><strong>Recommended Actions:</strong></p>
                        <ul>
                            <li>Monitor the patient closely</li>
                            <li>Contact the treating physician</li>
                            <li>Follow the treatment plan</li>
                            <li>Seek emergency care if symptoms worsen</li>
                        </ul>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        
        result = self._send_email_smtp(recipient_email, subject, html_body)
        
        if result['success']:
            self.log_email(db, recipient_email, subject, html_body, 'alert_notification', 
                          related_object_type='alert')
        
        return result
    
    def send_appointment_reminder(self, db, patient_id, doctor_name, 
                                 appointment_date, appointment_time, location):
        """
        Send appointment reminder email
        
        Args:
            db: Database instance
            patient_id (int): Patient's ID (email fetched from database)
            doctor_name (str): Doctor's name
            appointment_date (str): Appointment date
            appointment_time (str): Appointment time
            location (str): Appointment location
        """
        from backend.models import User
        
        # Fetch patient from database
        patient = User.query.filter_by(id=patient_id).first()
        if not patient or not patient.email:
            logger.error(f"Patient {patient_id} not found or has no email")
            return {'success': False, 'error': 'Patient email not found'}
        
        patient_email = patient.email
        patient_name = patient.full_name or "Patient"
        
        subject = f"Appointment Reminder: {appointment_date} at {appointment_time}"
        
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .container {{ max-width: 600px; margin: 0 auto; }}
                .header {{ background-color: #1976D2; color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; background-color: #f5f5f5; }}
                .section {{ background-color: white; padding: 15px; margin: 10px 0; border-left: 4px solid #1976D2; }}
                .appointment-details {{ background-color: #E3F2FD; padding: 15px; border-radius: 5px; margin: 15px 0; }}
                .detail-row {{ display: flex; justify-content: space-between; padding: 5px 0; }}
                .detail-label {{ font-weight: bold; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Reminder: You have an Appointment</h1>
                </div>
                
                <div class="content">
                    <div class="section">
                        <p>Dear {patient_name},</p>
                        <p>This is a reminder about your upcoming appointment.</p>
                    </div>
                    
                    <div class="appointment-details">
                        <div class="detail-row">
                            <span class="detail-label">Doctor:</span>
                            <span>Dr. {doctor_name}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Date:</span>
                            <span>{appointment_date}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Time:</span>
                            <span>{appointment_time}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Location:</span>
                            <span>{location}</span>
                        </div>
                    </div>
                    
                    <div class="section">
                        <p><strong>What to Bring:</strong></p>
                        <ul>
                            <li>Valid ID and insurance card</li>
                            <li>Any recent medical reports</li>
                            <li>Current medications list</li>
                            <li>Any medical test results</li>
                        </ul>
                    </div>
                    
                    <div class="section">
                        <p>If you need to cancel or reschedule, please contact us at least 24 hours in advance.</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        
        result = self._send_email_smtp(patient_email, subject, html_body)
        
        if result['success']:
            self.log_email(db, patient_email, subject, html_body, 'appointment_reminder', 
                          related_object_type='appointment')
        
        return result
    
    def send_lab_result_notification(self, db, patient_id, test_name, 
                                    results_summary, has_abnormal_values, pdf_attachment):
        """
        Send email when lab results are available
        
        Args:
            db: Database instance
            patient_id (int): Patient's ID (email fetched from database)
            test_name (str): Name of the lab test
            results_summary (str): Summary of results
            has_abnormal_values (bool): Whether results have abnormal values
            pdf_attachment (str): Path to PDF results
        """
        from backend.models import User
        
        # Fetch patient from database
        patient = User.query.filter_by(id=patient_id).first()
        if not patient or not patient.email:
            logger.error(f"Patient {patient_id} not found or has no email")
            return {'success': False, 'error': 'Patient email not found'}
        
        patient_email = patient.email
        patient_name = patient.full_name or "Patient"
        
        subject = f"Your Lab Results: {test_name}"
        
        abnormal_note = ""
        if has_abnormal_values:
            abnormal_note = """
            <div style="background-color: #FFF3E0; padding: 15px; border-left: 4px solid #F57C00; margin: 15px 0;">
                <strong>⚠️ NOTE:</strong> Some results are outside the normal range. Please consult with your doctor for interpretation.
            </div>
            """
        
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .container {{ max-width: 600px; margin: 0 auto; }}
                .header {{ background-color: #1976D2; color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; background-color: #f5f5f5; }}
                .section {{ background-color: white; padding: 15px; margin: 10px 0; border-left: 4px solid #1976D2; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Your Lab Test Results</h1>
                </div>
                
                <div class="content">
                    <div class="section">
                        <p>Dear {patient_name},</p>
                        <p>Your lab test results for <strong>{test_name}</strong> are now available.</p>
                    </div>
                    
                    {abnormal_note}
                    
                    <div class="section">
                        <p><strong>Results Summary:</strong></p>
                        <p>{results_summary}</p>
                    </div>
                    
                    <div class="section">
                        <p>Please find the detailed results in the attached PDF file.</p>
                        <p>If you have any questions, please contact our laboratory or your healthcare provider.</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        
        attachments = [pdf_attachment] if pdf_attachment else []
        
        result = self._send_email_smtp(patient_email, subject, html_body, attachments=attachments)
        
        if result['success']:
            self.log_email(db, patient_email, subject, html_body, 'lab_result_notification', 
                          related_object_type='lab_result', attachment_count=len(attachments))
        
        return result
    
    def send_prescription_notification(self, db, patient_id, medicines, 
                                      special_instructions, doctors_advice):
        """
        Send email when new prescription is issued
        
        Args:
            db: Database instance
            patient_id (int): Patient's ID (email fetched from database)
            medicines (list): List of medicine dicts with 'name', 'dosage', 'frequency', 'duration'
            special_instructions (str): Special instructions
            doctors_advice (str): Doctor's advice
        """
        from backend.models import User
        
        # Fetch patient from database
        patient = User.query.filter_by(id=patient_id).first()
        if not patient or not patient.email:
            logger.error(f"Patient {patient_id} not found or has no email")
            return {'success': False, 'error': 'Patient email not found'}
        
        patient_email = patient.email
        patient_name = patient.full_name or "Patient"
        
        subject = "New Prescription Available"
        
        medicines_html = ""
        for med in medicines:
            medicines_html += f"""
            <div style="background-color: #F5F5F5; padding: 10px; margin: 5px 0; border-radius: 3px;">
                <strong>{med['name']}</strong> - {med['dosage']}<br>
                Frequency: {med['frequency']}<br>
                Duration: {med['duration']}
            </div>
            """
        
        html_body = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .container {{ max-width: 600px; margin: 0 auto; }}
                .header {{ background-color: #1976D2; color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; background-color: #f5f5f5; }}
                .section {{ background-color: white; padding: 15px; margin: 10px 0; border-left: 4px solid #1976D2; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>New Prescription</h1>
                </div>
                
                <div class="content">
                    <div class="section">
                        <p>Dear {patient_name},</p>
                        <p>A new prescription has been issued for you.</p>
                    </div>
                    
                    <div class="section">
                        <strong>Prescribed Medicines:</strong>
                        {medicines_html}
                    </div>
                    
                    {f"<div class='section'><strong>Special Instructions:</strong><p>{special_instructions}</p></div>" if special_instructions else ""}
                    
                    {f"<div class='section'><strong>Doctor's Advice:</strong><p>{doctors_advice}</p></div>" if doctors_advice else ""}
                    
                    <div class="section">
                        <p><strong>Important:</strong></p>
                        <ul>
                            <li>Take medicines exactly as prescribed</li>
                            <li>Do not skip doses</li>
                            <li>Inform your doctor about any side effects</li>
                            <li>Do not exceed the recommended dosage</li>
                        </ul>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        
        result = self._send_email_smtp(patient_email, subject, html_body)
        
        if result['success']:
            self.log_email(db, patient_email, subject, html_body, 'prescription_notification', 
                          related_object_type='prescription')
        
        return result


# Utility function to get email service instance
def get_email_service(db=None):
    """Get configured email service instance"""
    from .models_extended import HospitalSettings
    
    if db:
        hospital = HospitalSettings.query.first()
        if hospital and hospital.smtp_server:
            return EmailService(hospital)
    
    return EmailService()
