from ..models import CaregiverAssignment

def has_access(caregiver_id, patient_id, required_level='view'):
    """
    Core 16: Family / Caregiver Access Control
    Checks if a caregiver has the required access to a patient's data.
    """
    assignment = CaregiverAssignment.query.filter_by(
        caregiver_id=caregiver_id, 
        patient_id=patient_id
    ).first()
    
    if not assignment:
        return False
        
    if required_level == 'manage' and assignment.access_level != 'manage':
        return False
        
    return True
