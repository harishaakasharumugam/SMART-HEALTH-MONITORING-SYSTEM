from fpdf import FPDF
import os
from datetime import datetime

class AdvancedHealthPDF(FPDF):
    def __init__(self, hospital_name="GEMCARE Medical Center", doctor_name=None):
        super().__init__()
        self.hospital_name = hospital_name
        self.doctor_name = doctor_name
        self.page_width = 210
        self.page_height = 297

    def header(self):
        # Hospital Header with Blue Background
        self.set_fill_color(25, 118, 210)  # Professional Blue
        self.rect(0, 0, self.page_width, 35, 'F')
        
        # Hospital Name
        self.set_font('Arial', 'B', 20)
        self.set_text_color(255, 255, 255)  # White text
        self.cell(0, 12, self.hospital_name, 0, 1, 'C')
        
        # Subtitle
        self.set_font('Arial', 'I', 10)
        self.set_text_color(220, 220, 220)
        self.cell(0, 8, 'Comprehensive Patient Health Report', 0, 1, 'C')
        self.set_text_color(0, 0, 0)  # Reset to black
        self.ln(3)

    def footer(self):
        self.set_y(-20)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(100, 100, 100)
        
        # Divider line
        self.set_line_width(0.3)
        self.line(10, self.get_y() - 5, 200, self.get_y() - 5)
        
        self.cell(0, 5, f'Page {self.page_no()}', 0, 0, 'R')
        self.set_xy(10, self.get_y() + 5)
        self.cell(0, 5, f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}', 0, 0, 'L')
        self.set_text_color(0, 0, 0)

    def section_title(self, title, color=(25, 118, 210)):
        # Section Title with colored background
        self.set_fill_color(color[0], color[1], color[2])
        self.set_font('Arial', 'B', 13)
        self.set_text_color(255, 255, 255)
        self.cell(0, 10, title, 0, 1, 'L', True)
        self.set_text_color(0, 0, 0)
        self.ln(2)

    def colored_cell(self, w, h, txt, border=1, align='L', fill_color=(240, 240, 240)):
        self.set_fill_color(fill_color[0], fill_color[1], fill_color[2])
        self.cell(w, h, txt, border=border, align=align, fill=True)

def generate_patient_report(patient, vitals, alerts, reports_dir):
    """
    Core 11: Enhanced Health Report PDF Generator
    Creates a colorful, comprehensive patient health report
    """
    pdf = AdvancedHealthPDF(hospital_name="GEMCARE Medical Center", doctor_name=None)
    pdf.add_page()
    
    # ==================== PATIENT INFORMATION ====================
    pdf.section_title('PATIENT INFORMATION', (41, 128, 185))
    
    pdf.set_font('Arial', '', 10)
    info_data = [
        ('Patient Name:', patient.full_name),
        ('Email:', patient.email),
        ('Registration Date:', patient.created_at.strftime("%B %d, %Y") if hasattr(patient, 'created_at') else 'N/A'),
        ('Report Generated:', datetime.now().strftime("%B %d, %Y at %I:%M %p")),
    ]
    
    col_width = 50
    for label, value in info_data:
        pdf.set_font('Arial', 'B', 10)
        pdf.cell(col_width, 8, label, 0, 0)
        pdf.set_font('Arial', '', 10)
        pdf.cell(0, 8, str(value), 0, 1)
    
    pdf.ln(5)
    
    # ==================== VITALS SUMMARY ====================
    pdf.section_title('VITAL SIGNS SUMMARY', (46, 204, 113))
    
    if vitals:
        latest_vital = vitals[0]
        pdf.set_font('Arial', '', 10)
        
        # Create a 2-column layout for vitals
        col1_width = 95
        col2_width = 95
        
        vital_stats = [
            ('Heart Rate:', f"{latest_vital.heart_rate} bpm", 'Temperature:', f"{latest_vital.temperature}°F"),
            ('Blood Pressure (Sys):', f"{latest_vital.blood_pressure_sys} mmHg", 'Blood Pressure (Dia):', f"{latest_vital.blood_pressure_dia} mmHg"),
            ('Oxygen Level:', f"{latest_vital.oxygen_level}%", 'Glucose Level:', f"{latest_vital.glucose_level} mg/dL"),
        ]
        
        for stat in vital_stats:
            pdf.set_font('Arial', 'B', 9)
            pdf.cell(30, 8, stat[0], 0, 0)
            pdf.set_font('Arial', '', 9)
            pdf.cell(col1_width - 30, 8, str(stat[1]), 0, 0)
            pdf.set_font('Arial', 'B', 9)
            pdf.cell(30, 8, stat[2], 0, 0)
            pdf.set_font('Arial', '', 9)
            pdf.cell(col2_width - 30, 8, str(stat[3]), 0, 1)
        
        pdf.ln(3)
    
    # ==================== VITALS HISTORY TABLE ====================
    pdf.section_title('RECENT VITALS HISTORY (Last 10 Readings)', (155, 89, 182))
    
    pdf.set_font('Arial', 'B', 9)
    pdf.set_text_color(255, 255, 255)
    pdf.set_fill_color(155, 89, 182)  # Purple
    
    # Header row
    pdf.cell(28, 8, 'Date', 1, 0, 'C', True)
    pdf.cell(20, 8, 'HR', 1, 0, 'C', True)
    pdf.cell(26, 8, 'BP Sys', 1, 0, 'C', True)
    pdf.cell(26, 8, 'BP Dia', 1, 0, 'C', True)
    pdf.cell(20, 8, 'Temp', 1, 0, 'C', True)
    pdf.cell(18, 8, 'O2', 1, 0, 'C', True)
    pdf.cell(22, 8, 'Glucose', 1, 1, 'C', True)
    
    pdf.set_text_color(0, 0, 0)
    pdf.set_font('Arial', '', 8)
    
    # Data rows with alternating colors
    for i, v in enumerate(vitals[:10]):
        if i % 2 == 0:
            pdf.set_fill_color(245, 245, 245)
        else:
            pdf.set_fill_color(255, 255, 255)
        
        pdf.cell(28, 7, v.timestamp.strftime("%m-%d"), 1, 0, 'C', True)
        pdf.cell(20, 7, str(int(v.heart_rate)) if v.heart_rate else 'N/A', 1, 0, 'C', True)
        pdf.cell(26, 7, str(int(v.blood_pressure_sys)) if v.blood_pressure_sys else 'N/A', 1, 0, 'C', True)
        pdf.cell(26, 7, str(int(v.blood_pressure_dia)) if v.blood_pressure_dia else 'N/A', 1, 0, 'C', True)
        pdf.cell(20, 7, str(v.temperature) if v.temperature else 'N/A', 1, 0, 'C', True)
        pdf.cell(18, 7, str(int(v.oxygen_level)) if v.oxygen_level else 'N/A', 1, 0, 'C', True)
        pdf.cell(22, 7, str(int(v.glucose_level)) if v.glucose_level else 'N/A', 1, 1, 'C', True)
    
    pdf.ln(5)
    
    # ==================== ALERTS & ABNORMALITIES ====================
    if alerts:
        pdf.section_title('HEALTH ALERTS & ABNORMALITIES', (231, 76, 60))
        
        pdf.set_font('Arial', '', 9)
        for idx, a in enumerate(alerts[:8], 1):
            # Alert header
            severity_color = {
                'critical': (231, 76, 60),
                'high': (230, 126, 34),
                'medium': (241, 196, 15),
                'low': (52, 152, 219)
            }.get(a.severity.lower(), (100, 100, 100))
            
            pdf.set_text_color(severity_color[0], severity_color[1], severity_color[2])
            pdf.set_font('Arial', 'B', 9)
            pdf.cell(0, 7, f"Alert {idx}: {a.alert_type.upper()} [{a.severity.upper()}]", 0, 1)
            
            # Alert details
            pdf.set_text_color(0, 0, 0)
            pdf.set_font('Arial', '', 8)
            pdf.multi_cell(0, 5, f"  - {a.description}")
            pdf.set_font('Arial', 'I', 7)
            pdf.set_text_color(100, 100, 100)
            pdf.cell(0, 5, f"  Reported: {a.created_at.strftime('%Y-%m-%d %H:%M')}", 0, 1)
            pdf.set_text_color(0, 0, 0)
            pdf.ln(2)
    else:
        pdf.section_title('HEALTH STATUS', (46, 204, 113))
        pdf.set_font('Arial', '', 10)
        pdf.set_text_color(46, 204, 113)
        pdf.cell(0, 10, '[OK] No recent abnormal alerts detected. Keep maintaining healthy practices.', 0, 1)
        pdf.set_text_color(0, 0, 0)
        pdf.ln(5)
    
    # ==================== RECOMMENDATIONS ====================
    pdf.section_title('RECOMMENDATIONS', (52, 73, 94))
    
    pdf.set_font('Arial', '', 9)
    recommendations = [
        "- Schedule regular check-ups with your healthcare provider",
        "- Maintain consistent vital signs logging for better health tracking",
        "- Follow the doctor's prescribed medication and treatment plan",
        "- Engage in moderate physical activity as recommended by your physician",
        "- Maintain a balanced diet and adequate hydration",
        "- Manage stress through relaxation techniques and adequate sleep",
    ]
    
    for rec in recommendations:
        pdf.multi_cell(0, 5, rec)
    
    pdf.ln(3)
    
    # ==================== FOOTER NOTE ====================
    pdf.set_font('Arial', 'I', 8)
    pdf.set_text_color(150, 150, 150)
    pdf.multi_cell(0, 4, 
        "This report is generated by the GEMCARE Smart Health Monitoring System. "
        "It is intended for informational purposes only and should not be used as a substitute for professional medical advice. "
        "Please consult your healthcare provider for diagnosis and treatment recommendations."
    )
    
    # Custom naming: PatientName_YYYY-MM-DD.pdf
    date_str = datetime.now().strftime('%Y-%m-%d')
    clean_name = "".join(x for x in patient.full_name if x.isalnum())
    filename = f"{clean_name}_{date_str}.pdf"
    filepath = os.path.join(reports_dir, filename)
    
    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir)
        
    pdf.output(filepath)
    return filepath
