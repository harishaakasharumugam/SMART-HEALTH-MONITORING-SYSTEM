from ..models import Symptom, db
from sqlalchemy import text

def find_similar_symptoms(query_text):
    """
    Advanced 34: Symptom Similarity Finder
    Identifies patients with similar symptom patterns using database-level matching.
    """
    # Simplified text-based similarity using MySQL LIKE (in production, use Full-Text Search)
    search_pattern = f"%{query_text}%"
    similar = Symptom.query.filter(Symptom.description.like(search_pattern)).limit(10).all()
    
    results = []
    for s in similar:
        results.append({
            "patient_id": s.patient_id,
            "description": s.description,
            "severity": s.severity,
            "timestamp": s.timestamp.strftime("%Y-%m-%d")
        })
        
    return results
