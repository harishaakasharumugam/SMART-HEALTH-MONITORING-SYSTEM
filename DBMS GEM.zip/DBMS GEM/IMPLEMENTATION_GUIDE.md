# Implementation Integration Guide

## Overview
This guide shows how to integrate the new advanced healthcare features into your existing application.

---

## 1. DATABASE SETUP

### Step 1: Create Extended Models Tables
Add the extended models to your database schema. The new tables are in `backend/models_extended.py`:

```bash
# Run database migrations
python
>>> from backend.app import create_app, db
>>> from backend.models_extended import *
>>> app = create_app()
>>> with app.app_context():
...     db.create_all()
```

Or create a migration SQL file with:
```sql
-- Run the SQL from models_extended.py file
-- This includes all new tables like:
-- - patient_extended_profiles
-- - prescriptions
-- - appointments
-- - lab_tests, lab_results
-- - consultation_notes
-- - treatment_plans
-- - medical_documents
-- - hospital_settings
-- - email_logs
```

### Step 2: Update Hospital Settings
Insert hospital configuration:

```python
from backend.models_extended import HospitalSettings

hospital = HospitalSettings(
    hospital_name='HAPPY HEAL Medical Center',
    hospital_registration_number='REG123456',
    address='123 Health Street, City',
    city='City Name',
    state='State',
    postal_code='12345',
    phone='+1-555-0123',
    email='info@hospitalhappy.com',
    website='www.hospitalhappy.com',
    smtp_server='smtp.gmail.com',
    smtp_port=587,
    smtp_username='your-email@gmail.com',
    smtp_password='your-app-password',
    smtp_from_email='noreply@hospitalhappy.com',
    smtp_from_name='HAPPY HEAL Medical Center'
)
db.session.add(hospital)
db.session.commit()
```

---

## 2. INTEGRATION WITH EXISTING FILES

### Step 1: Update `backend/app.py`

Add the new blueprint to your app initialization:

```python
def create_app():
    app = Flask(__name__)
    # ... existing code ...
    
    # Register existing blueprints
    from .routes.auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint)
    
    from .routes.main import main as main_blueprint
    app.register_blueprint(main_blueprint)
    
    from .routes.api import api as api_blueprint
    app.register_blueprint(api_blueprint)
    
    # ADD THIS: Register new advanced features blueprint
    from .routes.advanced_api import advanced_api as advanced_api_blueprint
    app.register_blueprint(advanced_api_blueprint)
    
    # ... rest of code ...
    return app
```

### Step 2: Update `backend/models.py`

Add import for extended models:

```python
# At the top of models.py
from .models_extended import (
    PatientExtendedProfile, Prescription, Appointment,
    ConsultationNote, TreatmentPlan, MedicalDocument,
    HospitalSettings, Department, EmailLog, Medicine,
    LabTest, LabResult, LabOrder
)
```

### Step 3: Update HTML Templates

Add navigation links for new features in your base template or dashboard templates:

```html
<!-- Add these menu items to your dashboard -->
<a href="/prescriptions" class="menu-item">📋 Prescriptions</a>
<a href="/appointments" class="menu-item">📅 Appointments</a>
<a href="/consultation-notes" class="menu-item">📝 Medical Notes</a>
<a href="/treatment-plans" class="menu-item">🎯 Treatment Plans</a>
<a href="/lab-results" class="menu-item">🧪 Lab Results</a>
<a href="/medical-documents" class="menu-item">📄 Documents</a>
```

---

## 3. EMAIL CONFIGURATION

### Step 1: Setup Environment Variables

Create or update `.env` file:

```env
# SMTP Configuration
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM_EMAIL=noreply@hospitalhappy.com
SMTP_FROM_NAME=HAPPY HEAL Medical Center

# Hospital Settings
HOSPITAL_NAME=HAPPY HEAL Medical Center
HOSPITAL_ADDRESS=123 Health Street, City
HOSPITAL_PHONE=+1-555-0123
HOSPITAL_EMAIL=info@hospitalhappy.com
HOSPITAL_REGISTRATION=REG123456
```

### Step 2: Initialize Logging

Add to your main app or create a logging configuration:

```python
import logging

logging.basicConfig(
    filename='healthcare_system.log',
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
```

---

## 4. USAGE EXAMPLES

### Creating a Prescription

```python
from backend.services.email_service import get_email_service
from backend.models_extended import Prescription, PrescriptionMedicine

# Create prescription endpoint usage
POST /api/prescriptions
{
    "patient_id": 5,
    "diagnosis": "Hypertension Stage 1",
    "medicines": [
        {
            "medicine_id": 1,
            "dosage": "5mg",
            "frequency": "Once daily",
            "duration_days": 30,
            "instructions": "Take in morning with water"
        }
    ],
    "special_instructions": "Monitor blood pressure daily",
    "valid_days": 30
}
```

### Scheduling an Appointment

```python
POST /api/appointments
{
    "doctor_id": 3,
    "patient_id": 5,
    "appointment_date": "2024-04-15T10:30:00",
    "type": "Consultation",
    "reason": "Hypertension follow-up",
    "duration": 30
}
```

### Creating Consultation Notes (SOAP Format)

```python
POST /api/consultation-notes
{
    "patient_id": 5,
    "appointment_id": 12,
    "subjective": "Patient reports increased fatigue and occasional headaches",
    "objective": "BP: 140/90, HR: 78, Temperature: 98.6°F",
    "assessment": "Hypertension, adequately controlled on current medication",
    "plan": "Continue current antihypertensive medication, follow-up in 2 weeks",
    "differential_diagnosis": "Secondary hypertension ruled out by earlier tests",
    "follow_up_date": "2024-04-29"
}
```

### Generating Professional Reports

```python
from backend.services.pdf_professional import generate_professional_report

hospital_info = {
    'name': 'HAPPY HEAL Medical Center',
    'address': '123 Health Street, City',
    'phone': '+1-555-0123',
    'email': 'info@hospital.com',
    'registration': 'REG123456',
    'logo_path': 'path/to/logo.png'
}

patient_info = {
    'patient_id': 'PAT-2024-001',
    'name': 'John Doe',
    'dob': datetime(1980, 5, 15),
    'age': 44,
    'gender': 'Male',
    'blood_group': 'O+',
    'contact': '555-1234',
    'email': 'john@email.com',
    'address': '456 Main St',
    'insurance_provider': 'Blue Cross',
    'policy_number': 'BC123456'
}

doctor_info = {
    'name': 'Dr. Sarah Johnson',
    'license_number': 'LIC123456',
    'specialization': 'Internal Medicine',
    'registration_number': 'REG987654',
    'experience_years': 15,
    'contact': '555-5678'
}

vital_signs = {
    'heart_rate': 72,
    'blood_pressure': '120/80',
    'temperature': 98.6,
    'oxygen_level': 98,
    'glucose_level': 110,
    'measurement_date': datetime.now()
}

clinical_findings = {
    'chief_complaint': 'Hypertension management',
    'diagnosis': 'Hypertension Stage 1',
    'assessment': 'Patient stable on current medication',
    'treatment_plan': 'Continue antihypertensive therapy'
}

medications = [
    {
        'name': 'Lisinopril',
        'dosage': '5mg',
        'frequency': 'Once daily',
        'duration': '30 days',
        'instructions': 'Take in morning'
    }
]

recommendations = {
    'treatment_plan': 'Antihypertensive therapy',
    'lifestyle_modifications': 'Reduce sodium intake, exercise 30 mins daily',
    'return_visit_date': '2024-04-29',
    'when_to_seek_emergency_care': 'If BP > 180/110 or chest pain'
}

generate_professional_report(
    '/path/to/report.pdf',
    hospital_info, patient_info, doctor_info,
    vital_signs, clinical_findings, medications, recommendations
)
```

### Sending Email Notifications

```python
from backend.services.email_service import get_email_service

email_service = get_email_service(db)

# Send report notification
email_service.send_report_notification(
    db,
    patient_email='patient@email.com',
    patient_name='John Doe',
    doctor_name='Dr. Sarah Johnson',
    hospital_name='HAPPY HEAL Medical Center',
    report_summary='Hypertension adequately controlled',
    key_findings='BP readings improved with current medication',
    follow_up_date='April 29, 2024',
    pdf_attachment='/path/to/report.pdf'
)

# Send alert notification
email_service.send_alert_notification(
    db,
    recipient_email='patient@email.com',
    patient_name='John Doe',
    alert_type='High Blood Pressure',
    severity='critical',
    description='Blood pressure reading exceeds critical threshold',
    vital_readings='<div class="vital">BP: 180/110</div>',
    immediate_action_required=True
)

# Send appointment reminder
email_service.send_appointment_reminder(
    db,
    patient_email='patient@email.com',
    patient_name='John Doe',
    doctor_name='Dr. Sarah Johnson',
    appointment_date='April 15, 2024',
    appointment_time='10:30 AM'
)

# Send lab result notification
email_service.send_lab_result_notification(
    db,
    patient_email='patient@email.com',
    patient_name='John Doe',
    test_name='Complete Blood Count (CBC)',
    results_summary='All values within normal range',
    has_abnormal_values=False
)

# Send prescription notification
email_service.send_prescription_notification(
    db,
    patient_email='patient@email.com',
    patient_name='John Doe',
    medicines=[
        {'name': 'Lisinopril', 'dosage': '5mg', 'frequency': 'Once daily', 'duration': '30 days'}
    ]
)
```

---

## 5. FRONTEND TEMPLATES

### Create These Templates

Create the following HTML templates in `backend/templates/`:

#### 1. `prescriptions.html`
- Form to create prescriptions (doctor)
- List of prescriptions for patients
- Prescription detail view

#### 2. `appointments.html`
- Appointment booking form
- Calendar view of appointments
- Appointment management

#### 3. `consultation_notes.html`
- SOAP note creation form
- Note history and versioning

#### 4. `treatment_plans.html`
- Treatment plan creation
- Progress tracking
- Phase management

#### 5. `lab_results.html`
- Lab test ordering
- Results display
- Result history

#### 6. `medical_documents.html`
- Document upload interface
- Document viewer
- Access control

---

## 6. IMPORTANT UPDATES TO EXISTING CODE

### In `backend/routes/auth.py` - Update Patient Profile Creation

```python
@auth.route('/signup', methods=['POST'])
def signup():
    # ... existing code ...
    
    # After creating PatientProfile, also create PatientExtendedProfile
    from ..models_extended import PatientExtendedProfile
    
    extended_profile = PatientExtendedProfile(
        patient_id=user.id,
        smoking_status='never',
        alcohol_consumption='none'
    )
    db.session.add(extended_profile)
    db.session.commit()
```

### In `backend/routes/api.py` - Add Post-Report Hook

```python
# After generating a report, trigger email notification
@api.route('/api/generate-report', methods=['POST'])
@login_required
def generate_report():
    # ... existing report generation code ...
    
    # ADD THIS: Send email notification
    from ..services.email_service import get_email_service
    
    email_service = get_email_service(db)
    patient = User.query.get(patient_id)
    
    if patient and patient.email:
        email_service.send_report_notification(
            db,
            patient_email=patient.email,
            patient_name=patient.full_name,
            doctor_name=current_user.full_name,
            hospital_name=hospital_name,
            report_summary=report_summary,
            key_findings=key_findings,
            follow_up_date=follow_up_date,
            pdf_attachment=report_path
        )
```

---

## 7. BACKGROUND TASKS (Optional but Recommended)

Add scheduled email reminders using APScheduler:

```python
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime, timedelta

def schedule_appointment_reminders():
    """Send appointment reminders 24 hours before"""
    tomorrow = datetime.now() + timedelta(days=1)
    
    appointments = Appointment.query.filter(
        Appointment.appointment_date.between(tomorrow, tomorrow + timedelta(hours=1)),
        Appointment.status != 'cancelled'
    ).all()
    
    email_service = get_email_service()
    
    for appt in appointments:
        email_service.send_appointment_reminder(
            db,
            appt.patient.email,
            appt.patient.full_name,
            appt.doctor.full_name,
            appt.appointment_date.strftime('%B %d, %Y'),
            appt.appointment_date.strftime('%I:%M %p')
        )

# Initialize scheduler in app.py
scheduler = BackgroundScheduler()
scheduler.add_job(schedule_appointment_reminders, 'interval', hours=1)
scheduler.start()
```

---

## 8. TESTING

### Create Test Cases

```python
# test_prescriptions.py
def test_create_prescription():
    client = app.test_client()
    response = client.post('/api/prescriptions', json={
        'patient_id': 5,
        'medicines': [...],
        'diagnosis': 'Test'
    }, headers={'Authorization': 'Bearer token'})
    assert response.status_code == 201

def test_create_appointment():
    response = client.post('/api/appointments', json={
        'doctor_id': 3,
        'appointment_date': '2024-04-15T10:30:00'
    })
    assert response.status_code == 201

def test_consultation_note():
    response = client.post('/api/consultation-notes', json={
        'patient_id': 5,
        'subjective': 'Test',
        'objective': 'Test'
    })
    assert response.status_code == 201
```

---

## 9. DEPLOYMENT CHECKLIST

- [ ] Update database schema with new tables
- [ ] Configure email/SMTP settings
- [ ] Update requirements.txt and install new packages
- [ ] Register new blueprints in app.py
- [ ] Create new HTML templates
- [ ] Update existing routes for email notifications
- [ ] Test all new endpoints
- [ ] Configure hospital settings
- [ ] Setup audit logging
- [ ] Configure file storage for documents
- [ ] Test email functionality
- [ ] Backup database before deploying
- [ ] Test with sample data
- [ ] Document API changes

---

## 10. API ENDPOINTS SUMMARY

### Prescriptions
- `POST /api/prescriptions` - Create prescription
- `GET /api/prescriptions` - List prescriptions
- `GET /api/prescriptions/<id>` - Get prescription details

### Appointments
- `POST /api/appointments` - Create appointment
- `GET /api/appointments/<id>` - Get appointment
- `PUT /api/appointments/<id>` - Update appointment
- `DELETE /api/appointments/<id>` - Cancel appointment
- `GET /api/appointments/doctor/<doctor_id>` - Get doctor's appointments

### Consultation Notes
- `POST /api/consultation-notes` - Create SOAP note
- `GET /api/consultation-notes/<id>` - Get note

### Treatment Plans
- `POST /api/treatment-plans` - Create plan

### Email/Notifications
- `GET /api/email-logs` - Get email logs

---

## Support & Troubleshooting

**Issue**: Emails not sending
- Check SMTP credentials in hospital_settings
- Verify network access to SMTP server
- Check email_logs table for errors

**Issue**: Database errors
- Ensure all models_extended tables are created
- Check foreign key constraints
- Verify database user permissions

**Issue**: PDF generation errors
- Install reportlab and dependencies
- Check file paths exist
- Verify write permissions to output directory

